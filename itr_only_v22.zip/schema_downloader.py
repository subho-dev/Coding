# schema_downloader fallback stub for v22
def bulk_fallback_all_years(fin_years, itr_ids=("itr-1","itr-2","itr-3","itr-4"), dest_root:str="./"):
    msgs=[]
    for fy in fin_years:
        for itr in itr_ids:
            msgs.append(f"{fy}/{itr}: not downloaded in this environment - runtime will attempt download")
    return msgs

def decide_applicable_itr(user):
    # simple heuristic
    if user.get("business",0)>0:
        return "itr-3"
    if user.get("capital_gains",0)>0 or user.get("multiple_house_property",False):
        return "itr-2"
    return "itr-1"

def download_schema_for_ay(fin_year, itr_id, dest_root="./"):
    return dest_root, "stub - download at runtime"
