
ITR Assistant v22
- Auto-downloads official ITR schemas at app startup if missing; saves under regimes_schema_<AY>/<itr-id>
- Uses webdriver-manager to fetch chromedriver automatically at runtime (cross-platform). Shipping drivers is not safe/reliable.
- Improved CAHelper: fuzzy matching over schema corpus and follow-up clarification when confidence low.
- Background downloader thread that prefetches schemas and keeps helper alive until Autopilot closes.
- Theme apply fixed (uses st.rerun fallback) and seamless.
Run:
1) python -m venv .venv && source .venv/bin/activate
2) pip install -r requirements.txt
3) streamlit run app_streamlit_itr_only_v22.py
Note: Web schema downloads require internet access. For offline use, place schema files under regimes_schema_<AY>/<itr-id>/
