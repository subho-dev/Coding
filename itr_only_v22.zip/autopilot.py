# autopilot stub for v22 - improved CAHelper with fuzzy matching
import threading, queue, os, glob, difflib
class CAHelper(threading.Thread):
    def __init__(self, schema_dir):
        super().__init__(daemon=True)
        self.schema_dir = schema_dir
        self.q = queue.Queue()
        self.aq = queue.Queue()
        self._running = True
        self.corpus = self.load_corpus()
    def load_corpus(self):
        docs=[]
        for path in glob.glob(os.path.join(self.schema_dir,"**","*.*"), recursive=True):
            if path.lower().endswith((".json",".yaml",".yml",".xsd",".txt",".md")):
                try:
                    with open(path,"r",encoding="utf-8",errors="ignore") as f:
                        docs.append((path, f.read()))
                except:
                    pass
        return docs
    def run(self):
        while self._running:
            try:
                q = self.q.get(timeout=0.2)
                if q is None: break
                ans = self.answer(q)
                self.aq.put(ans)
            except Exception:
                continue
    def ask(self, text):
        self.q.put(text)
    def get_answer(self, timeout=0.1):
        try: return self.aq.get(timeout=timeout)
        except: return None
    def stop(self):
        self._running=False
        self.q.put(None)
    def answer(self, text):
        # fuzzy match keywords in corpus
        titles = [os.path.basename(p) for p,_ in self.corpus]
        match = difflib.get_close_matches(text, titles, n=1, cutoff=0.3)
        if match:
            return f"Found related schema file: {match[0]}. Please check fields in that file. If you want specifics, ask a more precise question."
        # otherwise find best doc by word overlap
        words = set(text.lower().split())
        best=None; best_score=0
        for path,doc in self.corpus:
            score = sum(1 for w in words if w in doc.lower())
            if score>best_score:
                best_score=score; best=path
        if best_score==0:
            return "I couldn't find a confident match in schemas. Can you provide more details (e.g., which deduction, section, or field)?"
        return f"Best matching schema: {os.path.basename(best)}. I found {best_score} keyword matches. Ask follow-up for exact fields."
