ITR + Stock Analysis App (Demo)
Files:
- app.py              : Main application (PySide6) combining ITR assistant and stock analysis.
- regimes.json       : Tax regime data (data-driven). Update when new regimes arrive.
- sample_stocks.csv  : Synthetic stock price data for demo & testing.
- requirements.txt   : Python dependencies.
- README.txt         : This file.

Important safety notes:
- Autopilot (browser automation) is a scaffold and WILL NOT bypass OTP or 2FA. You must enter OTPs manually.
- No feature guarantees risk-free or fully profitable investments. Stock markets carry risk. The app provides predictive models for educational/demo purposes only.
- Update regimes.json with official rates for production.

To run (demo):
1. Create a virtualenv and install requirements: pip install -r requirements.txt
2. Run: python app.py
3. Use the "Analyze Stocks" mode to explore sample data.

This is a demo project scaffolded by ChatGPT. For production use, add secure credential storage, server-side updates for regimes, robust error handling, and professional testing.
