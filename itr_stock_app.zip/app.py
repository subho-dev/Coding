
# app.py
"""
ITR + Stock Analysis Assistant (Demo)
- PySide6 GUI: ITR assistant (data-driven) + Stock analysis tool (demo)
- Includes regime loader, best-regime chooser, filing guide generator, and an autopilot scaffold.
- Stock tool: shows available stocks from CSV, basic RandomForest-based prediction with plots.
- DISCLAIMER: This is a demo scaffold. Autopilot does not bypass OTP/2FA. Investment predictions are probabilistic and not guaranteed.
"""
import sys, json, math, os
from pathlib import Path
from datetime import datetime
from functools import partial

from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                               QListWidget, QStackedWidget, QPushButton, QFormLayout, QLineEdit,
                               QTextEdit, QFileDialog, QMessageBox, QComboBox, QCheckBox, QScrollArea,
                               QFrame, QSpinBox)
from PySide6.QtCore import Qt, QSize

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

BASE = Path(__file__).parent
REGIMES_PATH = BASE / "regimes.json"
STOCKS_PATH = BASE / "sample_stocks.csv"

def load_regimes(path=REGIMES_PATH):
    if not path.exists():
        raise FileNotFoundError("regimes.json not found.")
    return json.load(open(path, "r", encoding="utf-8"))

REGIMES = load_regimes()

# ---- Tax engine (same as earlier, simplified) ----
class TaxEngine:
    def __init__(self, regime):
        self.regime = regime
    def calculate_tax(self, taxable_income):
        slabs = self.regime.get("slabs", [])
        remaining = taxable_income
        tax = 0.0
        lower = 0.0
        for slab in slabs:
            upto = slab.get("upto")
            rate = slab.get("rate", 0)/100.0
            if upto is None:
                taxable = max(0.0, remaining)
                tax += taxable*rate
                break
            slab_amount = max(0.0, min(remaining, upto-lower))
            tax += slab_amount*rate
            remaining -= slab_amount
            lower = upto
            if remaining<=0:
                break
        # cess
        cess = self.regime.get("cess_percent",0)
        tax += tax*(cess/100.0)
        return round(tax,0)

def compute_tax_for_regime(regime, total_income, deductions):
    ded_limits = regime.get("deduction_limits",{})
    allowed = {}
    for k,v in deductions.items():
        limit = ded_limits.get(k,None)
        allowed[k] = min(v, limit) if (limit is not None and limit>0) else v if (limit is None) else 0
    total_ded = sum(allowed.values())
    taxable = max(0.0, total_income - total_ded)
    engine = TaxEngine(regime)
    tax = engine.calculate_tax(taxable)
    return {"taxable_income": taxable, "tax": tax, "allowed_deductions": allowed, "total_deductions": total_ded}

def choose_best_regime(total_income, deductions, regimes):
    best = None; best_key=None; details={}
    for k,reg in regimes.get("regimes",{}).items():
        res = compute_tax_for_regime(reg, total_income, deductions)
        details[k]=res
        if best is None or res["tax"]<best:
            best = res["tax"]; best_key=k
    return best_key, details

# ---- Stock utilities ----
def load_stocks(path=STOCKS_PATH):
    if not path.exists():
        return pd.DataFrame()
    df = pd.read_csv(path, parse_dates=["date"])
    return df

def prepare_lag_features(df, lags=5):
    df = df.sort_values("date").copy()
    for i in range(1,lags+1):
        df[f"lag_{i}"] = df["close"].shift(i)
    df["target"] = df["close"].shift(-1)
    return df.dropna()

def train_predict_stock(df_symbol):
    # simple RF on lag features
    lags = 5
    df = prepare_lag_features(df_symbol, lags=lags)
    X = df[[f"lag_{i}" for i in range(1,lags+1)]].values
    y = df["target"].values
    if len(X)<20:
        return None
    X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,shuffle=False)
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    last_features = df[[f"lag_{i}" for i in range(1,lags+1)]].values[-1].reshape(1,-1)
    next_pred = model.predict(last_features)[0]
    return {"model": model, "predictions": pred, "y_test": y_test, "next_pred": float(next_pred)}

# ---- GUI ----
class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=3, dpi=100):
        fig, self.ax = plt.subplots(figsize=(width,height), dpi=dpi)
        super().__init__(fig)
        self.setParent(parent)
    def plot_time_series(self, dates, series, title=""):
        self.ax.clear()
        self.ax.plot(dates, series)
        self.ax.set_title(title)
        self.ax.figure.autofmt_xdate()
        self.draw()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ITR + Stock Assistant (Demo)")
        self.resize(1100,700)
        self.regimes = REGIMES
        self.stocks_df = load_stocks()
        self._build_ui()

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        h = QHBoxLayout(central)
        # left list
        self.menu = QListWidget()
        self.menu.addItems(["Home","ITR Assistant","Analyze Stocks","Know best investment plan","CA Tools"])
        self.menu.setMaximumWidth(260)
        self.menu.currentRowChanged.connect(self.switch_page)
        h.addWidget(self.menu)
        # stack
        self.stack = QStackedWidget()
        h.addWidget(self.stack)
        # pages
        self.page_home = self.page_home()
        self.page_itr = self.page_itr()
        self.page_stocks = self.page_stocks()
        self.page_invest = self.page_invest()
        self.page_tools = self.page_tools()
        for p in [self.page_home, self.page_itr, self.page_stocks, self.page_invest, self.page_tools]:
            self.stack.addWidget(p)
        self.menu.setCurrentRow(0)

    def switch_page(self, idx):
        self.stack.setCurrentIndex(idx)

    # --- Page: Home ---
    def page_home(self):
        w = QWidget()
        v = QVBoxLayout(w)
        lbl = QLabel("<h2>Welcome — ITR + Stock Assistant</h2>")
        v.addWidget(lbl)
        info = QLabel("Use the left menu to navigate. This demo is data-driven. Update regimes.json and sample_stocks.csv for live data.")
        info.setWordWrap(True)
        v.addWidget(info)
        return w

    # --- Page: ITR Assistant ---
    def page_itr(self):
        w = QWidget()
        v = QVBoxLayout(w)
        form = QFormLayout()
        self.income_input = QLineEdit(); self.income_input.setPlaceholderText("Total annual income (numeric)")
        form.addRow("Total Income (₹):", self.income_input)
        # deductions
        self.ded_80c = QLineEdit(); self.ded_80c.setPlaceholderText("0")
        self.ded_80d = QLineEdit(); self.ded_80d.setPlaceholderText("0")
        self.home_loan = QLineEdit(); self.home_loan.setPlaceholderText("0")
        form.addRow("80C (₹):", self.ded_80c)
        form.addRow("80D (₹):", self.ded_80d)
        form.addRow("Home loan interest (₹):", self.home_loan)
        v.addLayout(form)
        # actions
        btn_h = QHBoxLayout()
        calc_btn = QPushButton("Compare regimes & Suggest best")
        calc_btn.clicked.connect(self.compute_best_regime)
        btn_h.addWidget(calc_btn)
        guide_btn = QPushButton("Generate Step-by-step Filing Guide")
        guide_btn.clicked.connect(self.generate_guide)
        btn_h.addWidget(guide_btn)
        autopilot_btn = QPushButton("Autopilot (scaffold)")
        autopilot_btn.clicked.connect(self.autopilot_scaffold)
        btn_h.addWidget(autopilot_btn)
        v.addLayout(btn_h)
        # results
        self.itr_result = QTextEdit(); self.itr_result.setReadOnly(True)
        v.addWidget(self.itr_result)
        return w

    def compute_best_regime(self):
        try:
            income = float(self.income_input.text() or 0)
        except:
            QMessageBox.warning(self, "Input error", "Enter numeric income.")
            return
        deductions = {"80C": float(self.ded_80c.text() or 0), "80D": float(self.ded_80d.text() or 0),
                      "home_loan_interest": float(self.home_loan.text() or 0)}
        key, details = choose_best_regime(income, deductions, self.regimes)
        text = f"Best regime: {self.regimes['regimes'][key]['name']} (key={key})\n\nDetails per regime:\n"
        for k,v in details.items():
            text += f"- {k}: taxable_income=₹{v['taxable_income']}, tax=₹{v['tax']}, total_deductions=₹{v['total_deductions']}\n"
        text += "\nNote: Review allowed deductions and confirm before filing. Autopilot is a scaffold and will not bypass OTP/2FA."
        self.itr_result.setPlainText(text)

    def generate_guide(self):
        # Simple step-by-step guide generator
        income = float(self.income_input.text() or 0)
        deductions = {"80C": float(self.ded_80c.text() or 0), "80D": float(self.ded_80d.text() or 0),
                      "home_loan_interest": float(self.home_loan.text() or 0)}
        key, details = choose_best_regime(income, deductions, self.regimes)
        regime = self.regimes['regimes'][key]
        g = []
        g.append(f"1) Selected regime: {regime['name']}")
        g.append(f"2) Total Income: ₹{income}")
        g.append(f"3) Deductions used: {details[key]['allowed_deductions']}")
        g.append(f"4) Taxable income: ₹{details[key]['taxable_income']}")
        g.append(f"5) Estimated tax: ₹{details[key]['tax']}")
        g.append("6) Documents to collect: Form 16, bank interest statements, investment proofs (80C receipts), health premium receipts (80D), home loan interest certificate.")
        g.append("7) Visit the official income tax e-filing portal. Login with credentials, fill ITR form, upload documents, verify summary.")
        g.append("8) If using Autopilot: the app can pre-fill fields and guide you; you must enter OTPs during login / verification as required.")
        self.itr_result.setPlainText("\\n".join(g))

    def autopilot_scaffold(self):
        QMessageBox.information(self, "Autopilot scaffold",
                                "Autopilot opens a Selenium scaffold to pre-fill forms. It will NOT bypass OTP or 2FA. "
                                "For security, autofill credentials are not stored by this demo.")

    # --- Page: Stocks ---
    def page_stocks(self):
        w = QWidget()
        v = QVBoxLayout(w)
        top_h = QHBoxLayout()
        load_btn = QPushButton("Load stocks CSV")
        load_btn.clicked.connect(self.load_stocks_file)
        top_h.addWidget(load_btn)
        back_btn = QPushButton("Back to Home")
        back_btn.clicked.connect(lambda: self.menu.setCurrentRow(0))
        top_h.addWidget(back_btn)
        v.addLayout(top_h)
        # list of symbols
        self.symbol_list = QListWidget()
        symbols = sorted(self.stocks_df["symbol"].unique()) if not self.stocks_df.empty else []
        self.symbol_list.addItems(symbols)
        self.symbol_list.itemClicked.connect(self.show_stock_detail)
        v.addWidget(self.symbol_list)
        # detail area
        self.stock_detail = QWidget()
        self.stock_detail_layout = QVBoxLayout(self.stock_detail)
        v.addWidget(self.stock_detail)
        return w

    def load_stocks_file(self):
        p, _ = QFileDialog.getOpenFileName(self, "Open CSV", str(BASE), "CSV Files (*.csv)")
        if not p:
            return
        self.stocks_df = pd.read_csv(p, parse_dates=["date"])
        self.symbol_list.clear()
        self.symbol_list.addItems(sorted(self.stocks_df["symbol"].unique()))

    def show_stock_detail(self, item):
        sym = item.text()
        df = self.stocks_df[self.stocks_df["symbol"]==sym].sort_values("date")
        # clear layout
        for i in reversed(range(self.stock_detail_layout.count())):
            self.stock_detail_layout.itemAt(i).widget().setParent(None)
        # plot
        canvas = PlotCanvas(self, width=6, height=3)
        canvas.plot_time_series(df["date"], df["close"], title=f"{sym} — Close Price")
        self.stock_detail_layout.addWidget(canvas)
        # train & predict
        res = train_predict_stock(df)
        txt = QTextEdit(); txt.setReadOnly(True)
        if res is None:
            txt.setPlainText("Not enough data for prediction.")
            self.stock_detail_layout.addWidget(txt)
            return
        txt.setPlainText(f"Next day predicted close: ₹{res['next_pred']:.2f}")
        self.stock_detail_layout.addWidget(txt)
        # show simple analysis
        stats = df["close"].describe()
        stats_txt = QTextEdit(); stats_txt.setReadOnly(True)
        stats_txt.setPlainText(str(stats))
        self.stock_detail_layout.addWidget(stats_txt)

    # --- Page: Investment planner ---
    def page_invest(self):
        w = QWidget()
        v = QVBoxLayout(w)
        form = QFormLayout()
        self.invest_amount = QLineEdit(); self.invest_amount.setPlaceholderText("Amount per month or lump sum")
        self.invest_duration = QSpinBox(); self.invest_duration.setRange(1,60); self.invest_duration.setValue(12)
        self.invest_freq = QComboBox(); self.invest_freq.addItems(["Monthly","Yearly","Lump-sum"])
        form.addRow("Amount (₹):", self.invest_amount)
        form.addRow("Duration (months):", self.invest_duration)
        form.addRow("Frequency:", self.invest_freq)
        v.addLayout(form)
        btn = QPushButton("Recommend portfolio (demo)")
        btn.clicked.connect(self.recommend_portfolio)
        v.addWidget(btn)
        self.invest_result = QTextEdit(); self.invest_result.setReadOnly(True)
        v.addWidget(self.invest_result)
        return w

    def recommend_portfolio(self):
        # WARNING: cannot guarantee risk-free profitable investments.
        try:
            amt = float(self.invest_amount.text() or 0)
        except:
            QMessageBox.warning(self, "Input", "Enter numeric amount.")
            return
        dur = int(self.invest_duration.value())
        freq = self.invest_freq.currentText()
        if self.stocks_df.empty:
            QMessageBox.warning(self, "Data", "Load stocks in Analyze Stocks first.")
            return
        # naive strategy: choose top 2 symbols by recent trend (slope)
        symbols = self.stocks_df["symbol"].unique()
        trends = {}
        for s in symbols:
            df = self.stocks_df[self.stocks_df["symbol"]==s].sort_values("date")
            x = np.arange(len(df))
            if len(x)>2:
                slope = np.polyfit(x, df["close"].values, 1)[0]
                trends[s]=slope
        ranked = sorted(trends.items(), key=lambda x: -x[1])
        top = [r[0] for r in ranked[:2]]
        self.invest_result.setPlainText(f"Suggested (demo) portfolio: {top}\n\nMethod: top symbols by trend. THIS IS A DEMO — not risk-free or guaranteed profitable.")
    def page_tools(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(QLabel("CA Tools — placeholders for reconciliation, form generators, document checklist, etc."))
        return w

if __name__=="__main__":
    app = QApplication(sys.argv)
    mw = MainWindow()
    mw.show()
    sys.exit(app.exec())
