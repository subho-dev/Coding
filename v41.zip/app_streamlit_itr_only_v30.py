# app_streamlit_itr_only.py - merged 
import os, io, time, traceback, yaml, glob
import streamlit as st, pandas as pd, numpy as np, requests, feedparser
import plotly.express as px
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from fetcher import fetch_from_sources
from schema_downloader import decide_applicable_itr, download_schema_for_ay, bulk_fallback_all_years
from autopilot import launch_headless_chrome, CAHelper

# ===== Inlined Topbar + Chat + Auth UI (all inside app file) =====
import streamlit.components.v1 as components, html

_topbar_html = r"""
<style>
:root{--tb-bg:rgba(8,10,16,0.9);--tb-fg:#e8eefc;--tb-accent:#4f8cff;--tb-border:rgba(255,255,255,0.08)}
.itrtopbar{position:fixed;top:0;left:0;right:0;height:62px;display:flex;align-items:center;justify-content:flex-end;padding:10px 18px;z-index:99999;background:var(--tb-bg);backdrop-filter:blur(6px);border-bottom:1px solid var(--tb-border)}
.itrtopbar .right{display:flex;gap:10px;align-items:center}
.chip{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:12px;background:rgba(255,255,255,0.03);color:var(--tb-fg);cursor:pointer;border:1px solid var(--tb-border);font-weight:600;transition:all .12s ease}
.chip:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(0,0,0,0.35)}
.chip.primary{background:linear-gradient(90deg,var(--tb-accent),#7c5cff);color:white;border:none}
.chip.select select{background:transparent;border:none;color:inherit;outline:none;font-weight:600}
.avatar img{width:36px;height:36px;border-radius:10px;display:block}
/* Chat modal */
.chat-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(3px);display:none;z-index:100000;align-items:center;justify-content:center}
.chat-modal{width:680px;max-height:82vh;background:linear-gradient(180deg, rgba(12,14,20,0.96), rgba(9,11,16,0.98));border-radius:14px;border:1px solid var(--tb-border);display:flex;flex-direction:column;overflow:hidden;color:var(--tb-fg)}
.chat-head{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid rgba(255,255,255,0.03)}
.chat-body{padding:12px;overflow:auto;flex:1;background:linear-gradient(180deg, rgba(6,8,12,0.0), rgba(0,0,0,0.03))}
.chat-input{display:flex;gap:8px;padding:12px;border-top:1px solid rgba(255,255,255,0.03)}
.chat-input input{flex:1;padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,0.04);background:rgba(255,255,255,0.02);color:var(--tb-fg)}

.auth-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);display:none;align-items:center;justify-content:center;z-index:100000}
.auth-card{width:460px;border-radius:12px;background:linear-gradient(180deg, rgba(10,12,18,0.98), rgba(8,10,15,0.98));border:1px solid var(--tb-border);color:var(--tb-fg);overflow:hidden}
.auth-head{padding:12px 14px;border-bottom:1px solid rgba(255,255,255,0.03);display:flex;justify-content:space-between;align-items:center}
.auth-body{padding:14px}
.auth-body input{width:100%;padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.04);margin:6px 0;background:rgba(255,255,255,0.02);color:var(--tb-fg)}
.auth-body button{width:100%;padding:10px;border-radius:8px;border:none;margin-top:8px;background:var(--tb-accent);color:white;font-weight:700}

.small-muted{font-size:13px;opacity:0.8;color:rgba(255,255,255,0.8)}

</style>

<div class="itrtopbar" id="itrtopbar">
  <div class="right">
    <div class="chip select" id="theme_chip"><span>🎨</span><select id="theme_select"><option value="auto">Auto</option><option value="neo-dark">Neo Dark</option><option value="ocean">Ocean</option><option value="sunrise">Sunrise</option><option value="plus">＋ Themes</option></select></div>
    <div class="chip select" id="lang_chip"><span>🌐</span><select id="lang_select"><option value="en">English</option><option value="hi">हिन्दी</option></select></div>
    <div class="chip" id="call_chip"><span>📞</span><span class="small-muted">Call</span></div>
    <div class="chip primary" id="chat_chip"><span class="small-muted">Ask the CA</span><span>🤖</span></div>
    <div class="chip" id="login_chip"><span>🔐</span><span class="small-muted">Login</span></div>
    <div class="chip avatar" id="profile_chip" style="display:none"><img id="profile_img" src=""></div>
  </div>
</div>

<div class="chat-overlay" id="chat_overlay">
  <div class="chat-modal" id="chat_modal">
    <div class="chat-head"><div><strong>Ask the CA</strong></div><div><button id="min_btn">_</button>&nbsp;<button id="close_btn">×</button></div></div>
    <div class="chat-body" id="chat_body"></div>
    <div class="chat-input"><input id="chat_input" placeholder="Type your question..."><button id="chat_send">Send</button></div>
  </div>
</div>

<div class="auth-overlay" id="auth_overlay">
  <div class="auth-card">
    <div class="auth-head"><strong>Welcome</strong><div><button id="auth_close">×</button></div></div>
    <div class="auth-body">
      <div id="login_section">
        <input id="login_user" placeholder="Username"><input id="login_pass" placeholder="Password" type="password">
        <button id="login_submit">Login</button>
        <button id="guest_submit" style="background:transparent;border:1px solid rgba(255,255,255,0.06);">Continue as Guest</button>
        <div class="small-muted">No account? <a href="#" id="show_signup">Signup</a></div>
        <div id="login_msg" class="small-muted"></div>
      </div>
      <div id="signup_section" style="display:none">
        <input id="su_user" placeholder="Username"><input id="su_pass" placeholder="Password" type="password">
        <input id="su_email" placeholder="Email"><input id="su_name" placeholder="Full name"><input id="su_phone" placeholder="Phone">
        <button id="signup_submit">Create account</button>
        <div class="small-muted">Already a user? <a href="#" id="show_login">Login</a></div>
        <div id="signup_msg" class="small-muted"></div>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  // Helper for toggling overlays
  const chatOverlay = document.getElementById('chat_overlay');
  const chatModal = document.getElementById('chat_modal');
  const chatBody = document.getElementById('chat_body');
  const chatInput = document.getElementById('chat_input');
  const chatSend = document.getElementById('chat_send');
  const chatChip = document.getElementById('chat_chip');
  const authOverlay = document.getElementById('auth_overlay');
  const loginChip = document.getElementById('login_chip');
  const profileChip = document.getElementById('profile_chip');
  const profileImg = document.getElementById('profile_img');
  const themeSelect = document.getElementById('theme_select');
  const langSelect = document.getElementById('lang_select');
  const callChip = document.getElementById('call_chip');

  function openChat(){ chatOverlay.style.display='flex'; chatBody.innerHTML=''; resetTimers(); }

  async function saveProfileToServer(user, profile){ await fetch('/profile/'+encodeURIComponent(user), {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(profile)}); }
  async function loadProfileFromServer(user){ try{ const r=await fetch('/profile/'+encodeURIComponent(user)); const j=await r.json(); return j.ok?j:{} }catch(e){return {}} }

  function closeChat(){ chatOverlay.style.display='none'; clearTimers(); }
  function minimizeChat(){ chatOverlay.style.display='none'; /* show small dock if required */ }

  chatChip.onclick = openChat;
  document.getElementById('close_btn').onclick = closeChat;
  document.getElementById('min_btn').onclick = minimizeChat;

  // Chat send
  async function sendMsg(){
    const m = chatInput.value.trim(); if(!m) return;
    addMsg(m,'user'); chatInput.value='';
    const stop = showTyping();
    try{
      const resp = await fetch('/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({session_id: (await (await fetch('/_session')).json()).username || 'default', message: m})});
      const j = await resp.json();
      stop(); addMsg(j.reply || 'No reply','bot');
    }catch(e){ stop(); addMsg('Error contacting backend.','bot'); }
  }
  chatSend.onclick = sendMsg;
  chatInput.addEventListener('keydown',(e)=>{ if(e.key==='Enter') sendMsg(); });

  function addMsg(t, who){
    const d = document.createElement('div'); d.style.padding='8px 10px'; d.style.margin='8px'; d.style.borderRadius='10px'; d.style.maxWidth='80%';
    if(who==='user'){ d.style.background='rgba(255,255,255,0.04)'; d.style.marginLeft='auto'; d.style.textAlign='right'; }
    else { d.style.background='rgba(255,255,255,0.02)'; d.style.marginRight='auto'; }
    d.textContent = t; chatBody.appendChild(d); chatBody.scrollTop = chatBody.scrollHeight;
  }
  function showTyping(){
    const d = document.createElement('div'); d.textContent='Thinking...'; d.style.opacity='0.8'; d.style.margin='8px'; chatBody.appendChild(d); chatBody.scrollTop = chatBody.scrollHeight;
    const iv = setInterval(()=>{ d.textContent = d.textContent+'.'; if(d.textContent.length>20) d.textContent='Thinking...'; }, 700);
    return ()=>{ clearInterval(iv); d.remove(); };
  }

  // Theme select: write query param and reload (keeps Streamlit simple)
  themeSelect.onchange = async function(e){
    const val = e.target.value;
    if(val==='plus'){ const qs = new URLSearchParams(window.location.search); qs.set('page','Themes'); window.location.search = qs.toString(); return; }
    try{ const r = await fetch('/theme/list'); const j = await r.json(); if(j.ok){ const found = j.themes.find(t=>t.name===val); if(found){ applyTheme(found.config); } } }catch(e){ console.error(e);}
  };
  // Lang select sets query param
  langSelect.onchange = function(e){ const qs = new URLSearchParams(window.location.search); qs.set('lang', e.target.value); window.location.search = qs.toString(); };

  // Call
  callChip.onclick = function(){ const num = window.stCallNumber || ''; if(num) window.location.href = 'tel:'+num; };

  // Auth handlers (calls backend endpoints)
  loginChip.onclick = function(){ authOverlay.style.display='flex'; };
  document.getElementById('auth_close').onclick = function(){ authOverlay.style.display='none'; };

  document.getElementById('show_signup').onclick = function(e){ e.preventDefault(); document.getElementById('login_section').style.display='none'; document.getElementById('signup_section').style.display='block'; };
  document.getElementById('show_login').onclick = function(e){ e.preventDefault(); document.getElementById('login_section').style.display='block'; document.getElementById('signup_section').style.display='none'; };

  document.getElementById('guest_submit').onclick = async function(){
    try{ const r=await fetch('/guest_login',{method:'POST'}); const j=await r.json(); if(j.ok){ await fetch('/_session', {method:'POST',headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'set_user', username: j.username})}); authOverlay.style.display='none'; showProfile(j.username); await fetch('/profile_upsert/'+encodeURIComponent(j.username), {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email:j.email, full_name:j.full_name, phone:j.phone, data:j.data||{}})}); } }catch(e){}
  };

  document.getElementById('login_submit').onclick = async function(){
    const payload = {username: document.getElementById('login_user').value, password: document.getElementById('login_pass').value};
    try{ const r=await fetch('/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); const j=await r.json(); if(j.ok){ await fetch('/_session', {method:'POST',headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'set_user', username: j.username})}); authOverlay.style.display='none'; showProfile(j.username); await fetch('/profile_upsert/'+encodeURIComponent(j.username), {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email:j.email, full_name:j.full_name, phone:j.phone, data:j.data||{}})}); } else { document.getElementById('login_msg').textContent = j.error || 'Login failed'; } }catch(e){ document.getElementById('login_msg').textContent='Login error'; }
  };

  document.getElementById('signup_submit').onclick = async function(){
    const payload = {username: document.getElementById('su_user').value, password: document.getElementById('su_pass').value, email: document.getElementById('su_email').value, full_name: document.getElementById('su_name').value, phone: document.getElementById('su_phone').value};
    try{ const r=await fetch('/signup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); const j=await r.json(); if(j.ok){ await fetch('/_session', {method:'POST',headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'set_user', username: j.username})}); authOverlay.style.display='none'; showProfile(j.username); await fetch('/profile_upsert/'+encodeURIComponent(j.username), {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email:j.email, full_name:j.full_name, phone:j.phone, data:j.data||{}})}); } else { document.getElementById('signup_msg').textContent = j.error || 'Signup failed'; } }catch(e){ document.getElementById('signup_msg').textContent='Signup error'; }
  };

  async function showProfile(user){
    const prof = await loadProfileFromServer(user);
    try{ if(prof && prof.full_name){ /* set profile in UI */ } }catch(e){}
    // Load ITR saved data
    try{ const r = await fetch('/itr/load/'+encodeURIComponent(user)); const j=await r.json(); if(j.ok && j.data){ window._loaded_itr = j.data; /* front-end can use this to pre-fill fields via Streamlit if needed */ } }catch(e){}

    try{
      const r = await fetch('/profile/'+encodeURIComponent(user)); const j = await r.json();
      if(j.ok){ profileChip.style.display='flex'; profileImg.src = 'data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="36" height="36" rx="8" fill="#1f6feb"/><text x="50%" y="55%" font-size="16" text-anchor="middle" fill="#fff">'+(j.full_name?j.full_name.charAt(0).toUpperCase():'U')+'</text></svg>'); loginChip.style.display='none'; /* profile cached in server session/database */ }
    }catch(e){ console.error(e); }
  }

  // On load, if user exists in localStorage show profile
  (function(){ const resp = await fetch('/_session'); const ss = await resp.json(); if(ss.username) showProfile(ss.username); })();

  // Simple idle timers: minimize after 30s, close after 5min
  let idleTimer=null, longTimer=null;
  function resetTimers(){ clearTimers(); idleTimer = setTimeout(minimizeChat, 30*1000); longTimer = setTimeout(closeChat, 5*60*1000); }
  function clearTimers(){ if(idleTimer) clearTimeout(idleTimer); if(longTimer) clearTimeout(longTimer); }
  document.addEventListener('mousemove', resetTimers, {passive:true}); document.addEventListener('keydown', resetTimers, {passive:true});

})();
</script>
"""

# Use components.html to inject - height 0 so it runs and injects into page DOM
components.html(_topbar_html, height=0)
# ===== End Inlined Topbar =====
import re

# ---- Server-side DB helper for app ----
import sqlite3, json as _json, atexit
APP_DB = os.environ.get("APP_DB", "data/app.db")
def app_db_conn():
    os.makedirs(os.path.dirname(APP_DB), exist_ok=True)
    conn = sqlite3.connect(APP_DB, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def get_profile_for_user(username):
    if not username: return {}
    c = app_db_conn(); cur = c.cursor()
    cur.execute("SELECT username,email,full_name,phone,data FROM profiles WHERE username=?", (username,))
    r = cur.fetchone(); c.close()
    if not r: return {}
    try: data = _json.loads(r["data"] or "{}")
    except: data={}
    return {"username": r["username"], "email": r["email"], "full_name": r["full_name"], "phone": r["phone"], "data": data}

# On app start, ensure DB exists and defaults are in place (calls FastAPI defaults endpoint optional)
try:
    conn_tmp = app_db_conn(); conn_tmp.close()
except Exception as e:
    st.error("Failed to create app DB: "+str(e))

st.markdown("""<style>
.main, .block-container, [data-testid="stSidebar"], [data-testid="stBottomBlockContainer"] { 
  scroll-behavior:smooth; transition: all .18s ease-in-out;
}
</style>""", unsafe_allow_html=True)


# ===== Injected Topbar + Backend Mount =====

# ---- Theme & Language from query params ----
qp = st.query_params
if 'theme' in qp:
    st.session_state['theme'] = qp.get('theme')
if 'lang' in qp:
    st.session_state['lang'] = qp.get('lang')
# Inject CSS variables for theme if present
def theme_css(theme):
    if theme == 'neo-dark':
        return ":root{--tb-bg:rgba(9,11,18,.82);--tb-fg:#f0f3ff;--tb-accent:#7aa2ff;--tb-border:rgba(255,255,255,.16);}"
    if theme == 'ocean':
        return ":root{--tb-bg:rgba(4,18,28,.80);--tb-fg:#e8f4ff;--tb-accent:#27c4ff;--tb-border:rgba(255,255,255,.14);}"
    if theme == 'sunrise':
        return ":root{--tb-bg:rgba(34,19,16,.80);--tb-fg:#fff6f0;--tb-accent:#ff8a4b;--tb-border:rgba(255,255,255,.18);}"
    return ""
st.markdown(f"<style>{theme_css(st.session_state.get('theme',''))}</style>", unsafe_allow_html=True)


# ----- User profile integration -----
import sqlite3, json
USERS_DB = os.environ.get("USERS_DB", "data/users.sqlite3")
def load_profile_for(user):
    if not user: return {}
    try:
        con = sqlite3.connect(USERS_DB); cur=con.cursor()
        cur.execute("SELECT username,email,full_name,phone,data FROM users WHERE username=?", (user,))
        r=cur.fetchone(); con.close()
        if not r: return {}
        u,email,full_name,phone,data = r
        try: parsed = json.loads(data or "{}")
        except: parsed = {}
        return {"username":u,"email":email,"full_name":full_name,"phone":phone,"data":parsed}
    except Exception as e:
        return {}
# Check for query param override to prefill fields
_user_q = st.query_params.get("_user", [None])[0]
if _user_q:
    prof = load_profile_for(_user_q)
    if prof:
        # expose profile to client-side for JS and prefill default forms via session_state
        st.session_state['profile'] = prof
        st.markdown(f"<script>window.itr_profile = {json.dumps(prof)};</script>", unsafe_allow_html=True)

import threading, uvicorn, types
from fastapi import FastAPI
from server.fastapi_server import app as _fastapi_app
from server.voice_bg import background_bootstrap

# bootstrap voice downloads (background)
background_bootstrap()

# Mount FastAPI on the same server via st.experimental_singleton-like approach
if "uvicorn_thread" not in st.session_state:
    def run_server():
        uvicorn.run(_fastapi_app, host="0.0.0.0", port=8000, log_level="warning")
    t = threading.Thread(target=run_server, daemon=True)
    t.start()
    st.session_state["uvicorn_thread"]=True

# Serve topbar assets
st.markdown(f"<style>{open('', encoding='utf-8').read(, encoding='utf-8')}</style>", unsafe_allow_html=True)
st.components.v1.html(open("", encoding='utf-8').read(, encoding='utf-8'), height=0)

# Language/theme handlers (simple session flags)
lang = st.query_params.get("_lang_sel", [st.session_state.get("lang","en")])[0]
st.session_state["lang"]=lang
theme_sel = st.query_params.get("_theme_sel", [st.session_state.get("theme","auto")])[0]
st.session_state["theme"]=theme_sel

# Expose phone number for call button
st.session_state.setdefault("call_number","+919999999999")  # change in Settings page
st.markdown(f"<script>window.stCallNumber='{st.session_state['call_number']}';</script>", unsafe_allow_html=True)

# smooth page transitions via CSS
st.markdown("""
<style>
.reportview-container .main .block-container{transition:opacity .25s ease-in-out; }
</style>
""", unsafe_allow_html=True)
# ===== End Injected =====


def use_regex(input_text):
    pattern = re.compile(r"[1-9]"+"\. "+".*", re.IGNORECASE)
    output = pattern.findall(input_text)
    final_output = []
    for value in output:
        value = value.replace("</p>","")
        final_output.append(value)
    return final_output

st.set_page_config(page_title="ITR Assistant", layout="wide", initial_sidebar_state="expanded")
LOG="itr_log.txt"

def log(msg):
    try:
        with open(LOG,"a",encoding="utf-8") as f: f.write(f"{time.time()} - {msg}\n")
    except: pass

# Theme system
THEME_FILE="themes.yaml"
DEFAULT_THEMES={"Neo Dark":{"bg":"#0b0f1a","card":"#111827","text":"#E5F0FF","muted":"#9FB8D6","accent":"#7AFCFF"},
                "Ink Black":{"bg":"#00040A","card":"#0B1220","text":"#F1F5F9","muted":"#98A2B3","accent":"#00E5A8"},
                "Light Contrast":{"bg":"#F6FAFF","card":"#FFFFFF","text":"#0B1220","muted":"#5B6777","accent":"#006D77"}}
def load_themes():
    if os.path.exists(THEME_FILE):
        try:
            with open(THEME_FILE,"r",encoding="utf-8") as f: return yaml.safe_load(f)
        except: return DEFAULT_THEMES.copy()
    return DEFAULT_THEMES.copy()
def save_themes(th): 
    try:
        with open(THEME_FILE,"w",encoding="utf-8") as f: yaml.safe_dump(th,f,sort_keys=False)
    except Exception as e: log(f"save themes err {e}")

if "themes" not in st.session_state: st.session_state.themes = load_themes()
if "theme_name" not in st.session_state: st.session_state.theme_name = list(st.session_state.themes.keys())[0]
def apply_theme(name):
    th = st.session_state.themes.get(name, list(st.session_state.themes.values())[0])
    css = f"""
    <style>
    :root{{--bg:{th['bg']};--card:{th['card']};--text:{th['text']};--muted:{th['muted']};--accent:{th['accent']};}}
    .appview-container{{background:var(--bg);}}
    .card{{background:var(--card);border-radius:12px;padding:14px;color:var(--text);margin-bottom:12px}}
    .hero{{background:linear-gradient(90deg,#03396c,#006d77);padding:20px;border-radius:12px;color:var(--text);margin-bottom:12px}}
    .muted{{color:var(--muted)}}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)
apply_theme(st.session_state.theme_name)

menu = st.sidebar.radio("Navigate", ["🏠 Overview","🧾 ITR Assistant","🧩 Regime Manager","🤖 Autopilot","🎨 Themes","⚙️ Settings"], index=0)
# "📰 Newsletter"
# defaults
DEFAULT_CFG = {"regimes":{"old":{"name":"Old Regime","cess_percent":4,"slabs":[{"upto":250000,"rate":0},{"upto":500000,"rate":5},{"upto":1000000,"rate":20},{"upto":None,"rate":30}],"deduction_limits":{"80C":150000},"explanation":"Old Regime"},"new":{"name":"New Regime","cess_percent":4,"slabs":[{"upto":300000,"rate":0},{"upto":600000,"rate":5},{"upto":900000,"rate":10},{"upto":1200000,"rate":15},{"upto":1500000,"rate":20},{"upto":2000000,"rate":25},{"upto":None,"rate":30}],"deduction_limits":{"80C":0},"explanation":"New Regime"}},"sources":[]}

if "cfg" not in st.session_state:
    if os.path.exists("regimes.yaml"):
        try:
            with open("regimes.yaml","r",encoding="utf-8") as f: st.session_state.cfg = yaml.safe_load(f)
        except Exception:
            st.session_state.cfg = DEFAULT_CFG.copy()
    else:
        st.session_state.cfg = DEFAULT_CFG.copy()

# tax calc utilities
def calc_tax_contrib(taxable, slabs):
    parts=[]; tax=0.0; rem=taxable; lower=0.0
    for s in slabs:
        upto=s.get("upto"); rate=float(s.get("rate",0))/100.0
        if upto is None:
            amt=max(0.0,rem); t=amt*rate; tax+=t; parts.append((f"{lower:+,.0f}+", rate*100, amt, t)); break
        slab_amt = max(0.0, min(rem, float(upto)-lower)); t=slab_amt*rate; tax+=t; parts.append((f"{lower:,.0f}-{float(upto):,.0f}", rate*100, slab_amt, t))
        rem-=slab_amt; lower=float(upto)
        if rem<=0: break
    return parts, tax
def calc_tax(taxable, slabs, cess):
    parts, pre = calc_tax_contrib(taxable, slabs)
    tax = pre + pre*(float(cess)/100.0)
    return max(0.0,tax), parts
def compute(incomes,deductions,cfg):
    total=sum(float(v) for v in incomes.values())
    out={}
    for key,reg in cfg.get("regimes",{}).items():
        dl=reg.get("deduction_limits",{}) or {}
        used=0.0
        for dkey,amt in deductions.items():
            lim=dl.get(dkey,None); a=float(amt)
            used += a if lim is None else min(a, float(lim))
        taxable=max(0.0, total-used)
        tax, parts = calc_tax(taxable, reg.get("slabs",[]), reg.get("cess_percent",4))
        out[key]={"name":reg.get("name",key),"tax":tax,"taxable":taxable,"ded_used":used,"explanation":reg.get("explanation",""),"parts":parts}
    return total, out
def chat_bot_call():
    # Floating Action Button (FAB) on all pages

    # ===== Start local FastAPI backend in a background thread =====
    def _ensure_backend():
        if st.session_state.get("_backend_started"):
            return
        import threading, uvicorn, sys, importlib, time
        sys.path.append(os.path.dirname(__file__))
        # import the app
        from server.app import app as _fastapi_app
        def _run():
            uvicorn.run(_fastapi_app, host="127.0.0.1", port=7860, log_level="warning")

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        # small wait for port to open
        time.sleep(0.5)
        st.session_state["_backend_started"] = True

    _ensure_backend()

    # FAB section removed

# ----- Theme Editor Page -----
if st.query_params.get("page", [None])[0] == "Themes":
    st.title("Theme Editor")
    st.markdown("Create or edit themes. Saved themes are stored in the app DB.")
    col1, col2 = st.columns(2)
    with col1:
        name = st.text_input("Theme name", value="custom-theme")
        bg = st.color_picker("Background color", "#0b0f1a")
        fg = st.color_picker("Foreground color", "#e8eefc")
        accent = st.color_picker("Accent color", "#4f8cff")
        if st.button("Save theme"):
            payload = {"name": name, "config": {"bg": bg, "fg": fg, "accent": accent}}
            try:
                r = requests.post("http://127.0.0.1:8000/theme/save", json=payload, timeout=5)
                st.success("Saved theme")
            except Exception as e:
                st.error("Failed to save theme: "+str(e))
    with col2:
        st.markdown("Existing themes")
        try:
            r = requests.get("http://127.0.0.1:8000/theme/list", timeout=5); j=r.json()
            if j.get("themes"):
                for t in j["themes"]:
                    st.write(t["name"], t["config"])
        except Exception as e:
            st.info("No themes found or failed to fetch: "+str(e))
    st.stop()
