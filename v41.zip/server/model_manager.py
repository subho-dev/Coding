
import os, pathlib, time, threading, shutil
from typing import Optional, Tuple, Dict, Any

MODEL_URLS = {
    "llama-2-7b-chat.ggmlv3.q4_0.bin": "https://huggingface.co/TheBloke/Llama-2-7B-Chat-GGML/resolve/main/llama-2-7b-chat.ggmlv3.q4_0.bin",
    "GPT4All-J.v1.3-groovy.bin": "https://gpt4all.io/models/ggml-gpt4all-j-v1.3-groovy.bin"
}

class LocalLLM:
    def __init__(self, models_dir: str = "models"):
        self.models_dir = pathlib.Path(models_dir)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.primary = self.models_dir / "llama-2-7b-chat.ggmlv3.q4_0.bin"
        self.fallback = self.models_dir / "GPT4All-J.v1.3-groovy.bin"
        # lazy import
        self._llama = None
        self._gpt4all = None
        # background ensure
        threading.Thread(target=self._ensure_models, daemon=True).start()

    def _ensure_models(self):
        for name, url in MODEL_URLS.items():
            dest = self.models_dir / name
            if not dest.exists():
                try:
                    import requests
                    with requests.get(url, stream=True, timeout=60) as r:
                        r.raise_for_status()
                        tmp = dest.with_suffix(".part")
                        with open(tmp, "wb") as f:
                            for chunk in r.iter_content(1024*1024):
                                if chunk:
                                    f.write(chunk)
                        tmp.replace(dest)
                except Exception:
                    # leave for manual download
                    pass

    def models_available(self):
        return [p.name for p in [self.primary, self.fallback] if p.exists()]

    def _load_llama(self):
        if self._llama is not None:
            return self._llama
        try:
            from llama_cpp import Llama
            self._llama = Llama(model_path=str(self.primary), n_ctx=4096, n_threads=4)
        except Exception:
            self._llama = None
        return self._llama

    def _load_gpt4all(self):
        if self._gpt4all is not None:
            return self._gpt4all
        try:
            from gpt4all import GPT4All
            self._gpt4all = GPT4All(model_name=str(self.fallback))
        except Exception:
            self._gpt4all = None
        return self._gpt4all

    def generate(self, prompt: str, system_prompt: str = "", memory: Optional[str] = None) -> Tuple[str,str]:
        ctx = system_prompt
        if memory:
            ctx += f"\nConversation so far:\n{memory}\n---\n"
        # primary
        llm = self._load_llama()
        if llm:
            try:
                out = llm.create_completion(prompt=f"{ctx}\nUser: {prompt}\nAssistant:", max_tokens=256, temperature=0.4)
                txt = out["choices"][0]["text"].strip()
                return txt, "llama-2-7b"
            except Exception:
                pass
        # fallback
        g4a = self._load_gpt4all()
        if g4a:
            try:
                with g4a.chat_session():
                    res = g4a.generate(f"{ctx}\nUser: {prompt}\nAssistant:", max_tokens=256, temp=0.4)
                return res.strip(), "gpt4all-j"
            except Exception:
                pass
        # final simple rule-based
        return "I'm unable to load local models. Please ensure models are downloaded (see README). Meanwhile, ask a specific ITR question.", "rule-based"
