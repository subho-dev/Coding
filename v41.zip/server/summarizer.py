
import json, re, math
from typing import Dict, Any

class SmartSummarizer:
    def __init__(self): pass
    def summarize(self, text: str, meta: Dict[str,Any]=None) -> str:
        # naive but robust: split into sentences, pick top-N via length and simple scoring
        sents = re.split(r'(?<=[.?!])\s+', text.strip())
        if not sents: return "No content to summarize."
        keep = max(3, min(10, len(sents)//4 or 3))
        scored = sorted(sents, key=lambda s: -len(s))
        core = " ".join(scored[:keep])
        note = ""
        if meta:
            note = " (based on provided metadata)"
        return f"Summary{note}: {core}"
