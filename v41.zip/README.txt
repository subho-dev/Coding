
ITR Assistant v24 - Production-ready snapshot
- All requested features merged: dynamic schema downloads, schema-aware assistant, editable regime manager table,
  theme manager fixed, autopilot helper, newsletter, detailed PDF.
- Uses webdriver-manager to fetch chromedriver at runtime. If you want a binary included, upload exact chromedriver for your OS & Chrome.
Run:
1) python -m venv .venv
2) source .venv/bin/activate   # Windows: .venv\Scripts\activate
3) pip install -r requirements.txt
4) streamlit run app_streamlit_itr_only_v24.py


## Offline Chatbot Models (auto-download on first run)
- Primary: `llama-2-7b-chat.ggmlv3.q4_0.bin` (Llama 2 license required)
  Manual download: https://huggingface.co/TheBloke/Llama-2-7B-Chat-GGML
  Place in `models/` if auto-download fails.
- Fallback: `GPT4All-J.v1.3-groovy.bin`
  Manual download: https://gpt4all.io/models/ggml-gpt4all-j-v1.3-groovy.bin
  Place in `models/`.

## FastAPI Chat Backend
The Streamlit app auto-starts a FastAPI server on port 8000 that serves `/chat`. No paid APIs.

## Voice (Optional)
Vosk small English model auto-downloads in background to `models/vosk/`. TTS via `pyttsx3` offline.




## Login / Signup / Guest access
- The app provides Signup (`/signup`), Login (`/login`) and Guest login (`/guest_login`) via the top-right Login button.
- User information is stored in `data/users.sqlite3` (auto-created). Passwords are hashed with per-user salt.
- After login, a profile icon appears on the top-right. Click it to edit your full name (quick inline). The profile is stored in DB.
- To prefill ITR fields from a profile, you can navigate to the app with `?_user=username` to auto-load the profile on load (useful for testing).

## Troubleshooting
- If FastAPI doesn't start: check console for `uvicorn` errors. Ensure `uvicorn` is installed (`pip install uvicorn fastapi`). On some systems port 8000 may be in use—change the port in `app_streamlit_itr_only_v30.py` where uvicorn is launched.
- If models don't auto-download: check network & that `models/` is writable. Manual download links are in the top of README.
- If OCR or pdf parsing fails, ensure `pytesseract` and `pdfminer.six` are installed and `tesseract` executable is in PATH for OCR.
