#!/usr/bin/env python3
"""Offline voice bridge using Vosk + pyttsx3 (free). Serves ws://127.0.0.1:2700/ws and auto-downloads small model."""
import asyncio, json, pathlib, zipfile, io, shutil, threading
from websockets import serve
MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
BASE = pathlib.Path(__file__).parent.resolve()
MODELDIR = BASE / "vosk_model"
READY_FLAG = BASE / "vosk_ready.txt"
def ensure_model():
    if MODELDIR.exists() and any(MODELDIR.iterdir()):
        READY_FLAG.write_text("ok"); return
    def _bg():
        try:
            import urllib.request
            with urllib.request.urlopen(MODEL_URL) as r: data=r.read()
            z=zipfile.ZipFile(io.BytesIO(data)); tmp=BASE/'_vosk_tmp'; shutil.rmtree(tmp, ignore_errors=True); tmp.mkdir(parents=True, exist_ok=True)
            z.extractall(tmp); inner=next(tmp.iterdir()); shutil.rmtree(MODELDIR, ignore_errors=True); shutil.move(str(inner), str(MODELDIR)); shutil.rmtree(tmp, ignore_errors=True); READY_FLAG.write_text("ok")
        except Exception as e:
            print("Model download failed:", e)
    threading.Thread(target=_bg, daemon=True).start()
ensure_model()
async def ws_handler(websocket):
    await websocket.send(json.dumps({"type":"hello","offline_ready": READY_FLAG.exists()}))
    try:
        import vosk, sounddevice as sd
        if READY_FLAG.exists():
            model=vosk.Model(str(MODELDIR)); rec=vosk.KaldiRecognizer(model,16000); rec.SetWords(True); sd.default.samplerate=16000; sd.default.channels=1
            await websocket.send(json.dumps({"type":"status","msg":"listening"}))
            with sd.RawInputStream(samplerate=16000, blocksize=8000, dtype='int16', channels=1) as stream:
                while True:
                    data=stream.read(8000)[0]
                    if rec.AcceptWaveform(data): await websocket.send(rec.Result())
                    else: await websocket.send(rec.PartialResult())
        else:
            await websocket.send(json.dumps({"type":"status","msg":"model_downloading"}))
            while True: await asyncio.sleep(2)
    except Exception as e:
        await websocket.send(json.dumps({"type":"error","error":str(e)}))
async def main():
    async with serve(ws_handler, "127.0.0.1", 2700, ping_interval=None):
        print("Vosk bridge: ws://127.0.0.1:2700/ws"); await asyncio.Future()
if __name__=="__main__": import asyncio; asyncio.run(main())