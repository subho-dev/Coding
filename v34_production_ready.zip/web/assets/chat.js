(function () {
  const root = document.getElementById("chat-root");
  if (!root) {
    console.error("Chat root not found");
    return;
  }
  const opts = window.CB_OPTIONS || {};
  const apiBase = opts.apiBase || "http://127.0.0.1:7860/api";
  const mode = opts.mode || "popup";
  const title = opts.title || "Assistant";

  // simple UI
  const container = document.createElement("div");
  container.className = "chat-container " + mode;
  container.innerHTML = `
    <div class="chat-header">${title}</div>
    <div class="chat-body"></div>
    <div class="chat-input">
      <textarea placeholder="Ask me anything..."></textarea>
      <button>Send</button>
    </div>
  `;
  root.appendChild(container);
  const body = container.querySelector(".chat-body");
  const textarea = container.querySelector("textarea");
  const btn = container.querySelector("button");

  function addMsg(text, cls){
    const m = document.createElement("div"); m.className="msg "+cls; m.innerText=text; body.appendChild(m); body.scrollTop=body.scrollHeight;
  }

  async function send(){
    const t = textarea.value.trim(); if(!t) return;
    addMsg(t, "user"); textarea.value="";
    const bot = document.createElement("div"); bot.className="msg bot"; bot.innerText="Thinking..."; body.appendChild(bot); body.scrollTop=body.scrollHeight;
    try{
      const r = await fetch(apiBase + "/chat", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({message:t})});
      if(!r.ok){ bot.innerText = "Error: "+r.statusText; return; }
      const d = await r.json();
      bot.innerText = d.reply || "(no reply)";
    }catch(e){ bot.innerText = "Error: "+e.message; }
  }
  btn.addEventListener("click", send);
  textarea.addEventListener("keydown", (e)=>{ if(e.key==="Enter" && !e.shiftKey){ e.preventDefault(); send(); }});
})();