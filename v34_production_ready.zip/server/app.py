
import os, re, json, asyncio, time
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse, Response, FileResponse
from pydantic import BaseModel
import traceback

# Simple CA knowledge base - can be extended
KB = [
    {"q":"what is gst registration", "a":"GST registration is required for businesses with turnover above threshold. In India, threshold is ₹20 lakh for most states. Consult local laws."},
    {"q":"how to compute depreciation", "a":"Depreciation can be computed using Straight Line Method or Written Down Value. Formula (SLM): (Cost - Salvage)/Useful life."},
    {"q":"what is tds", "a":"TDS stands for Tax Deducted at Source. It is an amount withheld at the time of payment to vendors/contractors and deposited to government."},
]

app = FastAPI(title="Local Chatbot Backend for CA", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class ChatRequest(BaseModel):
    messages: list = None
    message: str = None
    stream: bool = False
    system_prompt: str = None

def match_kb(text):
    import difflib
    choices = [k["q"] for k in KB]
    m = difflib.get_close_matches(text.lower(), choices, n=1, cutoff=0.4)
    if m:
        for k in KB:
            if k["q"]==m[0]:
                return k["a"]
    return None

def _safe_eval_math(expr):
    try:
        import sympy as sp
        x=sp.sympify(expr)
        return str(sp.simplify(x))
    except Exception as e:
        return "[math error] "+str(e)

def _run_python(code, timeout=3.0):
    import multiprocessing as mp, sys, traceback, io, contextlib
    def target(code, q):
        try:
            buf=io.StringIO()
            gl={"__builtins__": {"print": print, "range": range, "len": len, "int": int, "float": float}}
            with contextlib.redirect_stdout(buf):
                exec(code, gl, {})
            q.put(buf.getvalue() or "[no output]")
        except Exception as e:
            q.put("ERROR: "+str(e))
    q=mp.Queue()
    p=mp.Process(target=target, args=(code,q))
    p.start()
    p.join(timeout)
    if p.is_alive():
        p.terminate()
        return "ERROR: execution timed out"
    try:
        return q.get_nowait()
    except Exception:
        return "[no output]"

@app.get("/api/health")
async def health():
    return {"status":"ok"}

@app.post("/api/chat")
async def chat(req: ChatRequest):
    try:
        text = ""
        if req.message:
            text = req.message
        elif req.messages and len(req.messages)>0:
            text = req.messages[-1].get("content","")
        text = text.strip()
        # math detection
        if text.startswith("=") or re.search(r"\bsolve\b|\bintegrate\b|\bderive\b|\d+\s*[\+\-\*\/]\s*\d+", text.lower()):
            expr = text.lstrip("=").strip()
            res = _safe_eval_math(expr)
            return JSONResponse({"reply": "**Result:** "+res})
        # code detection
        m = re.search(r"```(?:python)?\n([\s\S]*?)```", text)
        if m:
            code = m.group(1)
            out = _run_python(code)
            return JSONResponse({"reply": "**Output:**\n```\n"+out+"\n```"})
        # KB match
        kb = match_kb(text)
        if kb:
            return JSONResponse({"reply": kb})
        # fallback heuristic
        # simple templated CA responder
        if "gst" in text.lower():
            return JSONResponse({"reply":"GST is a tax for goods and services. For specifics, provide the country and turnover."})
        if "tds" in text.lower():
            return JSONResponse({"reply":"TDS is tax deducted at source. Please provide context (salary, contractor, rent) for precise rates."})
        # otherwise generic helpful answer
        reply = "I'm a local CA assistant. I can answer accounting/tax questions, do symbolic math `= expr`, or run python code in fenced blocks. Example: `= 2*(3+4)` or ```python\\nprint(2+2)\\n```"
        return JSONResponse({"reply": reply})
    except Exception as e:
        return JSONResponse({"reply":"[error] "+str(e)})

@app.post("/api/export_pdf")
async def export_pdf(req: ChatRequest):
    try:
        msgs = req.messages or []
        # create PDF
        from reportlab.lib.pagesizes import letter
        from reportlab.pdfgen import canvas
        import io, datetime
        buf = io.BytesIO()
        c = canvas.Canvas(buf, pagesize=letter)
        width, height = letter
        y = height - 50
        c.setFont("Helvetica-Bold", 14)
        c.drawString(40, y, "Chat Export - ASK THE CA")
        y -= 30
        c.setFont("Helvetica", 10)
        for m in msgs:
            role = m.get("role","user")
            text = m.get("content","")
            lines = text.splitlines()
            for line in lines:
                if y < 60:
                    c.showPage()
                    y = height - 50
                c.drawString(40, y, f"{role.upper()}: {line}")
                y -= 14
            y -= 6
        c.showPage()
        c.save()
        buf.seek(0)
        return Response(content=buf.read(), media_type="application/pdf", headers={"Content-Disposition":"attachment; filename=chat_export.pdf"})
    except Exception as e:
        return JSONResponse({"error": str(e)})
