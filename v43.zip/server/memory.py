
import os, sqlite3, re, json
from typing import Dict, Any

class BotMemory:
    def __init__(self, db_path="data/chatbot_memory.sqlite3"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._init()

    def _init(self):
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS facts (user TEXT, key TEXT, val TEXT, PRIMARY KEY(user,key))")
        cur.execute("CREATE TABLE IF NOT EXISTS turns (user TEXT, role TEXT, text TEXT, ts DATETIME DEFAULT CURRENT_TIMESTAMP)")
        con.commit(); con.close()

    def extract_and_store(self, user: str, text: str):
        facts = {}
        m = re.search(r"\bpan\s+is\s*([A-Z]{5}[0-9]{4}[A-Z])\b", text, re.I)
        if m: facts["PAN"] = m.group(1).upper()
        m = re.search(r"\bname\s+is\s*([A-Za-z ]{3,})$", text.strip(), re.I)
        if m: facts["name"] = m.group(1).strip()
        if facts:
            con = sqlite3.connect(self.db_path); cur = con.cursor()
            for k,v in facts.items():
                cur.execute("INSERT OR REPLACE INTO facts(user,key,val) VALUES(?,?,?)",(user,k,v))
            con.commit(); con.close()
        return facts

    def load(self, user: str) -> str:
        con = sqlite3.connect(self.db_path); cur = con.cursor()
        cur.execute("SELECT key,val FROM facts WHERE user=?",(user,))
        rows = cur.fetchall(); con.close()
        return "\n".join([f"{k}: {v}" for k,v in rows])

    def append_turn(self, user: str, role: str, text: str):
        con = sqlite3.connect(self.db_path); cur = con.cursor()
        cur.execute("INSERT INTO turns(user,role,text) VALUES(?,?,?)",(user,role,text))
        con.commit(); con.close()
