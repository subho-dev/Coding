# CA Chatbot v29 — Popup/Full + Docked + Voice + Summarizer
See INTEGRATE_SNIPPET.html for the 2-line include. Features:
- Popup or Full Page via `?chatbot=popup|full` or `CAChatbotV29.setMode(...)`
- Minimized dock with badge + pulse; auto-minimize after 1 min
- Demo Mode (Ctrl+D), persistent; banner + DEMO badge
- Voice (browser speech) + optional offline (Vosk). Free only.
- File summarizer for JSON/XML/YAML/PDF/Image
- Dark/Light switcher; animated loader & toasts; global FAB; Ctrl+Shift+C
### Offline voice helper
pip install websockets vosk sounddevice pyttsx3 numpy
python chatbot_v29/voice_server.py
### Optional summarizer API (for better PDFs)
pip install fastapi uvicorn PyPDF2 pyyaml
python chatbot_v29/summarizer_service.py
