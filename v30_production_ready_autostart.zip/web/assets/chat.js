(function(){
  const el = (sel, root=document)=>root.querySelector(sel);
  function md(text){return text.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/```([\s\S]*?)```/g,'<pre><code>$1</code></pre>');}
  async function send(apiBase, messages, stream=true){
    const resp = await fetch(apiBase + "/chat", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({messages, stream})});
    if(stream){
      const reader = resp.body.getReader(); const decoder = new TextDecoder();
      return {async *[Symbol.asyncIterator](){while(true){const {value, done}=await reader.read(); if(done) break; yield decoder.decode(value,{stream:true});}}};
    } else { const data=await resp.json(); return data.text; }
  }
  function makeUI(root, opts){
    const panel=document.createElement("div"); panel.className="cb-panel";
    const header=document.createElement("div"); header.className="cb-header";
    const htitle=document.createElement("div"); htitle.className="cb-title"; htitle.textContent=opts.title||"Assistant";
    const close=document.createElement("button"); close.textContent="×"; close.onclick=()=>panel.classList.remove("open");
    header.append(htitle, close);
    const body=document.createElement("div"); body.className="cb-body";
    const inputWrap=document.createElement("div"); inputWrap.className="cb-input";
    const input=document.createElement("input"); input.placeholder="Ask CA, maths, or code…";
    const sendBtn=document.createElement("button"); sendBtn.textContent="Send"; inputWrap.append(input, sendBtn);
    panel.append(header, body, inputWrap);
    if(opts.mode==="inline"){ panel.classList.add("cb-inline"); root.append(panel); }
    else if(opts.mode==="fullscreen"){ panel.classList.add("cb-full","open"); root.append(panel); }
    else { const launch=document.createElement("button"); launch.className="cb-launch"; launch.textContent="Chat"; document.body.append(launch, panel); launch.onclick=()=>panel.classList.toggle("open"); }
    const messages=[];
    async function handleSend(){
      const content=input.value.trim(); if(!content) return;
      messages.push({role:"user",content}); const um=document.createElement("div"); um.className="cb-msg user"; um.textContent=content; body.append(um); input.value="";
      const bm=document.createElement("div"); bm.className="cb-msg bot"; bm.innerHTML="…"; body.append(bm); body.scrollTop=body.scrollHeight;
      try{ const iter=await send(opts.apiBase,messages,true); let acc=""; for await(const chunk of iter){ acc+=chunk; bm.innerHTML=md(acc); body.scrollTop=body.scrollHeight; } messages.push({role:"assistant",content:acc}); }catch(e){ bm.textContent="Error: "+e.message; }
    }
    sendBtn.onclick=handleSend; input.addEventListener("keydown",(e)=>{if(e.key==="Enter") handleSend();});
  }
  window.Chatbot={mount(target, opts){ const root=typeof target==="string"?el(target):target; makeUI(root, opts||{apiBase:"/api"});}}
})();