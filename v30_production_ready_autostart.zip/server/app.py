# FastAPI backend launched automatically by Streamlit
import os, re, json, asyncio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel

app = FastAPI(title="Local Chatbot Backend", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class ChatRequest(BaseModel):
    messages: list
    stream: bool = True
    system_prompt: str | None = None

def _safe_eval_math(expr: str) -> str:
    try:
        import sympy as sp
        x = sp.sympify(expr)
        return str(sp.simplify(x))
    except Exception as e:
        return f"[math engine error] {e}"

def _run_python(code: str, time_limit_sec: float = 3.0) -> str:
    import multiprocessing as mp
    def _target(code, out):
        try:
            import io, contextlib
            buf = io.StringIO()
            rglobals = {"__builtins__": {"print": print, "range": range, "len": len, "str": str, "int": int, "float": float}}
            with contextlib.redirect_stdout(buf):
                exec(code, rglobals, {})
            out.put(buf.getvalue() or "[no output]")
        except Exception as e:
            out.put("ERROR: " + str(e))
    q = mp.Queue()
    p = mp.Process(target=_target, args=(code, q))
    p.start()
    p.join(timeout=time_limit_sec)
    if p.is_alive():
        p.terminate()
        return "ERROR: execution timed out"
    try:
        return q.get_nowait()
    except Exception:
        return "[no output]"

def _local_reasoner(messages: list[dict]):
    import re
    user_text = ""
    for m in reversed(messages):
        if m.get("role") == "user":
            user_text = m.get("content", "")
            break
    if re.search(r"^=|[*/+\-]|\bsolve\b|\bderive\b|\bintegrate\b", user_text):
        result = _safe_eval_math(user_text.replace("=", "").strip())
        yield f"**Result:** {result}"
        return
    code_match = re.search(r"```(?:python)?\n([\s\S]*?)```", user_text)
    if code_match:
        code = code_match.group(1)
        output = _run_python(code)
        yield f"**Output:**\n```
{output}
```"
        return
    yield "I can help with Chartered Accounting, maths, and Python. Try `= 2*(3+4)^2` or:
```python\nprint(2+2)\n```"

@app.get("/api/health")
def health():
    return {"status":"ok"}

@app.post("/api/chat")
def chat(body: ChatRequest):
    def token_stream_local():
        for tok in _local_reasoner(body.messages):
            yield tok
    if body.stream:
        return StreamingResponse(token_stream_local(), media_type="text/plain")
    else:
        text = "".join(list(_local_reasoner(body.messages)))
        return JSONResponse({"text": text})
