
import os, threading, time, sqlite3, json, re, queue
from typing import Dict, Any, Optional, List
from fastapi import FastAPI
from pydantic import BaseModel
from starlette.middleware.cors import CORSMiddleware

# Lightweight semantic + rule-based engine with optional local LLMs
from .model_manager import LocalLLM
from .memory import BotMemory
from .summarizer import SmartSummarizer

app = FastAPI(title="ITR Assistant Chat Backend", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_mem = BotMemory(db_path=os.environ.get("CHATBOT_DB","data/chatbot_memory.sqlite3"))
_llm = LocalLLM(models_dir=os.environ.get("MODELS_DIR","models"))
_sum = SmartSummarizer()

class ChatIn(BaseModel):
    session_id: str
    message: str
    context: Optional[Dict[str, Any]] = None

class ChatOut(BaseModel):
    reply: str
    used_model: str
    memory_events: List[str] = []

@app.get("/health")
def health():
    return {"status":"ok","models":_llm.models_available()}

@app.post("/chat", response_model=ChatOut)
def chat(inp: ChatIn):
    user = inp.session_id or "default"
    msg = inp.message.strip()
    memory_events = []
    # Learn simple facts: "My PAN is ....", "My name is ...."
    facts = _mem.extract_and_store(user, msg)
    if facts:
        memory_events.append(f"learned: {', '.join([f'{k}={v}' for k,v in facts.items()])}")
    # Retrieve memory
    memo = _mem.load(user)
    # If the message looks like "summarize file: <path or name>"
    if re.search(r"\bsummar(i[sz]e|y)\b", msg, re.I):
        # The frontend should send content via context (raw_text or structured)
        ctx = inp.context or {}
        text = ctx.get("raw_text") or ""
        meta = {k:v for k,v in ctx.items() if k!="raw_text"}
        if text:
            reply = _sum.summarize(text, meta=meta)
            return ChatOut(reply=reply, used_model="summarizer", memory_events=memory_events)
    # Default: try LLM with fallback
    sys_context = (
        "You are ITR Assistant Chatbot. Be concise, factual. "
        "Ask targeted clarifying questions when the query is ambiguous. "
        "Prefer Indian Income Tax context when relevant."
    )
    reply, used = _llm.generate(msg, system_prompt=sys_context, memory=memo)
    # Store the conversation
    _mem.append_turn(user, "user", msg)
    _mem.append_turn(user, "assistant", reply)
    return ChatOut(reply=reply, used_model=used, memory_events=memory_events)
