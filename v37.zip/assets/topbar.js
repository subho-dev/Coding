
(function(){
  const root = document.createElement('div');
  root.innerHTML = `
    <div class="itrtopbar">
      <div class="left">
        <button class="btn" id="callbtn">📞 Call</button>
        <select id="langsel">
          <option value="en">English</option>
          <option value="hi">हिन्दी</option>
        </select>
        <select id="themesel">
          <option value="auto">Theme</option>
          <option value="neo-dark">Neo Dark</option>
          <option value="ocean">Ocean</option>
          <option value="sunrise">Sunrise</option>
        </select>
      </div>
      <div class="right">
        <button class="btn" id="chatbtn">💬 Chatbot</button>
      </div>
    </div>
    <div class="chat-overlay" id="overlay">
      <div class="chat-modal" id="chatmodal">
        <div class="chat-header">
          <div>ITR Assistant Chat</div>
          <div>
            <button id="minbtn">_</button>
            <button id="closebtn">×</button>
          </div>
        </div>
        <div class="chat-body" id="chatbody"></div>
        <div class="chat-input">
          <input id="chattext" placeholder="Type your question..." style="flex:1">
          <button id="sendbtn">Send</button>
        </div>
      </div>
    </div>
    <button class="fcb btn" id="fcb">💬</button>
  `;
  document.body.appendChild(root);
  const overlay = document.getElementById('overlay');
  const modal = document.getElementById('chatmodal');
  const chatbtn = document.getElementById('chatbtn');
  const fcb = document.getElementById('fcb');
  const minbtn = document.getElementById('minbtn');
  const closebtn = document.getElementById('closebtn');
  const body = document.getElementById('chatbody');
  const text = document.getElementById('chattext');
  const send = document.getElementById('sendbtn');
  let idleTimer=null, longTimer=null;

  function openChat(){
    overlay.style.display='block';
    fcb.style.display='none';
    resetTimers();
  }
  function minimize(){
    overlay.style.display='none';
    fcb.style.display='flex';
    fcb.classList.add('active');
    clearTimers();
    idleTimer = setTimeout(()=>{ /* still active indicator */ }, 30*1000);
    longTimer = setTimeout(()=>{
      fcb.style.display='none';
      fcb.classList.remove('active');
      body.innerHTML='';
    }, 5*60*1000);
  }
  function closeChat(){
    overlay.style.display='none';
    fcb.style.display='none';
    body.innerHTML='';
    fcb.classList.remove('active');
    clearTimers();
  }
  function clearTimers(){ if (idleTimer) clearTimeout(idleTimer); if (longTimer) clearTimeout(longTimer); }
  function resetTimers(){ clearTimers(); idleTimer=setTimeout(minimize, 30*1000); longTimer=setTimeout(closeChat, 5*60*1000); }

  chatbtn.onclick=openChat;
  fcb.onclick=openChat;
  minbtn.onclick=minimize;
  closebtn.onclick=closeChat;
  overlay.addEventListener('click', (e)=>{ if(e.target===overlay) minimize(); });
  modal.addEventListener('click', (e)=>e.stopPropagation());

  // Draggable FCB
  fcb.onmousedown = function(e){
    let sX=e.clientX, sY=e.clientY;
    const r = fcb.getBoundingClientRect();
    let oX=r.left, oY=r.top;
    function mm(ev){
      let nx = oX + (ev.clientX - sX);
      let ny = oY + (ev.clientY - sY);
      fcb.style.left = nx+'px';
      fcb.style.top = ny+'px';
      fcb.style.right = 'auto';
      fcb.style.bottom = 'auto';
      fcb.style.position='fixed';
    }
    function mu(){ document.removeEventListener('mousemove',mm); document.removeEventListener('mouseup',mu); }
    document.addEventListener('mousemove',mm); document.addEventListener('mouseup',mu);
  }

  function addBubble(t, who){
    const d = document.createElement('div');
    d.style.padding='6px 10px'; d.style.margin='8px'; d.style.borderRadius='10px';
    d.style.maxWidth='85%';
    if(who==='user'){ d.style.background='#1e293b'; d.style.marginLeft='auto'; }
    else { d.style.background='#0b1324'; d.style.marginRight='auto'; }
    d.textContent=t; body.appendChild(d); body.scrollTop = body.scrollHeight;
  }

  // Animated typing while fetching
  function showTyping(){
    const d = document.createElement('div'); d.className='typing';
    let dots=0; d.textContent='Thinking';
    const iv=setInterval(()=>{ dots=(dots+1)%4; d.textContent='Thinking'+'.'.repeat(dots); }, 400);
    body.appendChild(d); body.scrollTop = body.scrollHeight;
    return ()=>{ clearInterval(iv); d.remove(); };
  }

  async function sendMsg(){
    const m = text.value.trim(); if(!m) return;
    addBubble(m,'user'); text.value=''; resetTimers();
    const stopTyping = showTyping();
    try {
      const session = (window.stSessionId || 'default');
      const r = await fetch('/chat', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({session_id: session, message: m})
      });
      const j = await r.json();
      stopTyping();
      addBubble(j.reply || 'No reply', 'bot');
    } catch(e){
      stopTyping();
      addBubble('Error contacting chatbot backend.', 'bot');
    }
  }
  send.onclick=sendMsg; text.addEventListener('keydown', (e)=>{ if(e.key==='Enter') sendMsg(); });

  // Call button
  const callbtn = document.getElementById('callbtn');
  callbtn.onclick = ()=>{
    const num = window.stCallNumber || '';
    if(num){ window.location.href = 'tel:'+num; }
    callbtn.classList.add('active'); setTimeout(()=>callbtn.classList.remove('active'), 1200);
  };

  
  const dict = {
    en: {"ITR Assistant Chat":"ITR Assistant Chat","Type your question...":"Type your question...","Send":"Send","Chatbot":"Chatbot","Call":"Call"},
    hi: {"ITR Assistant Chat":"आईटीआर सहायक चैट","Type your question...":"अपना प्रश्न लिखें...","Send":"भेजें","Chatbot":"चैटबॉट","Call":"कॉल"}
  };
  function applyLang(lang){
    const map = dict[lang]||dict.en;
    document.querySelectorAll('*').forEach(el=>{
      if(map[el.innerText]) el.innerText = map[el.innerText];
      if(el.placeholder && map[el.placeholder]) el.placeholder = map[el.placeholder];
    });
  }
  document.getElementById('langsel').addEventListener('change', (e)=>{
    applyLang(e.target.value);
  });
  // apply default once
  applyLang('en');

// Language selector emits an event picked by Streamlit
  document.getElementById('langsel').onchange = (e)=>{
    fetch('/_lang?'+new URLSearchParams({lang: e.target.value}));
  };

  // Theme selector
  document.getElementById('themesel').onchange = (e)=>{
    fetch('/_theme?'+new URLSearchParams({theme: e.target.value}));
  };

  // Expose toggles
  document.addEventListener('mousemove', resetTimers, {passive:true});
  document.addEventListener('keydown', resetTimers, {passive:true});
  // Show FCB by default
  fcb.style.display='flex';
})();
