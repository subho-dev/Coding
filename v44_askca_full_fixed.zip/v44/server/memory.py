import os, sqlite3, re, json
from typing import Dict, Any, List, Tuple

class BotMemory:
    def __init__(self, db_path="data/chatbot_memory.sqlite3"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._init()

    def _init(self):
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS facts (user TEXT, key TEXT, val TEXT, PRIMARY KEY(user,key))")
        cur.execute("""CREATE TABLE IF NOT EXISTS turns (
            user TEXT, role TEXT, text TEXT, ts REAL DEFAULT (strftime('%s','now'))
        )""")
        con.commit(); con.close()

    def extract_and_store(self, user: str, text: str) -> Dict[str,str]:
        """Very naive extractor for simple self-claims like 'my pan is ABCD...'"""
        facts = {}
        try:
            # PAN pattern (not strict)
            m = re.search(r"\bpan\s+is\s*[:\-]?\s*([A-Z0-9]{8,10})\b", text, re.I)
            if m:
                facts['PAN'] = m.group(1).upper()
            m2 = re.search(r"\bmy\s+name\s+is\s*[:\-]?\s*([A-Za-z\s]{2,50})\b", text, re.I)
            if m2:
                facts['Name'] = m2.group(1).strip().title()
            if facts:
                con = sqlite3.connect(self.db_path); cur = con.cursor()
                for k,v in facts.items():
                    cur.execute("INSERT OR REPLACE INTO facts(user,key,val) VALUES(?,?,?)", (user,k,v))
                con.commit(); con.close()
        except Exception:
            pass
        return facts

    def load(self, user: str) -> str:
        con = sqlite3.connect(self.db_path); cur = con.cursor()
        cur.execute("SELECT key,val FROM facts WHERE user=?", (user,))
        rows = cur.fetchall(); con.close()
        return "\n".join([f"{k}: {v}" for k,v in rows])

    def append_turn(self, user: str, role: str, text: str):
        con = sqlite3.connect(self.db_path); cur = con.cursor()
        cur.execute("INSERT INTO turns(user,role,text) VALUES(?,?,?)", (user, role, text))
        con.commit(); con.close()

    def history(self, user: str, limit: int = 100) -> List[Tuple[str,str,float]]:
        con = sqlite3.connect(self.db_path); cur = con.cursor()
        cur.execute("SELECT role, text, ts FROM turns WHERE user=? ORDER BY ts ASC LIMIT ?", (user, limit))
        rows = cur.fetchall(); con.close()
        return rows
