
import os, threading, time, sqlite3, json, re, queue
from typing import Dict, Any, Optional, List
from fastapi import FastAPI
from pydantic import BaseModel
from starlette.middleware.cors import CORSMiddleware

# Lightweight semantic + rule-based engine with optional local LLMs
from .model_manager import LocalLLM
from .memory import BotMemory
from .summarizer import SmartSummarizer

# Session and app DB initialization (generalized connection)
APP_DB = os.environ.get("APP_DB", "data/app.db")
def get_db_conn(path=APP_DB):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

# Initialize core tables: users (if not exists), profiles, itr_data, themes, sessions, guest_temp
def init_app_db():
    conn = get_db_conn()
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY, password_hash TEXT, salt TEXT, email TEXT, full_name TEXT, phone TEXT, data TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS profiles (
        username TEXT PRIMARY KEY, email TEXT, full_name TEXT, phone TEXT, data TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS itr_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, key TEXT, value TEXT, transient INTEGER DEFAULT 0
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS themes (
        name TEXT PRIMARY KEY, config TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS sessions (
        session_id TEXT PRIMARY KEY, username TEXT, guest INTEGER DEFAULT 0, ts DATETIME DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.commit(); conn.close()

init_app_db()

app = FastAPI(title="ITR Assistant Chat Backend", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_mem = BotMemory(db_path=os.environ.get("CHATBOT_DB","data/chatbot_memory.sqlite3"))
_llm = LocalLLM(models_dir=os.environ.get("MODELS_DIR","models"))
_sum = SmartSummarizer()

class ChatIn(BaseModel):
    session_id: str
    message: str
    context: Optional[Dict[str, Any]] = None

class ChatOut(BaseModel):
    reply: str
    used_model: str
    memory_events: List[str] = []

@app.get("/health")
def health():
    return {"status":"ok","models":_llm.models_available()}

@app.post("/chat", response_model=ChatOut)
def chat(inp: ChatIn):
    user = inp.session_id or "default"
    msg = inp.message.strip()
    memory_events = []
    # Learn simple facts: "My PAN is ....", "My name is ...."
    facts = _mem.extract_and_store(user, msg)
    if facts:
        memory_events.append(f"learned: {', '.join([f'{k}={v}' for k,v in facts.items()])}")
    # Retrieve memory
    memo = _mem.load(user)
    # If the message looks like "summarize file: <path or name>"
    if re.search(r"\bsummar(i[sz]e|y)\b", msg, re.I):
        # The frontend should send content via context (raw_text or structured)
        ctx = inp.context or {}
        text = ctx.get("raw_text") or ""
        meta = {k:v for k,v in ctx.items() if k!="raw_text"}
        if text:
            reply = _sum.summarize(text, meta=meta)
            return ChatOut(reply=reply, used_model="summarizer", memory_events=memory_events)
    # Default: try LLM with fallback
    sys_context = (
        "You are ITR Assistant Chatbot. Be concise, factual. "
        "Ask targeted clarifying questions when the query is ambiguous. "
        "Prefer Indian Income Tax context when relevant."
    )
    reply, used = _llm.generate(msg, system_prompt=sys_context, memory=memo)
    # Store the conversation
    _mem.append_turn(user, "user", msg)
    _mem.append_turn(user, "assistant", reply)
    return ChatOut(reply=reply, used_model=used, memory_events=memory_events)


# --- Simple user auth (sqlite) ---
USERS_DB = os.environ.get("USERS_DB", "data/users.sqlite3")
def _init_users():
    os.makedirs(os.path.dirname(USERS_DB), exist_ok=True)
    con = sqlite3.connect(USERS_DB)
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY, password_hash TEXT, salt TEXT, email TEXT, full_name TEXT, phone TEXT, data JSON
    )""")
    con.commit(); con.close()
_init_users()

import hashlib, secrets, json as _json

def _hash_password(password, salt):
    return hashlib.sha256((salt+password).encode('utf-8')).hexdigest()

@app.post("/signup")
def signup(info: Dict[str,str]):
    username = info.get("username","").strip().lower()
    password = info.get("password","")
    if not username or not password:
        return {"ok":False, "error":"Username and password required."}
    con = sqlite3.connect(USERS_DB); cur = con.cursor()
    cur.execute("SELECT username FROM users WHERE username=?", (username,))
    if cur.fetchone():
        con.close(); return {"ok":False, "error":"User already exists."}
    salt = secrets.token_hex(8)
    ph = _hash_password(password, salt)
    cur.execute("INSERT INTO users(username,password_hash,salt,email,full_name,phone,data) VALUES(?,?,?,?,?,?,?)",
                (username, ph, salt, info.get("email",""), info.get("full_name",""), info.get("phone",""), _json.dumps({})))
    con.commit(); con.close()
    return {"ok":True, "username": username}

@app.post("/login")
def login(info: Dict[str,str]):
    username = info.get("username","").strip().lower()
    password = info.get("password","")
    if not username or not password:
        return {"ok":False, "error":"Username and password required."}
    con = sqlite3.connect(USERS_DB); cur = con.cursor()
    cur.execute("SELECT password_hash,salt,email,full_name,phone,data FROM users WHERE username=?", (username,))
    row = cur.fetchone(); con.close()
    if not row:
        return {"ok":False, "error":"Invalid username or password."}
    ph, salt, email, full_name, phone, data = row
    if _hash_password(password, salt) != ph:
        return {"ok":False, "error":"Invalid username or password."}
    return {"ok":True, "username": username, "email": email, "full_name": full_name, "phone": phone, "data": json.loads(data or "{}")}

@app.post("/guest_login")
def guest_login(info: Dict[str,str] = {}):
    # returns a temporary guest id
    gid = "guest_" + secrets.token_hex(6)
    return {"ok":True, "username": gid}

@app.get("/profile/{username}")
def get_profile(username: str):
    con = sqlite3.connect(USERS_DB); cur = con.cursor()
    cur.execute("SELECT username,email,full_name,phone,data FROM users WHERE username=?", (username,))
    row = cur.fetchone(); con.close()
    if not row: return {"ok":False, "error":"User not found."}
    u, email, full_name, phone, data = row
    return {"ok":True, "username":u, "email":email, "full_name":full_name, "phone":phone, "data": json.loads(data or "{}")}

@app.post("/profile/{username}")
def update_profile(username: str, info: Dict[str,str]):
    con = sqlite3.connect(USERS_DB); cur = con.cursor()
    cur.execute("SELECT username FROM users WHERE username=?", (username,))
    if not cur.fetchone():
        con.close(); return {"ok":False, "error":"User not found."}
    # update fields
    cur.execute("UPDATE users SET email=?, full_name=?, phone=?, data=? WHERE username=?",
                (info.get("email",""), info.get("full_name",""), info.get("phone",""), json.dumps(info.get("data",{})), username))
    con.commit(); con.close()
    return {"ok":True}


from fastapi import Request
@app.post("/_session")
def set_session(payload: Dict[str,Any]):
    sid = payload.get("session_id") or secrets.token_hex(12)
    username = payload.get("username")
    guest = 1 if payload.get("guest") else 0
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO sessions(session_id, username, guest) VALUES(?,?,?)", (sid, username, guest))
    conn.commit(); conn.close()
    return {"ok":True, "session_id": sid}

@app.get("/_session")
def get_session():
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute("SELECT session_id, username, guest FROM sessions ORDER BY ROWID DESC LIMIT 1")
    r = cur.fetchone(); conn.close()
    if not r: return {"username": None}
    return {"username": r["username"], "session_id": r["session_id"], "guest": bool(r["guest"])}

@app.post("/logout")
def logout(payload: Dict[str,str]):
    username = payload.get("username")
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute("DELETE FROM sessions WHERE username=?", (username,))
    conn.commit(); conn.close()
    return {"ok":True}


@app.post("/itr/save")
def save_itr(payload: Dict[str,Any]):
    username = payload.get("username")
    data = payload.get("data")
    transient = 1 if payload.get("transient") else 0
    conn = get_db_conn(); cur = conn.cursor()
    # store key-value pairs from data dict
    cur.execute("DELETE FROM itr_data WHERE username=? AND transient=?", (username, transient))
    for k,v in (data or {}).items():
        cur.execute("INSERT INTO itr_data(username,key,value,transient) VALUES(?,?,?,?)", (username, k, json.dumps(v), transient))
    conn.commit(); conn.close()
    return {"ok":True}

@app.get("/itr/load/{username}")
def load_itr(username: str):
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute("SELECT key,value FROM itr_data WHERE username=? ORDER BY id", (username,))
    rows = cur.fetchall(); conn.close()
    out = {r["key"]: json.loads(r["value"]) for r in rows}
    return {"ok":True, "data": out}

# Theme editor endpoints
@app.post("/theme/save")
def save_theme(payload: Dict[str,str]):
    name = payload.get("name"); cfg = payload.get("config","{}")
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO themes(name,config) VALUES(?,?)", (name, json.dumps(cfg)))
    conn.commit(); conn.close()
    return {"ok":True}

@app.get("/theme/list")
def list_themes():
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute("SELECT name,config FROM themes")
    rows = cur.fetchall(); conn.close()
    return {"ok":True, "themes": [{ "name": r["name"], "config": json.loads(r["config"]) if r["config"] else {} } for r in rows]}


# Endpoint to return default values (read from bundled defaults in code or file)
@app.get("/defaults")
def get_defaults():
    # Example defaults - could be loaded from file
    defaults = {
        "income": {"salary": 0.0, "other": 0.0},
        "deductions": {"80C": 0.0, "80D": 0.0},
        "profile": {"full_name": "", "email": "", "phone": ""}
    }
    return {"ok":True, "defaults": defaults}

# Initialize DB defaults if empty (simple check)
def init_defaults_into_db():
    conn = get_db_conn(); cur = conn.cursor()
    # if no themes, insert default themes
    cur.execute("SELECT COUNT(*) as c FROM themes"); r=cur.fetchone()
    if r and r["c"]==0:
        cur.execute("INSERT INTO themes(name,config) VALUES(?,?)", ("neo-dark", json.dumps({'bg':'#0b0f1a','fg':'#e8eefc','accent':'#4f8cff'})))
        cur.execute("INSERT INTO themes(name,config) VALUES(?,?)", ("ocean", json.dumps({'bg':'#021426','fg':'#e8f4ff','accent':'#27c4ff'})))
        cur.execute("INSERT INTO themes(name,config) VALUES(?,?)", ("sunrise", json.dumps({'bg':'#221310','fg':'#fff6f0','accent':'#ff8a4b'})))
    conn.commit(); conn.close()

init_defaults_into_db()


@app.post("/profile_upsert/{username}")
def profile_upsert(username: str, info: Dict[str,Any]):
    conn = get_db_conn(); cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO profiles(username,email,full_name,phone,data) VALUES(?,?,?,?,?)",
                (username, info.get("email",""), info.get("full_name",""), info.get("phone",""), json.dumps(info.get("data",{}))))
    conn.commit(); conn.close()
    return {"ok":True}

@app.get("/chat/history/{session_id}")
def chat_history(session_id: str, limit: int = 100):
    rows = _mem.history(session_id, limit=limit)
    return {"ok": True, "history": [{"role": r, "text": t, "ts": ts} for (r,t,ts) in rows]}
