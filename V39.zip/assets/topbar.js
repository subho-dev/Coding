
(function(){
  const root = document.createElement('div');
  
root.innerHTML = `
  <div class="itrtopbar" data-theme="auto">
    <div class="spacer"></div>
    <div class="right">
      <div class="chip" id="themesel_wrap">
        <span class="icon">🎨</span>
        <select id="themesel" title="Theme">
          <option value="auto">Auto</option>
          <option value="neo-dark">Neo Dark</option>
          <option value="ocean">Ocean</option>
          <option value="sunrise">Sunrise</option>
          <option value="plus">＋ Themes</option>
        </select>
      </div>
      <div class="chip">
        <span class="icon">🌐</span>
        <select id="langsel" title="Language">
          <option value="en">English</option>
          <option value="hi">हिन्दी</option>
        </select>
      </div>
      <div class="chip link" id="callbtn" title="Call"><span class="icon">📞</span><span class="lbl">Call</span></div>
      <div class="chip primary link" id="chatbtn" title="Ask the CA"><span class="lbl">Ask the CA</span><span class="icon">🤖</span></div>
      <div class="chip" id="loginbtn" title="Login">🔐</div>
      <div id="profilewrap" class="chip avatar" style="display:none;">
        <img id="profileicon" src="" alt="profile">
      </div>
    </div>
  </div>
  <div class="chat-overlay" id="overlay">
    <div class="chat-modal" id="chatmodal">
      <div class="chat-header">
        <div>Ask the CA</div>
        <div>
          <button id="minbtn">_</button>
          <button id="closebtn">×</button>
        </div>
      </div>
      <div class="chat-body" id="chatbody"></div>
      <div class="chat-input">
        <input id="chattext" placeholder="Type your question..." style="flex:1">
        <button id="sendbtn">Send</button>
      </div>
    </div>
  </div>
  <div class="auth-overlay" id="authoverlay" style="display:none;">
    <div class="auth-modal" id="authmodal" style="width:460px;border-radius:14px;padding:0;overflow:hidden;">
      <div class="auth-head"><strong>Welcome</strong><button id="authclose">×</button></div>
      <div class="auth-body">
        <div id="authforms">
          <div id="loginform">
            <input id="login_user" placeholder="Username"/><br>
            <input id="login_pass" placeholder="Password" type="password"/><br>
            <button id="login_submit" class="primary">Login</button>
            <button id="guest_login" class="ghost">Continue as Guest</button>
            <div class="muted">No account? <a href="#" id="show_signup">Signup</a></div>
            <div id="login_msg" class="error"></div>
          </div>
          <div id="signupform" style="display:none">
            <input id="su_user" placeholder="Username"/><br>
            <input id="su_pass" placeholder="Password" type="password"/><br>
            <input id="su_email" placeholder="Email"/><br>
            <input id="su_name" placeholder="Full name"/><br>
            <input id="su_phone" placeholder="Phone"/><br>
            <button id="signup_submit" class="primary">Create account</button>
            <div class="muted">Already have an account? <a href="#" id="show_login">Login</a></div>
            <div id="signup_msg" class="error"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <button class="fcb btn" id="fcb" style="display:none;">💬</button>
`;

  document.body.appendChild(root);
  const overlay = document.getElementById('overlay');
  const modal = document.getElementById('chatmodal');
  const chatbtn = document.getElementById('chatbtn');
  const fcb = document.getElementById('fcb');
  const minbtn = document.getElementById('minbtn');
  const closebtn = document.getElementById('closebtn');
  const body = document.getElementById('chatbody');
  const text = document.getElementById('chattext');
  const send = document.getElementById('sendbtn');
  let idleTimer=null, longTimer=null;

  function openChat(){
    overlay.style.display='block';
    fcb.style.display='none';
    resetTimers();
  }
  function minimize(){
    overlay.style.display='none';
    fcb.style.display='flex';
    fcb.classList.add('active');
    clearTimers();
    idleTimer = setTimeout(()=>{ /* still active indicator */ }, 30*1000);
    longTimer = setTimeout(()=>{
      fcb.style.display='none';
      fcb.classList.remove('active');
      body.innerHTML='';
    }, 5*60*1000);
  }
  function closeChat(){
    overlay.style.display='none';
    fcb.style.display='none';
    body.innerHTML='';
    fcb.classList.remove('active');
    clearTimers();
  }
  function clearTimers(){ if (idleTimer) clearTimeout(idleTimer); if (longTimer) clearTimeout(longTimer); }
  function resetTimers(){ clearTimers(); idleTimer=setTimeout(minimize, 30*1000); longTimer=setTimeout(closeChat, 5*60*1000); }

  chatbtn.onclick=openChat;
  fcb.onclick=openChat;
  minbtn.onclick=minimize;
  closebtn.onclick=closeChat;

  // Theme logic
  const themesel = document.getElementById('themesel');
  function applyTheme(t){
    document.documentElement.setAttribute('data-app-theme', t);
    try{ localStorage.setItem('itr_theme', t); }catch(e){}
    // notify Streamlit to update if needed
    fetch('/_theme?'+new URLSearchParams({theme:t})).catch(()=>{});
  }
  themesel.onchange = (e)=>{
    const t = e.target.value;
    if(t==='plus'){
      const qs = new URLSearchParams(window.location.search);
      qs.set('page','Themes');
      const url = window.location.pathname+'?'+qs.toString();
      window.history.pushState({}, '', url);
      // Streamlit listens to query params automatically
      return;
    }
    applyTheme(t);
  };
  // On load apply saved theme
  (function(){
    try{
      const t = localStorage.getItem('itr_theme') || 'auto';
      themesel.value = t;
      applyTheme(t);
    }catch(e){}
  })();

  overlay.addEventListener('click', (e)=>{ if(e.target===overlay) minimize(); });
  modal.addEventListener('click', (e)=>e.stopPropagation());

  // Draggable FCB
  fcb.onmousedown = function(e){
    let sX=e.clientX, sY=e.clientY;
    const r = fcb.getBoundingClientRect();
    let oX=r.left, oY=r.top;
    function mm(ev){
      let nx = oX + (ev.clientX - sX);
      let ny = oY + (ev.clientY - sY);
      fcb.style.left = nx+'px';
      fcb.style.top = ny+'px';
      fcb.style.right = 'auto';
      fcb.style.bottom = 'auto';
      fcb.style.position='fixed';
    }
    function mu(){ document.removeEventListener('mousemove',mm); document.removeEventListener('mouseup',mu); }
    document.addEventListener('mousemove',mm); document.addEventListener('mouseup',mu);
  }

  function addBubble(t, who){
    const d = document.createElement('div');
    d.style.padding='6px 10px'; d.style.margin='8px'; d.style.borderRadius='10px';
    d.style.maxWidth='85%';
    if(who==='user'){ d.style.background='#1e293b'; d.style.marginLeft='auto'; }
    else { d.style.background='#0b1324'; d.style.marginRight='auto'; }
    d.textContent=t; body.appendChild(d); body.scrollTop = body.scrollHeight;
  }

  // Animated typing while fetching
  function showTyping(){
    const d = document.createElement('div'); d.className='typing';
    let dots=0; d.textContent='Thinking';
    const iv=setInterval(()=>{ dots=(dots+1)%4; d.textContent='Thinking'+'.'.repeat(dots); }, 400);
    body.appendChild(d); body.scrollTop = body.scrollHeight;
    return ()=>{ clearInterval(iv); d.remove(); };
  }

  async function sendMsg(){
    const m = text.value.trim(); if(!m) return;
    addBubble(m,'user'); text.value=''; resetTimers();
    const stopTyping = showTyping();
    try {
      const session = (window.stSessionId || 'default');
      const r = await fetch('/chat', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({session_id: session, message: m})
      });
      const j = await r.json();
      stopTyping();
      addBubble(j.reply || 'No reply', 'bot');
    } catch(e){
      stopTyping();
      addBubble('Error contacting chatbot backend.', 'bot');
    }
  }
  send.onclick=sendMsg; text.addEventListener('keydown', (e)=>{ if(e.key==='Enter') sendMsg(); });

  // Call button
  const callbtn = document.getElementById('callbtn');
  callbtn.onclick = ()=>{
    const num = window.stCallNumber || '';
    if(num){ window.location.href = 'tel:'+num; }
    callbtn.classList.add('active'); setTimeout(()=>callbtn.classList.remove('active'), 1200);
  };

  
  const dict = {
    en: {"ITR Assistant Chat":"ITR Assistant Chat","Type your question...":"Type your question...","Send":"Send","Chatbot":"Chatbot","Call":"Call"},
    hi: {"ITR Assistant Chat":"आईटीआर सहायक चैट","Type your question...":"अपना प्रश्न लिखें...","Send":"भेजें","Chatbot":"चैटबॉट","Call":"कॉल"}
  };
  function applyLang(lang){
    const map = dict[lang]||dict.en;
    document.querySelectorAll('*').forEach(el=>{
      if(map[el.innerText]) el.innerText = map[el.innerText];
      if(el.placeholder && map[el.placeholder]) el.placeholder = map[el.placeholder];
    });
  }
  document.getElementById('langsel').addEventListener('change', (e)=>{
    applyLang(e.target.value);
  });
  // apply default once
  applyLang('en');


  // Language selector
  const dict = {
    en: {"Ask the CA":"Ask the CA","Type your question...":"Type your question...","Send":"Send","Call":"Call"},
    hi: {"Ask the CA":"सीए से पूछें","Type your question...":"अपना प्रश्न लिखें...","Send":"भेजें","Call":"कॉल"}
  };
  function applyLang(lang){
    try{ localStorage.setItem('itr_lang', lang); }catch(e){}
    const map = dict[lang]||dict.en;
    document.querySelectorAll('*').forEach(el=>{
      if(map[el.innerText]) el.innerText = map[el.innerText];
      if(el.placeholder && map[el.placeholder]) el.placeholder = map[el.placeholder];
    });
    fetch('/_lang?'+new URLSearchParams({lang: lang})).catch(()=>{});
  }
  const langsel = document.getElementById('langsel');
  langsel.onchange = (e)=>applyLang(e.target.value);
  (function(){ const l = (localStorage.getItem('itr_lang') || 'en'); langsel.value=l; applyLang(l); })();

// Language selector emits an event picked by Streamlit
  document.getElementById('langsel').onchange = (e)=>{
    fetch('/_lang?'+new URLSearchParams({lang: e.target.value}));
  };

  // Theme selector
  document.getElementById('themesel').onchange = (e)=>{
    fetch('/_theme?'+new URLSearchParams({theme: e.target.value}));
  };


  // Auth handlers
  const loginbtn = document.getElementById('loginbtn');
  const authoverlay = document.getElementById('authoverlay');
  const authmodal = document.getElementById('authmodal');
  const authclose = document.getElementById('authclose');
  const guestbtn = document.getElementById('guest_login');
  const profilewrap = document.getElementById('profilewrap');
  const profileicon = document.getElementById('profileicon');

  function showAuth(){ authoverlay.style.display='block'; }
  function hideAuth(){ authoverlay.style.display='none'; }
  loginbtn.onclick = showAuth;
  authclose.onclick = hideAuth;
  document.getElementById('show_signup').onclick = (e)=>{ e.preventDefault(); document.getElementById('loginform').style.display='none'; document.getElementById('signupform').style.display='block'; };
  document.getElementById('show_login').onclick = (e)=>{ e.preventDefault(); document.getElementById('loginform').style.display='block'; document.getElementById('signupform').style.display='none'; };

  document.getElementById('signup_submit').onclick = async ()=>{
    const payload = {username: document.getElementById('su_user').value, password: document.getElementById('su_pass').value,
                     email: document.getElementById('su_email').value, full_name: document.getElementById('su_name').value,
                     phone: document.getElementById('su_phone').value};
    const r = await fetch('/signup', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    const j = await r.json();
    if(j.ok){ localStorage.setItem('itr_user', j.username); hideAuth(); showProfile(j.username); } else { document.getElementById('signup_msg').innerText = j.error || 'Signup failed'; }
  };

  document.getElementById('login_submit').onclick = async ()=>{
    const payload = {username: document.getElementById('login_user').value, password: document.getElementById('login_pass').value};
    const r = await fetch('/login', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    const j = await r.json();
    if(j.ok){ localStorage.setItem('itr_user', j.username); hideAuth(); showProfile(j.username); } else { document.getElementById('login_msg').innerText = j.error || 'Login failed'; }
  };

  guestbtn.onclick = async ()=>{
    const r = await fetch('/guest_login', {method:'POST'}); const j = await r.json();
    if(j.ok){ localStorage.setItem('itr_user', j.username); hideAuth(); showProfile(j.username); }
  };

  async function showProfile(username){
    // fetch profile and display icon and store profile data
    try{
      const r = await fetch('/profile/'+encodeURIComponent(username));
      const j = await r.json();
      if(j.ok){
        profilewrap.style.display='flex';
        profileicon.src = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="36" height="36" rx="8" fill="#0b69ff"/><text x="50%" y="55%" font-size="16" text-anchor="middle" fill="#fff">'+(j.full_name?j.full_name.charAt(0).toUpperCase():'U')+'</text></svg>');
        // store profile to localStorage for prefill
        localStorage.setItem('itr_profile', JSON.stringify({username:j.username,email:j.email,full_name:j.full_name,phone:j.phone,data:j.data}));
        // replace login button with profile icon hidden
        loginbtn.style.display='none';
      }
    }catch(e){ console.error(e); }
  }

  profileicon.onclick = async ()=>{
    const p = JSON.parse(localStorage.getItem('itr_profile')||'{}');
    const newName = prompt('Full name', p.full_name||''); if(newName===null) return;
    p.full_name = newName;
    // update via API
    const username = localStorage.getItem('itr_user');
    await fetch('/profile/'+encodeURIComponent(username), {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email:p.email, full_name:p.full_name, phone:p.phone, data:p.data||{}})});
    localStorage.setItem('itr_profile', JSON.stringify(p));
    alert('Profile updated locally.');
  }

  // On load, if profile exists show it
  const existing = localStorage.getItem('itr_user');
  if(existing){ showProfile(existing); }

  // Expose toggles
  document.addEventListener('mousemove', resetTimers, {passive:true});
  document.addEventListener('keydown', resetTimers, {passive:true});
  // FCB hidden by default; appears after minimize or when chat engaged
})();
