# app_streamlit_itr_only.py - merged 
import os, io, time, traceback, yaml, glob
import streamlit as st, pandas as pd, numpy as np, requests, feedparser
import plotly.express as px
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from fetcher import fetch_from_sources
from schema_downloader import decide_applicable_itr, download_schema_for_ay, bulk_fallback_all_years
from autopilot import launch_headless_chrome, CAHelper
import re

st.markdown("""<style>
.main, .block-container, [data-testid="stSidebar"], [data-testid="stBottomBlockContainer"] { 
  scroll-behavior:smooth; transition: all .18s ease-in-out;
}
</style>""", unsafe_allow_html=True)


# ===== Injected Topbar + Backend Mount =====

# ---- Theme & Language from query params ----
qp = st.query_params
if 'theme' in qp:
    st.session_state['theme'] = qp.get('theme')
if 'lang' in qp:
    st.session_state['lang'] = qp.get('lang')
# Inject CSS variables for theme if present
def theme_css(theme):
    if theme == 'neo-dark':
        return ":root{--tb-bg:rgba(9,11,18,.82);--tb-fg:#f0f3ff;--tb-accent:#7aa2ff;--tb-border:rgba(255,255,255,.16);}"
    if theme == 'ocean':
        return ":root{--tb-bg:rgba(4,18,28,.80);--tb-fg:#e8f4ff;--tb-accent:#27c4ff;--tb-border:rgba(255,255,255,.14);}"
    if theme == 'sunrise':
        return ":root{--tb-bg:rgba(34,19,16,.80);--tb-fg:#fff6f0;--tb-accent:#ff8a4b;--tb-border:rgba(255,255,255,.18);}"
    return ""
st.markdown(f"<style>{theme_css(st.session_state.get('theme',''))}</style>", unsafe_allow_html=True)


# ----- User profile integration -----
import sqlite3, json
USERS_DB = os.environ.get("USERS_DB", "data/users.sqlite3")
def load_profile_for(user):
    if not user: return {}
    try:
        con = sqlite3.connect(USERS_DB); cur=con.cursor()
        cur.execute("SELECT username,email,full_name,phone,data FROM users WHERE username=?", (user,))
        r=cur.fetchone(); con.close()
        if not r: return {}
        u,email,full_name,phone,data = r
        try: parsed = json.loads(data or "{}")
        except: parsed = {}
        return {"username":u,"email":email,"full_name":full_name,"phone":phone,"data":parsed}
    except Exception as e:
        return {}
# Check for query param override to prefill fields
_user_q = st.query_params.get("_user", [None])[0]
if _user_q:
    prof = load_profile_for(_user_q)
    if prof:
        # expose profile to client-side for JS and prefill default forms via session_state
        st.session_state['profile'] = prof
        st.markdown(f"<script>window.itr_profile = {json.dumps(prof)};</script>", unsafe_allow_html=True)

import threading, uvicorn, types
from fastapi import FastAPI
from server.fastapi_server import app as _fastapi_app
from server.voice_bg import background_bootstrap

# bootstrap voice downloads (background)
background_bootstrap()

# Mount FastAPI on the same server via st.experimental_singleton-like approach
if "uvicorn_thread" not in st.session_state:
    def run_server():
        uvicorn.run(_fastapi_app, host="0.0.0.0", port=8000, log_level="warning")
    t = threading.Thread(target=run_server, daemon=True)
    t.start()
    st.session_state["uvicorn_thread"]=True

# Serve topbar assets
st.markdown(f"<style>{open('assets/topbar.css', encoding='utf-8').read(, encoding='utf-8')}</style>", unsafe_allow_html=True)
st.components.v1.html(open("assets/topbar.js", encoding='utf-8').read(, encoding='utf-8'), height=0)

# Language/theme handlers (simple session flags)
lang = st.query_params.get("_lang_sel", [st.session_state.get("lang","en")])[0]
st.session_state["lang"]=lang
theme_sel = st.query_params.get("_theme_sel", [st.session_state.get("theme","auto")])[0]
st.session_state["theme"]=theme_sel

# Expose phone number for call button
st.session_state.setdefault("call_number","+919999999999")  # change in Settings page
st.markdown(f"<script>window.stCallNumber='{st.session_state['call_number']}';</script>", unsafe_allow_html=True)

# smooth page transitions via CSS
st.markdown("""
<style>
.reportview-container .main .block-container{transition:opacity .25s ease-in-out; }
</style>
""", unsafe_allow_html=True)
# ===== End Injected =====


def use_regex(input_text):
    pattern = re.compile(r"[1-9]"+"\. "+".*", re.IGNORECASE)
    output = pattern.findall(input_text)
    final_output = []
    for value in output:
        value = value.replace("</p>","")
        final_output.append(value)
    return final_output

st.set_page_config(page_title="ITR Assistant", layout="wide", initial_sidebar_state="expanded")
LOG="itr_log.txt"

def log(msg):
    try:
        with open(LOG,"a",encoding="utf-8") as f: f.write(f"{time.time()} - {msg}\n")
    except: pass

# Theme system
THEME_FILE="themes.yaml"
DEFAULT_THEMES={"Neo Dark":{"bg":"#0b0f1a","card":"#111827","text":"#E5F0FF","muted":"#9FB8D6","accent":"#7AFCFF"},
                "Ink Black":{"bg":"#00040A","card":"#0B1220","text":"#F1F5F9","muted":"#98A2B3","accent":"#00E5A8"},
                "Light Contrast":{"bg":"#F6FAFF","card":"#FFFFFF","text":"#0B1220","muted":"#5B6777","accent":"#006D77"}}
def load_themes():
    if os.path.exists(THEME_FILE):
        try:
            with open(THEME_FILE,"r",encoding="utf-8") as f: return yaml.safe_load(f)
        except: return DEFAULT_THEMES.copy()
    return DEFAULT_THEMES.copy()
def save_themes(th): 
    try:
        with open(THEME_FILE,"w",encoding="utf-8") as f: yaml.safe_dump(th,f,sort_keys=False)
    except Exception as e: log(f"save themes err {e}")

if "themes" not in st.session_state: st.session_state.themes = load_themes()
if "theme_name" not in st.session_state: st.session_state.theme_name = list(st.session_state.themes.keys())[0]
def apply_theme(name):
    th = st.session_state.themes.get(name, list(st.session_state.themes.values())[0])
    css = f"""
    <style>
    :root{{--bg:{th['bg']};--card:{th['card']};--text:{th['text']};--muted:{th['muted']};--accent:{th['accent']};}}
    .appview-container{{background:var(--bg);}}
    .card{{background:var(--card);border-radius:12px;padding:14px;color:var(--text);margin-bottom:12px}}
    .hero{{background:linear-gradient(90deg,#03396c,#006d77);padding:20px;border-radius:12px;color:var(--text);margin-bottom:12px}}
    .muted{{color:var(--muted)}}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)
apply_theme(st.session_state.theme_name)

menu = st.sidebar.radio("Navigate", ["🏠 Overview","🧾 ITR Assistant","🧩 Regime Manager","🤖 Autopilot","🎨 Themes","⚙️ Settings"], index=0)
# "📰 Newsletter"
# defaults
DEFAULT_CFG = {"regimes":{"old":{"name":"Old Regime","cess_percent":4,"slabs":[{"upto":250000,"rate":0},{"upto":500000,"rate":5},{"upto":1000000,"rate":20},{"upto":None,"rate":30}],"deduction_limits":{"80C":150000},"explanation":"Old Regime"},"new":{"name":"New Regime","cess_percent":4,"slabs":[{"upto":300000,"rate":0},{"upto":600000,"rate":5},{"upto":900000,"rate":10},{"upto":1200000,"rate":15},{"upto":1500000,"rate":20},{"upto":2000000,"rate":25},{"upto":None,"rate":30}],"deduction_limits":{"80C":0},"explanation":"New Regime"}},"sources":[]}

if "cfg" not in st.session_state:
    if os.path.exists("regimes.yaml"):
        try:
            with open("regimes.yaml","r",encoding="utf-8") as f: st.session_state.cfg = yaml.safe_load(f)
        except Exception:
            st.session_state.cfg = DEFAULT_CFG.copy()
    else:
        st.session_state.cfg = DEFAULT_CFG.copy()

# tax calc utilities
def calc_tax_contrib(taxable, slabs):
    parts=[]; tax=0.0; rem=taxable; lower=0.0
    for s in slabs:
        upto=s.get("upto"); rate=float(s.get("rate",0))/100.0
        if upto is None:
            amt=max(0.0,rem); t=amt*rate; tax+=t; parts.append((f"{lower:+,.0f}+", rate*100, amt, t)); break
        slab_amt = max(0.0, min(rem, float(upto)-lower)); t=slab_amt*rate; tax+=t; parts.append((f"{lower:,.0f}-{float(upto):,.0f}", rate*100, slab_amt, t))
        rem-=slab_amt; lower=float(upto)
        if rem<=0: break
    return parts, tax
def calc_tax(taxable, slabs, cess):
    parts, pre = calc_tax_contrib(taxable, slabs)
    tax = pre + pre*(float(cess)/100.0)
    return max(0.0,tax), parts
def compute(incomes,deductions,cfg):
    total=sum(float(v) for v in incomes.values())
    out={}
    for key,reg in cfg.get("regimes",{}).items():
        dl=reg.get("deduction_limits",{}) or {}
        used=0.0
        for dkey,amt in deductions.items():
            lim=dl.get(dkey,None); a=float(amt)
            used += a if lim is None else min(a, float(lim))
        taxable=max(0.0, total-used)
        tax, parts = calc_tax(taxable, reg.get("slabs",[]), reg.get("cess_percent",4))
        out[key]={"name":reg.get("name",key),"tax":tax,"taxable":taxable,"ded_used":used,"explanation":reg.get("explanation",""),"parts":parts}
    return total, out
def chat_bot_call():
    # Floating Action Button (FAB) on all pages

    # ===== Start local FastAPI backend in a background thread =====
    def _ensure_backend():
        if st.session_state.get("_backend_started"):
            return
        import threading, uvicorn, sys, importlib, time
        sys.path.append(os.path.dirname(__file__))
        # import the app
        from server.app import app as _fastapi_app
        def _run():
            uvicorn.run(_fastapi_app, host="127.0.0.1", port=7860, log_level="warning")

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        # small wait for port to open
        time.sleep(0.5)
        st.session_state["_backend_started"] = True

    _ensure_backend()

    # FAB section removed