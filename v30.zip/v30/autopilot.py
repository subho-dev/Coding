
# autopilot.py - launch headless chrome and CAHelper
import os, threading, queue, glob, difflib, time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

def launch_headless_chrome(url, download_dir=None, headless=True):
    opts = Options()
    if headless: opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-gpu")
    if download_dir:
        prefs={"download.default_directory": os.path.abspath(download_dir),"download.prompt_for_download": False,"download.directory_upgrade": True}
        opts.add_experimental_option("prefs", prefs)
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=opts)
    driver.get(url); return driver

class CAHelper(threading.Thread):
    def __init__(self, schema_dir):
        super().__init__(daemon=True)
        self.schema_dir = schema_dir
        self.q = queue.Queue()
        self.aq = queue.Queue()
        self._running = True
        self.corpus = self._load_corpus()
    def _load_corpus(self):
        docs=[]
        for path in glob.glob(os.path.join(self.schema_dir,"**","*.*"), recursive=True):
            if path.lower().endswith(('.json','.xsd','.yaml','.yml','.txt','.md')):
                try:
                    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                        docs.append((path, f.read()))
                except:
                    pass
        return docs
    def run(self):
        while self._running:
            try:
                q = self.q.get(timeout=0.2)
                if q is None:
                    break
                resp = self._answer(q)
                self.aq.put(resp)
            except Exception:
                continue
    def ask(self, text):
        self.q.put(text)
    def get_answer(self, timeout=0.1):
        try: return self.aq.get(timeout=timeout)
        except: return None
    def stop(self):
        self._running=False
        self.q.put(None)
    def _answer(self, text):
        # naive NLP: fuzzy match filenames then keyword overlap
        files = [os.path.basename(p) for p,_ in self.corpus]
        matches = difflib.get_close_matches(text, files, n=1, cutoff=0.2)
        if matches:
            return f"Related schema file: {matches[0]}. Inspect it for field definitions. Ask more specific queries for exact fields."
        words = set(text.lower().split())
        best=None; best_score=0
        for path,doc in self.corpus:
            score = sum(1 for w in words if w in doc.lower())
            if score>best_score:
                best_score=score; best=path
        if best_score==0:
            return "No confident match in schema corpus. Please rephrase or provide context (deduction name, section, field)."
        return f"Best matching schema: {os.path.basename(best)} (score {best_score}). Ask for fields or examples."
