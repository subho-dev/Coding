#!/usr/bin/env python3
import uvicorn, json, yaml, io, re
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
try:
    from PyPDF2 import PdfReader
except Exception:
    PdfReader=None
app = FastAPI(title="CB v29 Summarizer")
def summarize_text(text:str)->str:
    try:
        obj=json.loads(text); keys=list(obj.keys()); out=[f"JSON with {len(keys)} keys: "+", ".join(keys[:20])+"."]
        if isinstance(obj,dict) and 'properties' in obj: props=list(obj['properties'].keys()); out.append("Schema props: "+", ".join(props[:25])+"."); 
        if isinstance(obj,dict) and 'required' in obj: out.append("Required: "+", ".join(obj['required'])+".")
        return " ".join(out)
    except Exception: pass
    try:
        data=yaml.safe_load(text)
        if isinstance(data,dict): ks=list(data.keys()); return f"YAML with {len(ks)} keys: "+", ".join(ks[:25])+"."
    except Exception: pass
    tags=re.findall(r"<([A-Za-z0-9:_-]+)(\s|>)", text); 
    if tags: uniq=[]; [uniq.append(t) for t,_ in tags if t not in uniq]; return "XML-like with elements: "+", ".join(uniq[:25])+"."
    words=re.findall(r"\w+", text); return f"Plain text ~{len(words)} words. Sample: "+" ".join(words[:30])+"..."
@app.post("/summarize_file")
async def summarize_file(file: UploadFile = File(...)):
    ext=(file.filename.split('.')[-1] or '').lower(); data=await file.read()
    if ext in ['json','txt','md','xml','yml','yaml']:
        return {"summary": summarize_text(data.decode('utf-8','ignore'))}
    if ext=='pdf':
        if not PdfReader: return JSONResponse({"summary":"Install PyPDF2 for PDF extraction."})
        try:
            reader=PdfReader(io.BytesIO(data)); texts=[]; 
            for p in reader.pages[:5]: texts.append(p.extract_text() or "")
            return {"summary": summarize_text("\n".join(texts))}
        except Exception as e: return {"summary":"PDF error: "+str(e)}
    if ext in ['png','jpg','jpeg','webp','bmp']:
        return {"summary":"Image provided. Install Tesseract+pytesseract or EasyOCR for OCR-based summary."}
    return {"summary":"Unsupported file."}
if __name__=="__main__": uvicorn.run(app,host='127.0.0.1',port=8079)