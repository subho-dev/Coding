
# fetcher.py - dynamic regime fetcher
import requests, yaml, logging
from bs4 import BeautifulSoup
logger = logging.getLogger("regime_fetcher")
def try_load_remote(url, timeout=10):
    try:
        r = requests.get(url, timeout=timeout); r.raise_for_status()
        text = r.text.strip()
        try: return r.json()
        except: pass
        try: return yaml.safe_load(text)
        except: pass
    except Exception as e:
        logger.debug(f"try_load_remote failed {e}")
    return None
def discover_links(html, base):
    soup = BeautifulSoup(html, "html.parser")
    links = []
    for a in soup.find_all("a", href=True):
        href = a['href']
        if any(href.lower().endswith(ext) for ext in [".yaml",".yml",".json"]):
            links.append(href if href.startswith("http") else requests.compat.urljoin(base, href))
    return links
def fetch_from_sources(sources):
    for src in sources:
        try:
            r = requests.get(src, timeout=10); r.raise_for_status()
            data = try_load_remote(src)
            if isinstance(data, dict) and "regimes" in data:
                data['_source']=src; return data, src
            links = discover_links(r.text, src)
            for link in links:
                d2 = try_load_remote(link)
                if isinstance(d2, dict) and "regimes" in d2:
                    d2['_source']=link; return d2, link
        except Exception as e:
            logger.debug(f"fetch_from_sources failed for {src}: {e}")
    return None, None
