
ITR Assistant v24 - Production-ready snapshot
- All requested features merged: dynamic schema downloads, schema-aware assistant, editable regime manager table,
  theme manager fixed, autopilot helper, newsletter, detailed PDF.
- Uses webdriver-manager to fetch chromedriver at runtime. If you want a binary included, upload exact chromedriver for your OS & Chrome.
Run:
1) python -m venv .venv
2) source .venv/bin/activate   # Windows: .venv\Scripts\activate
3) pip install -r requirements.txt
4) streamlit run app_streamlit_itr_only_v24.py
