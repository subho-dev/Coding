
from fastapi import FastAPI, Body, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import time, json, os, sqlite3, threading, re, math, traceback, uuid, pathlib, hashlib
from io import BytesIO
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4

# --- Offline LLM backends: llama-cpp first, GPT4All-J fallback ---
LLAMA_MODEL_URL = "https://huggingface.co/TheBloke/Llama-2-7B-Chat-GGML/resolve/main/llama-2-7b-chat.ggmlv3.q4_0.bin"
MODEL_DIR = pathlib.Path(__file__).resolve().parent.parent / "models"
MODEL_PATH = MODEL_DIR / "llama-2-7b-chat.ggmlv3.q4_0.bin"

_llm = None
_backend = None
def _ensure_model():
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    if not MODEL_PATH.exists():
        # Auto-download once
        try:
            import requests
            with requests.get(LLAMA_MODEL_URL, stream=True, timeout=60) as r:
                r.raise_for_status()
                with open(MODEL_PATH, "wb") as f:
                    for chunk in r.iter_content(chunk_size=1024*1024):
                        if chunk: f.write(chunk)
        except Exception as e:
            # Leave it for manual download
            pass

def _init_llm():
    global _llm, _backend
    if _llm: return
    _ensure_model()
    # Try llama.cpp
    try:
        from llama_cpp import Llama
        if MODEL_PATH.exists():
            _llm = Llama(model_path=str(MODEL_PATH), n_ctx=4096, n_threads=4, verbose=False)
            _backend = "llama.cpp"
            return
    except Exception:
        pass
    # Fallback to GPT4All-J
    try:
        from gpt4all import GPT4All
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        _llm = GPT4All("gpt4all-j-v1.3-groovy", model_path=str(MODEL_DIR))
        _backend = "gpt4all-j"
        return
    except Exception:
        _llm = None
        _backend = None

# --- Lightweight NLP routing, ambiguity detection, and memory ---
DB_PATH = pathlib.Path(__file__).resolve().parent.parent / "data" / "chatbot_memory.sqlite3"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

def _db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS facts (
        id TEXT PRIMARY KEY,
        key TEXT,
        value TEXT,
        source TEXT,
        created_at REAL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS history (
        ts REAL,
        role TEXT,
        text TEXT
    )""")
    return conn

def save_history(role: str, text: str):
    try:
        conn=_db(); conn.execute("INSERT INTO history VALUES (?,?,?)",(time.time(), role, text)); conn.commit(); conn.close()
    except: pass

def learn_fact(key: str, value: str, source: str="user"):
    conn=_db()
    conn.execute("INSERT OR REPLACE INTO facts VALUES (?,?,?,?,?)",
                 (hashlib.sha256((key+value).encode()).hexdigest(), key.strip(), value.strip(), source, time.time()))
    conn.commit(); conn.close()

def search_facts(query: str) -> List[Dict[str,str]]:
    conn=_db(); cur=conn.cursor()
    rows = cur.execute("SELECT key,value,source FROM facts").fetchall(); conn.close()
    # naive relevance
    q = query.lower()
    res=[]
    for k,v,s in rows:
        score = sum(w in (k.lower()+" "+v.lower()) for w in re.findall(r'\w+', q))
        if score: res.append({"key":k,"value":v,"source":s,"score":score})
    return sorted(res, key=lambda x: -x["score"])[:5]

# Simple numeric expression evaluator using numexpr for safety/speed (no sympy)
def safe_eval(expr: str) -> Optional[float]:
    try:
        import numexpr as ne
        val = ne.evaluate(expr, local_dict={}, global_dict={})
        try:
            return float(val)
        except Exception:
            if hasattr(val, "item"): return float(val.item())
            return None
    except Exception:
        return None

def route_intent(text: str) -> str:
    t = text.lower().strip()
    if any(k in t for k in ["tax slab","regime","old regime","new regime","section 80", "deduction"]):
        return "tax_help"
    if any(k in t for k in ["calculate","eval","=", "+", "-", "*", "/", "percent", "%"]):
        return "math"
    if any(k in t for k in ["learn that","remember that","store that","note that"]):
        return "teach"
    return "chat"

def is_ambiguous(text: str) -> Optional[str]:
    needs = []
    if "deduction" in text.lower() and not re.search(r'section\s*\d', text.lower()):
        needs.append("Which section or deduction name (e.g., 80C, 80D)?")
    if "regime" in text.lower() and not re.search(r'old|new', text.lower()):
        needs.append("Old or new tax regime?")
    if re.search(r'it[rR]-?\d', text) is None and "which form" in text.lower():
        needs.append("Which ITR form are you referring to (ITR-1..ITR-4)?")
    if needs:
        return " / ".join(needs)
    return None

# LLM chat wrapper
def llm_reply(prompt: str) -> str:
    _init_llm()
    if _backend == "llama.cpp":
        out = _llm.create_completion(prompt=prompt, temperature=0.4, max_tokens=256)
        return out["choices"][0]["text"].strip()
    if _backend == "gpt4all-j":
        with _llm.chat_session():
            return _llm.generate(prompt, temp=0.4, max_tokens=256)
    # No backend available
    return "I'm running offline and couldn't load a model. Please download the model manually (see README) and try again."

# --- API ---
app = FastAPI(title="Local CA Chatbot API (Advanced)")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

class ChatMessage(BaseModel):
    role: str
    text: str

class ChatRequest(BaseModel):
    history: List[Dict[str, str]]
    query: str

@app.post("/api/chat")
def chat(req: ChatRequest):
    q = req.query.strip()
    save_history("user", q)

    amb = is_ambiguous(q)
    if amb:
        reply = f"I need a bit more detail: {amb}"
        save_history("assistant", reply)
        return {"reply": reply, "need_clarification": True}

    intent = route_intent(q)
    if intent == "teach":
        # pattern: "learn that X is Y" or "remember that PAN is ABC..."
        m = re.search(r'(?:learn|remember|note|store)\s+that\s+(.+?)\s+is\s+(.+)', q, re.I)
        if m:
            key, value = m.group(1), m.group(2)
            # naive self-verification via LLM
            prompt = f"Verify if the following fact is plausible in Indian tax context. Fact: '{key} is {value}'. Reply 'OK' or 'UNSURE' and a brief reason."
            verdict = llm_reply(prompt)
            if "OK" in verdict.upper():
                learn_fact(key, value, source="user-verified")
                reply = f"Saved: {key} → {value} (verified)."
            else:
                reply = f"I couldn't verify this confidently ({verdict}). I'll store it as tentative."
                learn_fact(key, value, source="tentative")
        else:
            reply = "To teach me, say: 'learn that <key> is <value>'."
        save_history("assistant", reply); 
        return {"reply": reply, "facts": search_facts(q), "need_clarification": False}

    if intent == "math":
        # Extract simple expression
        expr = re.sub(r'[^0-9\.\+\-\*\/\(\)\s%]', '', q)
        expr = expr.replace("%", "/100.0*")
        val = safe_eval(expr)
        if val is not None:
            reply = f"{expr} = {val:.4f}"
            save_history("assistant", reply)
            return {"reply": reply, "need_clarification": False}
        # fallback to LLM
        reply = llm_reply(f"Solve and explain briefly: {q}")
        save_history("assistant", reply)
        return {"reply": reply, "need_clarification": False}

    # Use memory to augment
    facts = search_facts(q)
    context = "\n".join([f"- {f['key']}: {f['value']}" for f in facts])
    prompt = f"You are a helpful Chartered Accountant assistant for Indian taxes. Use the following known facts if relevant:\n{context}\n\nQuestion: {q}\nAnswer clearly and concisely."
    reply = llm_reply(prompt)
    save_history("assistant", reply)
    return {"reply": reply, "facts": facts, "need_clarification": False, "backend": _backend}

@app.post("/api/export_pdf")
def export_pdf(req: ChatRequest):
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    story = [Paragraph("ASK THE CA — Conversation", styles['Title']), Spacer(1,12)]
    for m in req.history + [{"role":"user","text":req.query}]:
        who = m.get("role","user").capitalize()
        story.append(Paragraph(f"<b>{who}:</b> {m.get('text','')}", styles['BodyText']))
        story.append(Spacer(1,6))
    doc.build(story)
    pdf = buf.getvalue()
    return Response(content=pdf, media_type="application/pdf")

@app.get("/api/health")
def health():
    _init_llm()
    return {"ok": True, "backend": _backend, "model_path": str(MODEL_PATH)}
