
import os, threading, time, sqlite3, json, re, queue
from typing import Dict, Any, Optional, List
from fastapi import FastAPI
from pydantic import BaseModel
from starlette.middleware.cors import CORSMiddleware

# Lightweight semantic + rule-based engine with optional local LLMs
from .model_manager import LocalLLM
from .memory import BotMemory
from .summarizer import SmartSummarizer

app = FastAPI(title="ITR Assistant Chat Backend", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_mem = BotMemory(db_path=os.environ.get("CHATBOT_DB","data/chatbot_memory.sqlite3"))
_llm = LocalLLM(models_dir=os.environ.get("MODELS_DIR","models"))
_sum = SmartSummarizer()

class ChatIn(BaseModel):
    session_id: str
    message: str
    context: Optional[Dict[str, Any]] = None

class ChatOut(BaseModel):
    reply: str
    used_model: str
    memory_events: List[str] = []

@app.get("/health")
def health():
    return {"status":"ok","models":_llm.models_available()}

@app.post("/chat", response_model=ChatOut)
def chat(inp: ChatIn):
    user = inp.session_id or "default"
    msg = inp.message.strip()
    memory_events = []
    # Learn simple facts: "My PAN is ....", "My name is ...."
    facts = _mem.extract_and_store(user, msg)
    if facts:
        memory_events.append(f"learned: {', '.join([f'{k}={v}' for k,v in facts.items()])}")
    # Retrieve memory
    memo = _mem.load(user)
    # If the message looks like "summarize file: <path or name>"
    if re.search(r"\bsummar(i[sz]e|y)\b", msg, re.I):
        # The frontend should send content via context (raw_text or structured)
        ctx = inp.context or {}
        text = ctx.get("raw_text") or ""
        meta = {k:v for k,v in ctx.items() if k!="raw_text"}
        if text:
            reply = _sum.summarize(text, meta=meta)
            return ChatOut(reply=reply, used_model="summarizer", memory_events=memory_events)
    # Default: try LLM with fallback
    sys_context = (
        "You are ITR Assistant Chatbot. Be concise, factual. "
        "Ask targeted clarifying questions when the query is ambiguous. "
        "Prefer Indian Income Tax context when relevant."
    )
    reply, used = _llm.generate(msg, system_prompt=sys_context, memory=memo)
    # Store the conversation
    _mem.append_turn(user, "user", msg)
    _mem.append_turn(user, "assistant", reply)
    return ChatOut(reply=reply, used_model=used, memory_events=memory_events)


# --- Simple user auth (sqlite) ---
USERS_DB = os.environ.get("USERS_DB", "data/users.sqlite3")
def _init_users():
    os.makedirs(os.path.dirname(USERS_DB), exist_ok=True)
    con = sqlite3.connect(USERS_DB)
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY, password_hash TEXT, salt TEXT, email TEXT, full_name TEXT, phone TEXT, data JSON
    )""")
    con.commit(); con.close()
_init_users()

import hashlib, secrets, json as _json

def _hash_password(password, salt):
    return hashlib.sha256((salt+password).encode('utf-8')).hexdigest()

@app.post("/signup")
def signup(info: Dict[str,str]):
    username = info.get("username","").strip().lower()
    password = info.get("password","")
    if not username or not password:
        return {"ok":False, "error":"Username and password required."}
    con = sqlite3.connect(USERS_DB); cur = con.cursor()
    cur.execute("SELECT username FROM users WHERE username=?", (username,))
    if cur.fetchone():
        con.close(); return {"ok":False, "error":"User already exists."}
    salt = secrets.token_hex(8)
    ph = _hash_password(password, salt)
    cur.execute("INSERT INTO users(username,password_hash,salt,email,full_name,phone,data) VALUES(?,?,?,?,?,?,?)",
                (username, ph, salt, info.get("email",""), info.get("full_name",""), info.get("phone",""), _json.dumps({})))
    con.commit(); con.close()
    return {"ok":True, "username": username}

@app.post("/login")
def login(info: Dict[str,str]):
    username = info.get("username","").strip().lower()
    password = info.get("password","")
    if not username or not password:
        return {"ok":False, "error":"Username and password required."}
    con = sqlite3.connect(USERS_DB); cur = con.cursor()
    cur.execute("SELECT password_hash,salt,email,full_name,phone,data FROM users WHERE username=?", (username,))
    row = cur.fetchone(); con.close()
    if not row:
        return {"ok":False, "error":"Invalid username or password."}
    ph, salt, email, full_name, phone, data = row
    if _hash_password(password, salt) != ph:
        return {"ok":False, "error":"Invalid username or password."}
    return {"ok":True, "username": username, "email": email, "full_name": full_name, "phone": phone, "data": json.loads(data or "{}")}

@app.post("/guest_login")
def guest_login(info: Dict[str,str] = {}):
    # returns a temporary guest id
    gid = "guest_" + secrets.token_hex(6)
    return {"ok":True, "username": gid}

@app.get("/profile/{username}")
def get_profile(username: str):
    con = sqlite3.connect(USERS_DB); cur = con.cursor()
    cur.execute("SELECT username,email,full_name,phone,data FROM users WHERE username=?", (username,))
    row = cur.fetchone(); con.close()
    if not row: return {"ok":False, "error":"User not found."}
    u, email, full_name, phone, data = row
    return {"ok":True, "username":u, "email":email, "full_name":full_name, "phone":phone, "data": json.loads(data or "{}")}

@app.post("/profile/{username}")
def update_profile(username: str, info: Dict[str,str]):
    con = sqlite3.connect(USERS_DB); cur = con.cursor()
    cur.execute("SELECT username FROM users WHERE username=?", (username,))
    if not cur.fetchone():
        con.close(); return {"ok":False, "error":"User not found."}
    # update fields
    cur.execute("UPDATE users SET email=?, full_name=?, phone=?, data=? WHERE username=?",
                (info.get("email",""), info.get("full_name",""), info.get("phone",""), json.dumps(info.get("data",{})), username))
    con.commit(); con.close()
    return {"ok":True}
