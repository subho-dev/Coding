# schema_downloader.py - improved regime/schema downloader and parser
import requests, os, json, re
from pathlib import Path

DEFAULT_SCHEMA_URL = "https://example.com/official/regimes.json"  # Update README with real URL

class SchemaDownloader:
    def __init__(self, cache_dir=None):
        self.cache_dir = Path(cache_dir or Path(__file__).parent / "regimes_cache")
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_file = self.cache_dir / "regimes.json"
    def download(self, url=None, force=False):
        url = url or DEFAULT_SCHEMA_URL
        if self.cache_file.exists() and not force:
            try:
                return json.loads(self.cache_file.read_text())
            except:
                pass
        try:
            r = requests.get(url, timeout=20)
            r.raise_for_status()
            data = r.json()
            # save
            self.cache_file.write_text(json.dumps(data, indent=2))
            return data
        except Exception as e:
            # fallback to bundled themes or default
            return self._fallback()
    def _fallback(self):
        # attempt to load bundled regimes from file if present
        bundled = Path(__file__).parent / "default_regimes.json"
        if bundled.exists():
            return json.loads(bundled.read_text())
        # basic default
        return [{"name":"Default","year":"2024-25","slabs":[{"upto":250000,"rate":0},{"upto":500000,"rate":0.05},{"upto":1000000,"rate":0.2},{"upto":float('inf'),"rate":0.3}]}]
    def load_regimes(self):
        return self.download()
