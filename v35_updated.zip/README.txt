Updated README - Offline LLM & Deployment Notes

1) Overview
This project contains an ITR Assistant Streamlit frontend and a FastAPI backend chatbot. The updated UI moves the menu to the top, adds language/theme selectors and a chatbot modal. Chat backend stores learned facts in SQLite.

2) Offline LLM (optional)
Code includes placeholders to auto-download `llama-2-7b-chat.ggmlv3.q4_0.bin` and GPT4All-J when first run. **Automatic downloads require internet**:
- Suggested sources (manual download):
  - Llama 2 GGML variants: check official Meta release mirrors or reputable community builds.
  - GPT4All-J: https://gpt4all.io (or their official repository/releases)
- Place models under the folder: `models/` at project root.
  - Example: `models/llama-2-7b-chat.ggmlv3.q4_0.bin`
  - Fallback model: `models/gpt4all-j.bin`

3) SQLite
The backend FastAPI will create `server/chat_memory.db` automatically to store conversations and simple learned facts across runs.

4) Regimes / Schemas
The schema_downloader module attempts to fetch regimes from the official source. Update DEFAULT_SCHEMA_URL in `schema_downloader.py` to point to the authoritative JSON endpoint for regimes/schemas. The fetched and parsed JSON will be saved under `regimes_cache/regimes.json`.

5) Autopilot / Browser automation
`autopilot.py` will attempt to launch Chrome in non-headless mode. If it fails due to headless-only environment or missing executable, it reports a helpful error.

6) Running locally
- Install requirements: `pip install -r requirements.txt`
- Start backend: `uvicorn server.app:app --reload --port 8000`
- Start frontend: `streamlit run app_streamlit_itr_only_v30.py`

7) Notes & Limitations
- This update focuses on integrating UI elements, adding a simple offline-capable chatbot backend, and making the regime downloader more robust. 
- Heavy LLM usage / model downloads are optional and need proper hosting and storage. The codebase includes placeholders to perform downloads at startup if desired.
