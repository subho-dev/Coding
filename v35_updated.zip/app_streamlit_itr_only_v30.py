# Updated app_streamlit_itr_only_v30.py
# Adds a top fixed menu with call, language selector, theme selector, chatbot icon,
# integrates a modal chatbot (front-end) that communicates with FastAPI backend.
# NOTE: This is a front-end integration. Backend FastAPI is in server/app.py included in this package.

import streamlit as st
import yaml, os, json, time
from pathlib import Path

HERE = Path(__file__).parent
themes_file = HERE / "themes.yaml"

st.set_page_config(page_title="ITR Assistant (Updated)", layout="wide", initial_sidebar_state="collapsed")

# Load themes
def load_themes():
    if themes_file.exists():
        try:
            return yaml.safe_load(themes_file.read_text())
        except Exception as e:
            return {}
    return {}

themes = load_themes() or {}
theme_names = list(themes.keys()) or ["Default"]

# Persistent settings (in session state)
if 'language' not in st.session_state:
    st.session_state.language = 'English'
if 'theme' not in st.session_state:
    st.session_state.theme = theme_names[0]

# Top fixed menu via markdown + CSS + small JS for interactivity
menu_html = f"""
<style>
/* Top fixed menu */
#top-menu {{ position: fixed; top: 0; left: 0; right: 0; height: 56px; background: linear-gradient(90deg,#0f172a,#0b1220); color: white; z-index:9999; display:flex; align-items:center; gap:12px; padding:0 18px; box-shadow: 0 4px 12px rgba(2,6,23,0.6); }}
#top-menu .brand {{ font-weight:700; font-size:18px; margin-right:12px; }}
#top-menu .menu-item {{ padding:8px 12px; border-radius:8px; cursor:pointer; }}
#top-menu .menu-item.active {{ background: rgba(255,255,255,0.08); }}
#top-menu select, #top-menu button {{ background:transparent; color: white; border: 1px solid rgba(255,255,255,0.08); padding:6px 10px; border-radius:6px; }}
/* make body content lower */
.main-content {{ padding-top:76px; }}

/* Chat modal basics */
#chat-modal {{ display:none; position: fixed; inset:0; backdrop-filter: blur(6px); z-index:10000; align-items:center; justify-content:center; }}
#chat-card {{ width: min(980px, 95%); height: min(820px, 85%); background: #0b1220; border-radius:10px; box-shadow: 0 8px 24px rgba(2,6,23,0.8); padding:12px; color:white; display:flex; flex-direction:column; }}
#chat-header {{ display:flex; justify-content:space-between; align-items:center; gap:8px; }}
#chat-body {{ flex:1; overflow:auto; margin-top:12px; padding:8px; border-radius:8px; background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01)); }}
#chat-input { display:flex; gap:8px; margin-top:8px; }
#floating-chat {{ position: fixed; right: 18px; bottom: 18px; width:64px; height:64px; border-radius: 12px; background: linear-gradient(180deg,#10b981,#059669); display:flex; align-items:center; justify-content:center; cursor:pointer; z-index:9998; box-shadow: 0 6px 20px rgba(2,6,23,0.6); }}
#floating-chat .dot { position:absolute; right:6px; top:6px; width:12px; height:12px; border-radius:50%; background: limegreen; border: 2px solid white; display:none; }

</style>
<div id="top-menu">
  <div class="brand">ITR Assistant</div>
  <div id="call-btn" class="menu-item">📞 Call</div>
  <div id="chat-open" class="menu-item">💬 Chat</div>
  <div style="flex:1"></div>
  <select id="lang-select" title="Language">
    <option value="English">English</option>
    <option value="Hindi">Hindi</option>
  </select>
  <select id="theme-select" title="Theme">
    {''.join([f"<option value='{tn}'>{tn}</option>" for tn in theme_names])}
  </select>
</div>

<div id="chat-modal">
  <div id="chat-card" role="dialog" aria-modal="true">
    <div id="chat-header">
      <div><strong>Assistant</strong><div style="font-size:12px;color:#9CA3AF">Ask your ITR questions</div></div>
      <div style="display:flex;gap:8px;">
        <button id="minimize-btn">_</button>
        <button id="close-btn">X</button>
      </div>
    </div>
    <div id="chat-body"></div>
    <div id="chat-input">
      <input id="chat-text" placeholder="Type your question..." style="flex:1;padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,0.08);background:transparent;color:white;" />
      <button id="send-btn">Send</button>
    </div>
  </div>
</div>

<div id="floating-chat" title="Open chat" style="display:none;">
  <div style="font-size:22px;">💬</div>
  <div class="dot" id="chat-active-dot"></div>
</div>

<script>
const topMenu = document.getElementById('top-menu');
const chatModal = document.getElementById('chat-modal');
const floating = document.getElementById('floating-chat');

document.getElementById('chat-open').onclick = () => { chatModal.style.display='flex'; floating.style.display='none'; document.getElementById('chat-text').focus(); startTimers(); }
document.getElementById('close-btn').onclick = () => { chatModal.style.display='none'; floating.style.display='none'; localStorage.removeItem('chat_open'); stopTimers(); }
document.getElementById('minimize-btn').onclick = () => { chatModal.style.display='none'; floating.style.display='flex'; localStorage.setItem('chat_open','1'); startTimers(); }

// click backdrop to minimize
chatModal.addEventListener('click', (e)=>{ if(e.target===chatModal){ chatModal.style.display='none'; floating.style.display='flex'; startTimers(); } });

// floating click opens chat again
floating.onclick = () => { chatModal.style.display='flex'; floating.style.display='none'; startTimers(); }

// simple timers for inactivity: 30s minimize, 5min close
let minimizeTimer=null, closeTimer=null;
function startTimers(){
  clearTimers();
  minimizeTimer = setTimeout(()=>{ chatModal.style.display='none'; floating.style.display='flex'; document.getElementById('chat-active-dot').style.display='block'; }, 30000);
  closeTimer = setTimeout(()=>{ chatModal.style.display='none'; floating.style.display='none'; localStorage.removeItem('chat_open'); }, 5*60*1000);
}
function clearTimers(){ clearTimeout(minimizeTimer); clearTimeout(closeTimer); minimizeTimer=null; closeTimer=null; document.getElementById('chat-active-dot').style.display='none'; }
function stopTimers(){ clearTimers(); }

// language and theme interactions -> pass to Streamlit via window.postMessage
document.getElementById('lang-select').onchange = (e)=>{ window.parent.postMessage({streamlitMessage:true, type:'SET_LANG', value:e.target.value}, '*'); }
document.getElementById('theme-select').onchange = (e)=>{ window.parent.postMessage({streamlitMessage:true, type:'SET_THEME', value:e.target.value}, '*'); }

// Call button
document.getElementById('call-btn').onclick = ()=>{ window.location.href='tel:+911234567890'; }

// Chat send basic wiring: will call backend /chat endpoint
document.getElementById('send-btn').onclick = async ()=>{
  const q = document.getElementById('chat-text').value.trim();
  if(!q) return;
  const body = document.getElementById('chat-body');
  const msg = document.createElement('div'); msg.textContent = 'You: ' + q; msg.style.padding='6px'; msg.style.opacity=0.9; body.appendChild(msg);
  document.getElementById('chat-text').value='';
  // call backend
  try{
    const resp = await fetch('/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({q})});
    const data = await resp.json();
    const r = document.createElement('div'); r.textContent = 'Bot: ' + (data.answer||'No answer'); r.style.padding='6px'; r.style.marginTop='6px'; r.style.opacity=0.95; body.appendChild(r); body.scrollTop = body.scrollHeight;
  }catch(err){
    const e = document.createElement('div'); e.textContent = 'Bot: (error contacting backend)'; e.style.color='orange'; body.appendChild(e);
  }
  startTimers();
}
</script>
"""

st.components.v1.html(menu_html, height=120)

# Main content area
st.markdown('<div class="main-content">', unsafe_allow_html=True)

st.title("ITR Assistant — Modern UI")
st.write("Welcome to the updated assistant. Use top menu for language, theme and chat.")

# Theme selector reflected in session state
lang = st.selectbox("Language (also available in top menu)", ["English", "Hindi"], index=0 if st.session_state.language=='English' else 1, key="lang_select")
if lang != st.session_state.language:
    st.session_state.language = lang

theme = st.selectbox("Theme (also available in top menu)", theme_names, index=theme_names.index(st.session_state.theme) if st.session_state.theme in theme_names else 0, key="theme_select")
if theme != st.session_state.theme:
    st.session_state.theme = theme

# ITR Assistant area (placeholder for improved calculations)
st.subheader("ITR Assistant — Calculations & Regimes")
st.write("Regimes loaded from schema_downloader will be used here.")

# Show basic regime loader status
from schema_downloader import SchemaDownloader
sd = SchemaDownloader(cache_dir=HERE / "regimes_cache")
regimes = sd.load_regimes()
st.write(f"Loaded {len(regimes)} regimes/schemas. Using theme: **{st.session_state.theme}**, Language: **{st.session_state.language}**.")

# Animated modern steps (replace old step images)
st.markdown("""
<div style="display:flex;gap:12px;overflow:auto;padding:8px;">
  <div style="min-width:220px;padding:12px;border-radius:12px;background:linear-gradient(180deg,#071023, #0b1524);box-shadow:0 6px 18px rgba(2,6,23,0.6)">
    <h4>Step 1</h4><p>Collect documents — PAN, Aadhar, Form16.</p>
  </div>
  <div style="min-width:220px;padding:12px;border-radius:12px;background:linear-gradient(180deg,#071023, #0b1524);box-shadow:0 6px 18px rgba(2,6,23,0.6)">
    <h4>Step 2</h4><p>Choose regime — Old or New.</p>
  </div>
  <div style="min-width:220px;padding:12px;border-radius:12px;background:linear-gradient(180deg,#071023, #0b1524);box-shadow:0 6px 18px rgba(2,6,23,0.6)">
    <h4>Step 3</h4><p>Review calculations & file.</p>
  </div>
</div>
""", unsafe_allow_html=True)

st.write("End of page. Chat is available in top menu.")

st.markdown('</div>', unsafe_allow_html=True)

# Receive postMessage from iframe (top menu)
# Streamlit doesn't have direct window.postMessage listener in python; so we expose a tiny hack: user can use selects too.
# Advanced: We leave priority to selectboxes above for actual language/theme change.
