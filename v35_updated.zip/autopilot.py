# autopilot.py - attempt to open browser non-headless for automation tasks
# This script will attempt to run Chrome in non-headless mode. If it fails, it will report details.
import subprocess, shutil, sys, os, time

def launch_chrome(url="https://www.google.com", headless=False):
    # Try to find chrome executable
    chrome_cmds = ["google-chrome", "chrome", "chromium", "chromium-browser", "google-chrome-stable"]
    exe = None
    for c in chrome_cmds:
        if shutil.which(c):
            exe = c; break
    args = []
    if exe:
        args = [exe]
        if headless:
            args += ["--headless=new","--disable-gpu"]
        args += [url]
        try:
            subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True, f"Launched {exe} (headless={headless})."
        except Exception as e:
            return False, str(e)
    else:
        return False, "No chrome executable found on PATH."

if __name__ == '__main__':
    ok, msg = launch_chrome(headless=False)
    print(ok, msg)
