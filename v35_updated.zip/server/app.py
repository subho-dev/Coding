# server/app.py - FastAPI chatbot backend (updated)
from fastapi import FastAPI, Request
from pydantic import BaseModel
import sqlite3, os, json, time, re
from typing import Optional

DB = os.path.join(os.path.dirname(__file__), "chat_memory.db")

def init_db():
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp INTEGER,
        user_text TEXT,
        bot_text TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS facts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT UNIQUE,
        value TEXT,
        timestamp INTEGER
    )""")
    conn.commit()
    conn.close()

init_db()

app = FastAPI()

class Query(BaseModel):
    q: str

def simple_nlp_answer(q:str):
    ql = q.strip().lower()
    # If user asks to teach the bot: "i tell you that ..." store as fact
    teach_match = re.match(r".*(i\\s+(tell|told)\\s+you\\s+that|remember\\s+that)\\s+(.*)", ql)
    if teach_match:
        fact = teach_match.group(3)
        # naive key extraction: first 40 chars
        key = fact[:80]
        conn = sqlite3.connect(DB)
        cur = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO facts (key,value,timestamp) VALUES (?,?,?)", (key, fact, int(time.time())))
        conn.commit()
        conn.close()
        return "Thanks — I've stored that information for future conversations."
    # Basic Q/A fallback: search facts for keywords
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute("SELECT key,value FROM facts")
    rows = cur.fetchall()
    for k,v in rows:
        if any(tok in ql for tok in k.split()[:6]):
            return f"I recall: {v}"
    # Ambiguity detection: very short queries ask clarifying question
    if len(ql.split()) <= 3 or "?" in ql and len(ql) < 40:
        return "Could you please provide a little more detail so I can answer accurately?"
    # Rule-based responses for tax-related questions (very basic)
    if "tax slab" in ql or "rate" in ql:
        return "Tax slabs depend on regime and year. Please specify the financial year and regime (old/new)."
    # Default safe reply
    return "I can help with ITR calculations, regimes and filing steps. Please provide more details (financial year, income components)."

@app.post("/chat")
async def chat(q: Query):
    answer = simple_nlp_answer(q.q)
    # store in conversations
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute("INSERT INTO conversations (timestamp,user_text,bot_text) VALUES (?,?,?)", (int(time.time()), q.q, answer))
    conn.commit(); conn.close()
    return {"answer": answer}

@app.get("/health")
async def health():
    return {"status": "ok"}
