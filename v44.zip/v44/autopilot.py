
# autopilot.py - launch chrome and CAHelper (robust)
import os, threading, queue, glob, difflib, time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

def launch_chrome(url, download_dir=None, headless=False):
    opts = Options()
    if headless:
        opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=1366,900")
    if download_dir:
        prefs={"download.default_directory": os.path.abspath(download_dir),
               "download.prompt_for_download": False,
               "download.directory_upgrade": True}
        opts.add_experimental_option("prefs", prefs)
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=opts)
    if url: driver.get(url)
    return driver

class CAHelper:
    def __init__(self, corpus_glob="schemas/**/*.json"):
        self.corpus = [(p, open(p,'r',encoding='utf-8',errors='ignore').read()) for p in glob.glob(corpus_glob, recursive=True)]
    def ask(self, text: str) -> str:
        files = [os.path.basename(p) for p,_ in self.corpus]
        matches = difflib.get_close_matches(text, files, n=1, cutoff=0.2)
        if matches:
            return f"Related schema file: {matches[0]}."
        words = set(text.lower().split())
        best=None; best_score=0
        for path,doc in self.corpus:
            score = sum(1 for w in words if w in doc.lower())
            if score>best_score:
                best_score=score; best=path
        if best_score==0:
            return "No confident match in schema corpus. Provide deduction/section/field."
        return f"Best matching schema: {os.path.basename(best)} (score {best_score})."

# Backward compat
def launch_headless_chrome(url, download_dir=None, headless=False):
    return launch_chrome(url, download_dir, headless=headless)
