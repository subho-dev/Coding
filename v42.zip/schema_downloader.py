
# schema_downloader.py (robust)
import os, time, shutil, re, pathlib, json
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

PORTAL_URL = "https://incometax.gov.in/iec/foportal/downloads/income-tax-returns"

def safe_name(s):
    return re.sub(r'[^A-Za-z0-9_\\-\\.]', '_', s)

def headless_driver(download_dir):
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-gpu")
    prefs={"download.default_directory": os.path.abspath(download_dir),
           "download.prompt_for_download": False,"download.directory_upgrade": True}
    opts.add_experimental_option("prefs", prefs)
    return webdriver.Chrome(ChromeDriverManager().install(), options=opts)

def _requests_first(dest_root, ay: str, itr: str):
    os.makedirs(dest_root, exist_ok=True)
    r = requests.get(PORTAL_URL, timeout=20); r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    # look for json links
    links = [a["href"] for a in soup.select("a[href]")]
    targets = [u for u in links if re.search(rf"{itr}.*json|schema.*{itr}.*json", u, re.I)]
    for url in targets:
        try:
            if not url.startswith("http"): continue
            jr = requests.get(url, timeout=20); jr.raise_for_status()
            folder = os.path.join(dest_root, f"{ay}_{itr}")
            os.makedirs(folder, exist_ok=True)
            fname = os.path.join(folder, os.path.basename(url.split("?")[0]))
            with open(fname,"wb") as f: f.write(jr.content)
            return folder, f"Downloaded via requests: {fname}"
        except Exception:
            continue
    return None, None

def download_schema_for_ay(ay: str, itr: str, dest_root="schemas"):
    # Try direct requests discovery first
    folder, msg = _requests_first(dest_root, ay, itr)
    if folder: return folder, msg
    # Fallback to selenium
    tmp = os.path.join(dest_root, "_tmp_dl"); os.makedirs(tmp, exist_ok=True)
    driver = headless_driver(tmp)
    try:
        driver.get(PORTAL_URL)
        WebDriverWait(driver, 20).until(EC.presence_of_all_elements_located((By.TAG_NAME,"a")))
        anchors = [a.get_attribute("href") for a in driver.find_elements(By.TAG_NAME,"a") if a.get_attribute("href")]
        targets = [u for u in anchors if re.search(rf"{itr}.*json|schema.*{itr}.*json", u, re.I)]
        saved=[]
        for url in targets:
            try:
                import requests
                jr=requests.get(url, timeout=20); jr.raise_for_status()
                folder = os.path.join(dest_root, f"{ay}_{itr}")
                os.makedirs(folder, exist_ok=True)
                fname = os.path.join(folder, os.path.basename(url.split("?")[0]))
                with open(fname,"wb") as f: f.write(jr.content)
                saved.append(fname)
            except Exception: pass
        if saved:
            return os.path.dirname(saved[0]), f"Selenium discovered and saved {len(saved)} file(s)."
        raise RuntimeError("No schema links found")
    finally:
        try: driver.quit()
        except: pass

def decide_applicable_itr(total_income: float, has_business: bool=False, has_capital_gains: bool=False):
    if has_business or total_income>5000000: return "itr-3"
    if has_capital_gains: return "itr-2"
    return "itr-1"

def bulk_fallback_all_years(fin_years, itr_ids=( "itr-1","itr-2","itr-3","itr-4"), dest_root="schemas"):
    msgs=[]
    for fy in fin_years:
        for itr in itr_ids:
            try:
                folder,msg = download_schema_for_ay(fy, itr, dest_root=dest_root)
                msgs.append(f"{fy}/{itr}: {msg}")
            except Exception as e:
                msgs.append(f"{fy}/{itr}: failed {e}")
    return msgs
