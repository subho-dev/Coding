# Project README

## Offline Chatbot Integration

This project now supports **fully offline chatbot functionality** with the following features:

### 🔹 Models
- **Primary:** LLaMA-2-7B-Chat (Quantized)
- **Fallback:** GPT4All Falcon (Quantized)
- Both downloaded automatically on first run and stored in `/models`

### 🔹 Manual Download (if needed)
- [LLaMA-2-7B-Chat (Quantized)](https://huggingface.co/TheBloke/Llama-2-7B-Chat-GGML)
- [GPT4All Falcon (Quantized)](https://huggingface.co/nomic-ai/gpt4all)
- Place them in `/models`

### 🔹 Knowledge Base
- Auto-created on first run in `/chatbot/db/`
  - SQLite DB for structured info
  - FAISS index for semantic search

### 🔹 Behavior
- Learns from user corrections
- Cross-questions if query ambiguous
- Reloads memory on restart
- CPU-only (no GPU required)

### 🔹 Folder Structure
```
project_root/
  ├── app_streamlit_itr_only_v30.py   # Streamlit entry
  ├── app.py                          # FastAPI backend
  ├── models/                         # Auto-downloaded models
  ├── chatbot/
  │     ├── db/                       # Auto-created KB + FAISS
  │     ├── utils.py
  │     └── nlp_engine.py
  ├── static/
  ├── templates/
  ├── README.md
  └── requirements.txt
```
