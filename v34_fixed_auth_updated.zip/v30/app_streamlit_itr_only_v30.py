
st.markdown('''
    <style>
    /* Chatbot FAB bottom-right */
    .chatbot-fab { position: fixed; right: 22px; bottom: 22px; z-index: 1000; }
    .chatbot-fab button { border-radius: 9999px; padding: 14px 16px; box-shadow: 0 8px 20px rgba(0,0,0,0.25); }
    /* Popup sizing */
    .chatbot-popup { position: fixed; right: 22px; bottom: 90px; width: 380px; height: 560px; max-height: 70vh;
                     background: var(--card, #0b0f1a); color: var(--text, #f5f7fa); border-radius: 16px;
                     box-shadow: 0 16px 40px rgba(0,0,0,0.4); overflow: hidden; display: none; }
    .chatbot-popup.show { display: block; animation: slideUp .25s ease-out; }
    @keyframes slideUp { from { transform: translateY(16px); opacity: 0 } to { transform: translateY(0); opacity:1 } }
    /* Header icons */
    .chatbot-header { display:flex; align-items:center; justify-content:space-between; padding:10px 12px; background: rgba(255,255,255,0.04); backdrop-filter: blur(8px); }
    .chatbot-actions i { cursor:pointer; margin-left:10px; opacity:.9; transition: transform .15s ease; }
    .chatbot-actions i:hover { transform: scale(1.1); }
    /* Modern export button */
    .export-btn { border:none; border-radius:12px; padding:10px 14px; background: linear-gradient(135deg,#7c4dff,#00e5a8);
                  color:white; font-weight:600; box-shadow: 0 6px 14px rgba(124,77,255,.35); cursor:pointer; }
    /* Smooth transitions common */
    .menu-card { transition: transform .15s ease, box-shadow .15s ease; }
    .menu-card:hover { transform: translateY(-2px); box-shadow: 0 10px 24px rgba(0,0,0,.18); }
    /* High contrast */
    :root { --bg:#0B1220; --card:#131C2B; --text:#F2F4F7; --muted:#9AA4B2; --accent:#00E5A8; }
    .dark .stApp { background: var(--bg) !important; color: var(--text) !important; }
    </style>
''', unsafe_allow_html=True)


# app_streamlit_itr_only_v33.py - merged v33
import os, io, time, traceback, yaml, glob, re, json, base64, threading, requests as _requests
import streamlit as st, pandas as pd, numpy as np, requests, feedparser
import plotly.express as px
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from fetcher import fetch_from_sources
from schema_downloader import decide_applicable_itr, download_schema_for_ay, bulk_fallback_all_years
from autopilot import launch_headless_chrome, CAHelper
st.set_page_config(page_title="ITR Assistant v33", layout="wide", initial_sidebar_state="expanded")

# --- Auth helpers (Streamlit) ---
if "auth" not in st.session_state:
    st.session_state.auth = {"user_id": None, "username": None, "guest": True}

API_BASE = "http://localhost:8000"

def api_post(path, json_data):
    try:
        r = _requests.post(f"{API_BASE}{path}", json=json_data, timeout=20)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f"Server error: {e}")
        return None

def auth_gate():
    c1,c2,c3,c4 = st.columns(4)
    with c1: tab_login = st.button("🔐 Login")
    with c2: tab_signup = st.button("🆕 Sign up")
    with c3: tab_guest = st.button("🧭 Continue as Guest")
    with c4: tab_forgot = st.button("❓ Forgot Password")

    if "auth_tab" not in st.session_state:
        st.session_state.auth_tab = "login"
    if tab_login: st.session_state.auth_tab = "login"
    if tab_signup: st.session_state.auth_tab = "signup"
    if tab_guest: st.session_state.auth_tab = "guest"
    if tab_forgot: st.session_state.auth_tab = "forgot"

    st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)

    if st.session_state.auth_tab == "login":
        st.subheader("Welcome back")
        ident = st.text_input("Username or Email", key="login_ident")
        pw = st.text_input("Password", type="password", key="login_pw")
        otp = st.text_input("OTP (if enabled)", type="password", key="login_otp")
        if st.button("Login ▶"):
            if not ident or not pw:
                st.warning("Please enter both identifier and password.")
            else:
                resp = api_post("/api/auth/login", {"identifier": ident, "password": pw, "otp": otp})
                if resp and resp.get("ok"):
                    st.session_state.auth = {"user_id": resp["user_id"], "username": resp["username"], "guest": False}
                    st.success("Logged in!")
                    st.experimental_rerun()

    elif st.session_state.auth_tab == "signup":
        st.subheader("Create your account")
        u = st.text_input("Username (3-24 letters/digits . _ -)")
        e = st.text_input("Email")
        p = st.text_input("Password (8+ chars, letters & numbers)", type="password")
        p2 = st.text_input("Confirm Password", type="password")
        enable_totp = st.checkbox("Enable 2‑step verification (Authenticator app)")
        if st.button("Sign up ✅"):
            if not re.match(r"^[A-Za-z0-9_.-]{3,24}$", u or ""):
                st.warning("Invalid username.")
            elif not re.match(r"^[^@]+@[^@]+\.[^@]+$", e or ""):
                st.warning("Invalid email.")
            elif p != p2:
                st.warning("Passwords do not match.")
            else:
                resp = api_post("/api/auth/signup", {"username": u, "email": e, "password": p, "enable_totp": enable_totp})
                if resp and resp.get("ok"):
                    st.success("Account created! Please login.")
                    if resp.get("totp_uri"):
                        st.info("Scan this with Google Authenticator, Authy, etc.:")
                        st.code(resp["totp_uri"])
                        # Optional QR (simple text fallback to avoid heavy deps in Streamlit front)
                    st.session_state.auth_tab = "login"

    elif st.session_state.auth_tab == "guest":
        st.subheader("Continue as Guest")
        st.caption("Your data (themes & history) will be kept only for this session and discarded when you close the app.")
        if st.button("Enter as Guest 🚀"):
            st.session_state.auth = {"user_id": None, "username": "Guest", "guest": True}
            st.experimental_rerun()

    else:  # forgot
        st.subheader("Forgot Password")
        ident = st.text_input("Username or Email")
        if st.button("Send Reset Code"):
            resp = api_post("/api/auth/forgot", {"identifier": ident})
            if resp and resp.get("ok"):
                st.success("Reset code generated. Enter it below to set a new password.")
                st.session_state.reset_uid = resp["user_id"]
                st.session_state.reset_code_hint = resp.get("code")  # In real life we wouldn't show it; shown for demo
                if st.session_state.reset_code_hint:
                    st.info(f"(Demo) Code: {st.session_state.reset_code_hint}")
        code = st.text_input("Enter Reset Code")
        npw = st.text_input("New Password", type="password")
        npw2 = st.text_input("Confirm New Password", type="password")
        if st.button("Reset Password 🔁"):
            if npw != npw2:
                st.warning("Passwords do not match.")
            else:
                resp = api_post("/api/auth/reset", {"user_id": st.session_state.get("reset_uid"), "code": code, "new_password": npw})
                if resp and resp.get("ok"):
                    st.success("Password updated. Please log in.")
                    st.session_state.auth_tab = "login"

# Ensure backend is up (best-effort)
st.sidebar.markdown("")

if st.session_state.auth.get('user_id') is None and st.session_state.auth.get('guest'):
    st.markdown('<div class="hero"><h2>Welcome to ITR Assistant</h2><p>Login, sign up, or continue as guest.</p></div>', unsafe_allow_html=True)
    auth_gate()
    st.stop()

LOG="itr_v33_log.txt"
def log(msg):
    try:
        with open(LOG,"a",encoding="utf-8") as f: f.write(f"{time.time()} - {msg}\n")
    except: pass

# Theme system
THEME_FILE="themes.yaml"
DEFAULT_THEMES={"Neo Dark":{"bg":"#0b0f1a","card":"#111827","text":"#E5F0FF","muted":"#9FB8D6","accent":"#7AFCFF"},
                "Ink Black":{"bg":"#00040A","card":"#0B1220","text":"#F1F5F9","muted":"#98A2B3","accent":"#00E5A8"},
                "Light Contrast":{"bg":"#F6FAFF","card":"#FFFFFF","text":"#0B1220","muted":"#5B6777","accent":"#006D77"}}
def load_themes():
    if os.path.exists(THEME_FILE):
        try:
            with open(THEME_FILE,"r",encoding="utf-8") as f: return yaml.safe_load(f)
        except: return DEFAULT_THEMES.copy()
    return DEFAULT_THEMES.copy()
def save_themes(th): 
    try:
        with open(THEME_FILE,"w",encoding="utf-8") as f: yaml.safe_dump(th,f,sort_keys=False)
    except Exception as e: log(f"save themes err {e}")

if "themes" not in st.session_state: st.session_state.themes = load_themes()
if "theme_name" not in st.session_state: st.session_state.theme_name = list(st.session_state.themes.keys())[0]
def apply_theme(name):
    th = st.session_state.themes.get(name, list(st.session_state.themes.values())[0])
    css = f"""
    <style>
    :root{{--bg:{th['bg']};--card:{th['card']};--text:{th['text']};--muted:{th['muted']};--accent:{th['accent']};}}
    .appview-container{{background:var(--bg);}}
    .card{{background:var(--card);border-radius:12px;padding:14px;color:var(--text);margin-bottom:12px}}
    .hero{{background:linear-gradient(90deg,#03396c,#006d77);padding:20px;border-radius:12px;color:var(--text);margin-bottom:12px}}
    .muted{{color:var(--muted)}}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)
apply_theme(st.session_state.theme_name)

menu = st.sidebar.radio("Navigate", ["🏠 Overview","🧾 ITR Assistant","🧩 Regime Manager","🤖 Autopilot","🎨 Themes","📰 Newsletter","⚙️ Settings"], index=0)

# defaults
DEFAULT_CFG = {"regimes":{"old":{"name":"Old Regime","cess_percent":4,"slabs":[{"upto":250000,"rate":0},{"upto":500000,"rate":5},{"upto":1000000,"rate":20},{"upto":None,"rate":30}],"deduction_limits":{"80C":150000},"explanation":"Old Regime"},"new":{"name":"New Regime","cess_percent":4,"slabs":[{"upto":300000,"rate":0},{"upto":600000,"rate":5},{"upto":900000,"rate":10},{"upto":1200000,"rate":15},{"upto":1500000,"rate":20},{"upto":2000000,"rate":25},{"upto":None,"rate":30}],"deduction_limits":{"80C":0},"explanation":"New Regime"}},"sources":[]}

if "cfg" not in st.session_state:
    if os.path.exists("regimes.yaml"):
        try:
            with open("regimes.yaml","r",encoding="utf-8") as f: st.session_state.cfg = yaml.safe_load(f)
        except Exception:
            st.session_state.cfg = DEFAULT_CFG.copy()
    else:
        st.session_state.cfg = DEFAULT_CFG.copy()

# tax calc utilities
def calc_tax_contrib(taxable, slabs):
    parts=[]; tax=0.0; rem=taxable; lower=0.0
    for s in slabs:
        upto=s.get("upto"); rate=float(s.get("rate",0))/100.0
        if upto is None:
            amt=max(0.0,rem); t=amt*rate; tax+=t; parts.append((f"{lower:+,.0f}+", rate*100, amt, t)); break
        slab_amt = max(0.0, min(rem, float(upto)-lower)); t=slab_amt*rate; tax+=t; parts.append((f"{lower:,.0f}-{float(upto):,.0f}", rate*100, slab_amt, t))
        rem-=slab_amt; lower=float(upto)
        if rem<=0: break
    return parts, tax
def calc_tax(taxable, slabs, cess):
    parts, pre = calc_tax_contrib(taxable, slabs)
    tax = pre + pre*(float(cess)/100.0)
    return max(0.0,tax), parts
def compute(incomes,deductions,cfg):
    total=sum(float(v) for v in incomes.values())
    out={}
    for key,reg in cfg.get("regimes",{}).items():
        dl=reg.get("deduction_limits",{}) or {}
        used=0.0
        for dkey,amt in deductions.items():
            lim=dl.get(dkey,None); a=float(amt)
            used += a if lim is None else min(a, float(lim))
        taxable=max(0.0, total-used)
        tax, parts = calc_tax(taxable, reg.get("slabs",[]), reg.get("cess_percent",4))
        out[key]={"name":reg.get("name",key),"tax":tax,"taxable":taxable,"ded_used":used,"explanation":reg.get("explanation",""),"parts":parts}
    return total, out

# automatically ensure schemas at startup in background
def ensure_schemas_background(years=None):
    import threading
    years = years or ["2025-26","2024-25","2023-24"]
    def job():
        try:
            from schema_downloader import bulk_fallback_all_years
            bulk_fallback_all_years(years, dest_root=".")
        except Exception as e:
            log(f"background schema fetch error: {e}")
    if "schema_thread" not in st.session_state:
        t = threading.Thread(target=job, daemon=True); t.start(); st.session_state.schema_thread=True

ensure_schemas_background()

# Pages
if menu=="🏠 Overview":
    st.markdown('<div class="hero"><h2>ITR Assistant v33</h2><p class="muted">Schema-aware • Autopilot • Themeable • Beginner-friendly</p></div>', unsafe_allow_html=True)
    left,right = st.columns([2,1], gap="large")
    with left:
        steps = [("Collect Documents","Gather Form16, AIS/26AS, bank interest, capital statements."),
                 ("Enter Income","Enter salary, business, capital gains, other income."),
                 ("Deductions","Enter deductions you will claim; app caps per regime."),
                 ("Compare & Choose","We compute taxes under available regimes and recommend the best."),
                 ("File","Use Copilot to open portal and follow steps; OTP remains manual."),
                 ("Export","Save detailed PDF with schema references.")]
        for i,(t,d) in enumerate(steps,1):
            st.markdown(f'<div class="card"><b>{i}. {t}</b><div class="muted">{d}</div></div>', unsafe_allow_html=True)
    with right:
        st.markdown('<div class="card"><h4>📰 Newsletter</h4><div class="muted">Official updates</div></div>', unsafe_allow_html=True)
        try:
            rss = "https://www.incometax.gov.in/iec/foportal/rss"
            feed = feedparser.parse(rss)
            items = [{"title":e.get("title",""), "link":e.get("link","#")} for e in feed.get("entries",[])[:6]]
            if not items:
                src = "https://www.incometax.gov.in/iec/foportal/en/news-and-updates"
                r=requests.get(src, timeout=10); from bs4 import BeautifulSoup; soup=BeautifulSoup(r.text,"html.parser")
                items=[] 
                for a in soup.select("a"):
                    txt = a.get_text(" ", strip=True)
                    if txt and len(txt)>25:
                        href = a.get("href","#"); 
                        if not href.startswith("http"): href = requests.compat.urljoin(src, href)
                        items.append({"title":txt,"link":href})
                        if len(items)>=6: break
            if not items:
                st.caption("No news available right now.")
            else:
                idx = int(time.time()//3) % len(items)
                it = items[idx]; st.markdown(f"[{it['title']}]({it['link']})")
                if st.button("🔄 Refresh News"):
                    st.experimental_rerun()
        except Exception as e:
            st.error("News error"); log(str(e))

if menu=="🧾 ITR Assistant":
    st.markdown('<div class="card"><h3>ITR Assistant — schema-aware</h3><div class="muted">Select AY, enter income & deductions; we auto-suggest ITR and can fetch official schema.</div></div>', unsafe_allow_html=True)
    try:
        col1,col2 = st.columns([2,1])
        with col1:
            name = st.text_input("Full name")
            pan = st.text_input("PAN").upper()
            fy = st.selectbox("Assessment Year (AY)", ["2025-26","2024-25","2023-24"], index=1)
            salary = st.number_input("Salary (₹)", value=700000.0)
            business = st.number_input("Business (₹)", value=0.0)
            capg = st.number_input("Capital gains (₹)", value=0.0)
            other = st.number_input("Other income (₹)", value=5000.0)
            d80c = st.number_input("80C (₹)", value=150000.0)
            d80d = st.number_input("80D (₹)", value=25000.0)
            home = st.number_input("Home loan interest (₹)", value=200000.0)
            d80g = st.number_input("80G (₹)", value=0.0)
        with col2:
            resident = st.checkbox("Resident?", value=True)
            presumptive = st.checkbox("Presumptive income (44AD/44ADA/44AE)?", value=False)
            multi_house = st.checkbox("Multiple house property?", value=False)
            st.markdown("### Schema tools")
            if st.button("Fetch schema for selected AY/ITR (headless)"):
                itr_id = decide_applicable_itr({"salary":salary,"business":business,"capital_gains":capg,"other":other,"presumptive":presumptive,"multiple_house_property":multi_house})
                try:
                    folder,msg = download_schema_for_ay(fy, itr_id, dest_root=".")
                    st.success(f"{msg} -> {folder}")
                except Exception as e:
                    st.error(f"Schema fetch failed: {e}")
            if st.button("Bulk prefetch schemas (all AYs)"):
                try:
                    years=["2025-26","2024-25","2023-24"]
                    msgs = bulk_fallback_all_years(years, dest_root=".")
                    st.success("Bulk attempt done. See logs for details.")
                except Exception as e:
                    st.error(f"Bulk fetch failed: {e}")
        incomes = {"salary":salary,"business":business,"capital_gains":capg,"other":other}
        deductions = {"80C":d80c,"80D":d80d,"home_loan_interest":home,"80G":d80g}
        total, out = compute(incomes,deductions,st.session_state.cfg)
        df = pd.DataFrame(out).T.reset_index().rename(columns={"index":"regime"})
        st.metric("Total Income", f"₹{total:,.0f}"); st.dataframe(df[["name","tax","taxable","ded_used"]].rename(columns={"name":"Regime","tax":"Tax (₹)","taxable":"Taxable (₹)","ded_used":"Deductions Used (₹)"}).style.format({"Tax (₹)":"{:.0f}"}), height=240)
        st.plotly_chart(px.bar(pd.DataFrame(out).T.reset_index().rename(columns={"index":"regime"}) , x="regime", y="tax"), use_container_width=True)
        itr_id = decide_applicable_itr({"salary":salary,"business":business,"capital_gains":capg,"other":other,"presumptive":presumptive,"multiple_house_property":multi_house})
        st.info(f"Suggested ITR: {itr_id.upper()}")
        with st.expander("Step-by-step filing (with screenshots if available)", expanded=True):
            steps = ["Login to e-filing portal","Select AY and regime","Enter incomes","Apply deductions","Preview & submit","E-verify"]
            cols = st.columns(3)
            for i,s in enumerate(steps):
                idx = i%3
                img = f"assets/images/step{i+1}.png"
                if os.path.exists(img):
                    cols[idx].image(img, use_container_width=True, caption=s)
                else:
                    cols[idx].write(s)
        with st.expander("How to use Copilot (interactive)", expanded=False):
            st.write("Copilot launches headless browser and a helper chat. You must complete login & OTP manually for security.")
            if st.button("Launch Copilot (headless)"):
                try:
                    schema_dir = os.path.join(".", f"regimes_schema_{fy}")
                    driver = launch_headless_chrome("https://www.incometax.gov.in/iec/foportal/downloads/income-tax-returns", download_dir=schema_dir, headless=True)
                    st.session_state.driver = True; st.success("Headless browser launched. Complete login & OTP in the opened session.")
                    # start CA helper
                    if "ca_helper" not in st.session_state or st.session_state.get("ca_helper_dir")!=schema_dir:
                        helper = CAHelper(schema_dir); helper.start(); st.session_state.ca_helper = helper; st.session_state.ca_helper_dir = schema_dir
                except Exception as e:
                    st.error(f"Copilot launch failed: {e}")
            if st.button(""):
                q = st.text_input("Question for CA")
                if q:
                    helper = st.session_state.get("ca_helper", None)
                    if helper:
                        helper.ask(q); time.sleep(0.2); ans = helper.get_answer(timeout=2)
                        if ans: st.info(ans)
                    else:
                        st.warning("Start Copilot first to enable the CA helper.")
        if st.button("Export PDF (detailed)"):
            try:
                buffer = io.BytesIO(); doc = SimpleDocTemplate(buffer, pagesize=A4)
                styles = getSampleStyleSheet(); story=[]
                story.append(Paragraph("ITR Summary", styles["Title"])); story.append(Spacer(1,6))
                story.append(Paragraph(f"Name: {name} | PAN: {pan} | AY: {fy}", styles["Normal"])); story.append(Spacer(1,6))
                comp=[["Regime","Taxable","Tax","Deductions Used"]]
                for k,v in out.items():
                    comp.append([v["name"], f"{v['taxable']:,.0f}", f"{v['tax']:,.0f}", f"{v['ded_used']:,.0f}"])
                tc = Table(comp); tc.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.5,"#444444")])); story.append(tc)
                doc.build(story); buffer.seek(0); st.download_button("Download PDF", data=buffer.getvalue(), file_name="ITR_Summary_v33.pdf", mime="application/pdf")
            except Exception as e:
                st.error(f"PDF failed: {e}"); log(str(e))
    except Exception as e:
        st.error("ITR Assistant error"); log(str(e))

if menu=="🧩 Regime Manager":
    st.markdown('<div class="card"><h3>Regime Manager</h3><div class="muted">Edit regimes in table and save to yaml/json sources.</div></div>', unsafe_allow_html=True)
    try:
        regs = st.session_state.cfg.get("regimes",{})
        rows = []
        for key,reg in regs.items():
            rows.append({"key":key,"name":reg.get("name",""),"cess":reg.get("cess_percent",4),"slabs":yaml.safe_dump(reg.get("slabs",[])),"deduction_limits":yaml.safe_dump(reg.get("deduction_limits",{})),"explanation":reg.get("explanation","")})
        df = pd.DataFrame(rows)
        edited = st.data_editor(df, use_container_width=True, num_rows="dynamic")
        if st.button("Save config from table"):
            newr={}
            for _,r in edited.iterrows():
                try:
                    slabs = yaml.safe_load(r["slabs"] or "[]"); dlims = yaml.safe_load(r["deduction_limits"] or "{}")
                    newr[r["key"]] = {"name":r["name"], "cess_percent":float(r["cess"]), "slabs":slabs, "deduction_limits":dlims, "explanation": r["explanation"]}
                except Exception as e:
                    st.error(f"Parse error: {e}"); raise
            st.session_state.cfg["regimes"] = newr; st.success("Saved to session. Use Save to disk to persist.")
        if st.button("Save to disk (regimes.yaml)"):
            with open("regimes.yaml","w",encoding="utf-8") as f: yaml.safe_dump(st.session_state.cfg, f, sort_keys=False)
            st.success("Saved regimes.yaml")
    except Exception as e:
        st.error("Regime Manager error"); log(str(e))

if menu=="🤖 Autopilot":
    st.markdown('<div class="card"><h3>Autopilot</h3><div class="muted">Start headless Chrome and keep helper alive for guided filing.</div></div>', unsafe_allow_html=True)
    try:
        ay = st.selectbox("Schema AY", ["2025-26","2024-25","2023-24"], index=1)
        itr = st.selectbox("ITR form", ["itr-1","itr-2","itr-3","itr-4"], index=0)
        schema_dir = os.path.join(".", f"regimes_schema_{ay}")
        if st.button("Start Autopilot & helper"):
            try:
                driver = launch_headless_chrome("https://www.incometax.gov.in/iec/foportal/downloads/income-tax-returns", download_dir=schema_dir, headless=True)
                st.session_state.driver_alive = True
                st.success("Headless Chrome started. The helper has access to schemas in " + schema_dir)
                if "ca_helper" not in st.session_state or st.session_state.ca_helper_dir != schema_dir:
                    helper = CAHelper(schema_dir); helper.start(); st.session_state.ca_helper = helper; st.session_state.ca_helper_dir = schema_dir
            except Exception as e:
                st.error(f"Autopilot start failed: {e}"); log(str(e))
        if st.button("Stop Autopilot & helper"):
            try:
                if "ca_helper" in st.session_state: st.session_state.ca_helper.stop()
                st.session_state.driver_alive = False; st.success("Stopped helper")
            except Exception as e:
                st.error(f"Stop failed: {e}"); log(str(e))
        if st.button(" (example)"):
            q = st.text_input("Question to CA (schema-aware)")
            if q and "ca_helper" in st.session_state:
                st.session_state.ca_helper.ask(q); time.sleep(0.2); ans = st.session_state.ca_helper.get_answer(timeout=2)
                if ans:
                    st.info(ans)
                else:
                    st.warning("No answer yet.")
    except Exception as e:
        st.error("Autopilot error"); log(str(e))

if menu=="🎨 Themes":
    st.markdown('<div class="card"><h3>Themes</h3><div class="muted">Presets + Custom colors (saved to themes.yaml)</div></div>', unsafe_allow_html=True)
    try:
        names = list(st.session_state.themes.keys())
        sel = st.selectbox("Preset", names, index=names.index(st.session_state.theme_name) if st.session_state.theme_name in names else 0)
        if st.button("Apply preset"):
            st.session_state.theme_name = sel
            apply_theme(sel)
            st.query_params["theme"]=sel
        cur = st.session_state.themes.get(st.session_state.theme_name, list(st.session_state.themes.values())[0])
        bg = st.color_picker("Background", cur["bg"])
        card = st.color_picker("Card", cur["card"])
        text = st.color_picker("Text", cur["text"])
        muted = st.color_picker("Muted", cur["muted"])
        accent = st.color_picker("Accent", cur["accent"])
        name = st.text_input("Save as theme name", value="My Theme")
        if st.button("Save custom theme"):
            st.session_state.themes[name] = {"bg":bg,"card":card,"text":text,"muted":muted,"accent":accent}
            save_themes(st.session_state.themes); st.success("Saved theme")
    except Exception as e:
        st.error(e)
        log(str(e))

if menu=="📰 Newsletter":
    st.markdown('<div class="card"><h3>Newsletter</h3><div class="muted">Official Income Tax updates</div></div>', unsafe_allow_html=True)
    try:
        rss = "https://www.incometax.gov.in/iec/foportal/rss"
        feed = feedparser.parse(rss)
        items = [{"title":e.get("title",""), "link":e.get("link","#")} for e in feed.get("entries",[])[:6]]
        if not items:
            st.caption("No news found.")
        else:
            idx = int(time.time()//3) % len(items)
            it = items[idx]; st.markdown(f"[{it['title']}]({it['link']})")
            if st.button("🔄 Refresh News"):
                st.experimental_rerun()
    except Exception as e:
        st.error("News fetch error"); log(str(e))

if menu=="⚙️ Settings":
    st.markdown('<div class="card"><h3>Settings & Diagnostics</h3></div>', unsafe_allow_html=True)
    try:
        if st.button("Reset session"): 
            for k in list(st.session_state.keys()): del st.session_state[k]
            st.success("Session cleared")
        if os.path.exists(LOG) and st.button("Clear log"): os.remove(LOG); st.success("Log cleared")
        st.markdown("#### Log tail")
        if os.path.exists(LOG):
            with open(LOG,"r",encoding="utf-8") as f: st.text("".join(f.readlines()[-200:]))
        else:
            st.caption("No logs yet.")
    except Exception as e:
        st.error("Settings error"); log(str(e))


# Floating Action Button (FAB) on all pages



# ===== Start local FastAPI backend in a background thread =====
def _ensure_backend():
    if st.session_state.get("_backend_started"): 
        return
    import threading, uvicorn, sys, importlib, time
    sys.path.append(os.path.dirname(__file__))
    # import the app
    from server.app import app as _fastapi_app
    def _run():
        uvicorn.run(_fastapi_app, host="127.0.0.1", port=7860, log_level="warning")
    t = threading.Thread(target=_run, daemon=True)
    t.start()
    # small wait for port to open
    time.sleep(0.5)
    st.session_state["_backend_started"] = True

_ensure_backend()

# ===== Inject chatbot FAB & modal via components.html (isolated iframe) =====
import streamlit.components.v1 as components
components.html("""
<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'/>
<style>
:root {
  --bot:#2563eb; --bg:#0f172a; --white:#fff; --shadow:rgba(0,0,0,.35);
}
* { box-sizing:border-box; }
#ca-fab {
  position:fixed; right:24px; bottom:24px; width:64px; height:64px; border-radius:50%;
  background:var(--bot); display:flex; align-items:center; justify-content:center; 
  box-shadow:0 10px 20px var(--shadow); cursor:pointer; z-index:999999;
  animation:glow 2.2s infinite ease-in-out;
}
#ca-fab svg { width:34px; height:34px; fill:white; }
@keyframes glow {
  0%{ box-shadow:0 0 0 0 rgba(37,99,235,.6); } 
  70%{ box-shadow:0 0 0 18px rgba(37,99,235,0); } 
  100%{ box-shadow:0 0 0 0 rgba(37,99,235,0); }
}
#mini-dock {
  position:fixed; right:24px; bottom:24px; display:none; align-items:center; gap:10px; z-index: 999999;
}
#mini-icon { width:220px; height:48px; border-radius:24px; background:#1f2937; display:flex; align-items:center; padding:0 12px; color:#fff; cursor:pointer; box-shadow:0 8px 16px var(--shadow); }
#mini-icon .badge { background:#ef4444; color:white; border-radius:999px; padding:2px 7px; font-size:12px; margin-left:8px; }
#mini-actions button { margin-left:6px; }
.modal-mask {
  position:fixed; inset:0; background:rgba(0,0,0,.35); display:none; place-items:center; z-index: 999998;
}
.modal {
  width: min(900px, 90vw); height: min(70vh, 680px); background:white; border-radius:16px; overflow:hidden; display:flex; flex-direction:column; box-shadow:0 20px 60px var(--shadow); 
}
.modal.fullscreen { width:100vw; height:100vh; border-radius:0; }
.modal .topbar { background:#0ea5e9; color:white; padding:12px 14px; display:flex; align-items:center; justify-content:space-between; font-weight:600; }
.modal .chat { flex:1; background:#f8fafc; padding:12px; overflow:auto; }
.modal .input { display:flex; gap:8px; border-top:1px solid #e5e7eb; padding:10px; background:white; }
.modal .input textarea{ flex:1; padding:8px; resize:none; outline:none; border:1px solid #cbd5e1; border-radius:10px; }
.modal .input button{ background:#2563eb; color:white; border:none; padding:10px 14px; border-radius:10px; cursor:pointer; }
.message{ max-width:80%; margin:6px 0; padding:10px 12px; border-radius:12px; line-height:1.45; }
.message.user{ margin-left:auto; background:#dbeafe; }
.message.bot{ background:#e5e7eb; }
.typing{ font-style:italic; opacity:.8; }
.controls button{ border:none; background:rgba(255,255,255,.2); color:white; padding:6px 10px; margin-left:6px; border-radius:8px; cursor:pointer; }
</style>
</head>
<body>
<div id="ca-fab" role="button" title="">
  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a7 7 0 016.93 6.03 5 5 0 012.02 8.57c.03.2.05.41.05.62 0 3.31-3.58 6-8 6s-8-2.69-8-6c0-.21.02-.42.05-.62A5 5 0 015.07 8.03 7 7 0 0112 2zm0 2a5 5 0 00-4.9 4.02l-.13.7-.7.12A3 3 0 006 14h1v2a1 1 0 00.55.9L10 18.76V16h4v2.76l2.45-1.86A1 1 0 0017 16v-2h1a3 3 0 00-.27-5.16l-.7-.12-.12-.7A5 5 0 0012 4z"/></svg>
</div>

<div id="mini-dock">
  <div id="mini-icon" title="Open chat"><span>ASK THE CA</span><span class="badge" id="unread">0</span></div>
  <div id="mini-actions">
    <button id="mini-restore">Restore</button>
    <button id="mini-max">Maximize</button>
    <button id="mini-close">Close</button>
    <button id="mini-export">Export</button>
  </div>
</div>

<div class="modal-mask" id="mask">
  <div class="modal" id="modal">
    <div class="topbar">
      <div>ASK THE CA</div>
      <div class="controls">
        <button id="btn-min">_</button>
        <button id="btn-max">[ ]</button>
        <button id="btn-close">×</button>
      </div>
    </div>
    <div class="chat" id="chat"></div>
    <div class="input">
      <textarea id="msg" rows="2" placeholder="Ask a CA, math, or code question..."></textarea>
      <button id="send">Send</button>
    </div>
  </div>
</div>

<script>
const API = "http://127.0.0.1:7860/api";
let mode = localStorage.getItem("ca_mode") || "popup"; // popup | full
let minimized = false;
let unread = 0;
let inactivityTimer = null;
let history = [];

const mask = document.getElementById('mask');
const modal = document.getElementById('modal');
const chat = document.getElementById('chat');
const input = document.getElementById('msg');
const sendBtn = document.getElementById('send');
const fab = document.getElementById('ca-fab');
const mini = document.getElementById('mini-dock');
const miniIcon = document.getElementById('mini-icon');
const unBadge = document.getElementById('unread');

function show(modeArg) {
  mode = modeArg || mode;
  localStorage.setItem("ca_mode", mode);
  mask.style.display = "grid";
  modal.classList.toggle('fullscreen', mode === 'full');
  fab.style.display='none';
  mini.style.display='none';
  minimized=false;
  resetInactivity();
}
function hide(clear=false) {
  mask.style.display = "none";
  fab.style.display='flex';
  if (clear) { history=[]; chat.innerHTML=""; unread=0; unBadge.innerText="0"; }
}
function minimize() {
  minimized=true;
  mask.style.display="none";
  mini.style.display="flex";
}
function restore() {
  minimized=false;
  mini.style.display="none";
  show(mode);
}

function addMessage(text, who) {
  const d = document.createElement('div');
  d.className='message '+who;
  d.textContent = text;
  chat.appendChild(d);
  chat.scrollTop = chat.scrollHeight;
}

function typing(on) {
  let el = document.getElementById('typing');
  if (on) {
    if (!el) {
      el = document.createElement('div');
      el.id='typing'; el.className='message bot typing';
      el.textContent='Thinking…';
      chat.appendChild(el);
    }
  } else if (el) {
    el.remove();
  }
}

async function send() {
  const text = input.value.trim();
  if (!text) return;
  addMessage(text,'user');
  history.push({role:'user', text});
  input.value = '';
  typing(true);
  resetInactivity();

  try {
    const res = await fetch(API + "/chat", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({message:text, history})
    });
    const data = await res.json();
    typing(false);
    addMessage(data.reply || '(no reply)','bot');
    history.push({role:'bot', text:data.reply || ''});
    if (minimized) { unread++; unBadge.innerText = String(unread); }
  } catch (e) {
    typing(false);
    addMessage("Error: "+e.message, 'bot');
  }
}

sendBtn.addEventListener('click', send);
input.addEventListener('keydown', e => { if (e.key==='Enter' && !e.shiftKey){ e.preventDefault(); send(); } });
fab.addEventListener('click', ()=>show('popup'));
document.getElementById('btn-min').addEventListener('click', minimize);
document.getElementById('btn-max').addEventListener('click', ()=> { mode = (mode==='full'?'popup':'full'); show(mode); });
document.getElementById('btn-close').addEventListener('click', ()=>{ hide(true); });
miniIcon.addEventListener('click', ()=>{ unread=0; unBadge.innerText='0'; restore(); });
document.getElementById('mini-restore').addEventListener('click', restore);
document.getElementById('mini-max').addEventListener('click', ()=>{ unread=0; unBadge.innerText='0'; show('full'); });
document.getElementById('mini-close').addEventListener('click', ()=>{ mini.style.display='none'; fab.style.display='flex'; unread=0; unBadge.innerText='0'; history=[]; chat.innerHTML=""; });
document.getElementById('mini-export').addEventListener('click', exportPdf);

function resetInactivity(){
  if (inactivityTimer) clearTimeout(inactivityTimer);
  inactivityTimer = setTimeout(()=>{ minimize(); }, 30000);
}
document.addEventListener('mousemove', resetInactivity);
document.addEventListener('keydown', resetInactivity);

// Export PDF
async function exportPdf(){
  try {
    const res = await fetch(API + "/export_pdf", {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({history})});
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href=url; a.download='ask-the-ca.pdf'; a.click();
    URL.revokeObjectURL(url);
  } catch(e){ console.error(e); }
}

// Restore mode state if opened from minimized
if (localStorage.getItem('ca_mode')==='full'){
  // start in popup until user opens explicitly
}
</script>
""", height=0)
# ================== Chatbot Settings Page (v30.1) ==================
def chatbot_settings_page():
    st.title("🤖 Chatbot Settings")

    st.subheader("General")
    demo_mode = st.checkbox("Enable Demo Mode", value=False, key="demo_mode_checkbox")
    if demo_mode:
        st.info("Demo Mode Active – You are seeing sample CA Q&A responses.")

    st.subheader("Voice Settings")
    voice_enabled = st.checkbox("Enable Voice Features", value=False, key="voice_checkbox")
    if voice_enabled:
        mode = st.radio("Choose Mode", ["Auto (Online+Offline fallback)", "Online Only", "Offline Only"], index=0)

    st.subheader("Themes")
    theme = st.radio("Chatbot Theme", ["Auto", "Dark", "Light"], index=0)

    st.subheader("Hotkeys")
    st.markdown("**Ctrl+Shift+C** → Open Chatbot instantly")
    st.markdown("**Ctrl+D** → Toggle Demo Mode")

    st.success("Settings saved automatically and persist across sessions.")

# Add navigation tab for settings (if multipage app structure exists)
if "page" in st.session_state and st.session_state.page == "Chatbot Settings":
    chatbot_settings_page()
# ===============================================================


# --- User-theme persistence hooks ---
def load_user_themes():
    try:
        r = _requests.get(f"{API_BASE}/api/health", timeout=5)  # simple ping
    except Exception:
        return
    # Themes are currently read from YAML; extend later to read from DB per user if implemented in UI

