
ITR Assistant v20
-----------------
Key additions:
- More detailed PDF: side-by-side taxes (Old/New), slab breakdown for the recommended regime,
  tailored filing steps with images, and Copilot usage.
- UI readability tightened for dark themes (always light text on dark backgrounds).
- Animated Overview with per-step descriptions + visuals.
- Theme Manager: presets + full custom (color pickers), saved to themes.yaml and restored automatically.
- Newsletter: 4–6 latest items from official site with rotating 3-second slider. Falls back gracefully.
- Dynamic regimes: auto-update via Regime Manager sources; fallback to local regimes.yaml/defaults.

Run:
1) python -m venv .venv && source .venv/bin/activate
2) pip install -r requirements.txt
3) streamlit run app_streamlit_itr_only_v20.py
