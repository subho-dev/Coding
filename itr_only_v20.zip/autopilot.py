
# autopilot.py - scaffold v20
import time, keyring, getpass
from selenium import webdriver
SERVICE="itr_assistant_v20"
def store_credentials(username,password):
    try:
        keyring.set_password(SERVICE, username, password); return True,"Stored"
    except Exception as e: return False,str(e)
def get_password(username):
    try: return keyring.get_password(SERVICE, username)
    except Exception: return None
def run_autopilot_login(url, username, password=None, headless=False):
    try:
        if password is None:
            password = get_password(username) or getpass.getpass("Enter password: ")
        opts = webdriver.ChromeOptions()
        if headless: opts.add_argument("--headless=new")
        opts.add_argument("--no-sandbox"); opts.add_argument("--disable-gpu")
        driver = webdriver.Chrome(options=opts); driver.get(url); time.sleep(2)
        return True, "Browser opened. Proceed to login & OTP."
    except Exception as e:
        return False, str(e)
