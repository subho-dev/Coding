
# app_streamlit_itr_only_v20.py
import os, io, time, traceback, json, datetime, math, base64, requests, yaml, feedparser
import streamlit as st, pandas as pd, numpy as np
import plotly.express as px
from bs4 import BeautifulSoup
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from fetcher import fetch_from_sources, merge_configs
from autopilot import run_autopilot_login
st.set_page_config(page_title="ITR Assistant v20", page_icon="🪄", layout="wide", initial_sidebar_state="expanded")
LOG="itr_v20_log.txt"

def log(msg):
    try:
        with open(LOG,"a",encoding="utf-8") as f: f.write(f"{datetime.datetime.utcnow().isoformat()} - {msg}\n")
    except: pass

# ---------- Theme System ----------
THEME_FILE="themes.yaml"
DEFAULT_THEMES={
    "Neo Dark": {"bg":"#0b0f1a","card":"#111827","text":"#E5F0FF","muted":"#9FB8D6","accent":"#7AFCFF"},
    "Ink Black": {"bg":"#00040A","card":"#0B1220","text":"#F1F5F9","muted":"#98A2B3","accent":"#00E5A8"},
    "Light Contrast": {"bg":"#F6FAFF","card":"#FFFFFF","text":"#0B1220","muted":"#5B6777","accent":"#006D77"}
}
def load_themes():
    if os.path.exists(THEME_FILE):
        try:
            with open(THEME_FILE,"r",encoding="utf-8") as f: return yaml.safe_load(f)
        except Exception as e:
            log(f"theme load failed: {e}")
    return DEFAULT_THEMES.copy()

def save_themes(themes):
    try:
        with open(THEME_FILE,"w",encoding="utf-8") as f: yaml.safe_dump(themes,f,sort_keys=False)
    except Exception as e:
        log(f"theme save failed: {e}")

if "themes" not in st.session_state:
    st.session_state.themes = load_themes()
if "theme_name" not in st.session_state:
    st.session_state.theme_name = "Neo Dark"

def apply_theme(name):
    th = st.session_state.themes.get(name, list(st.session_state.themes.values())[0])
    css = f"""
    <style>
    :root{{
      --bg:{th['bg']}; --card:{th['card']}; --text:{th['text']}; --muted:{th['muted']}; --accent:{th['accent']};
    }}
    .appview-container{{background:var(--bg);}}
    .stMarkdown, .stText, .stTextInput, .stRadio, .stSelectbox, .stNumberInput, .stDataFrame, .stMetric, label, .css-10trblm, .css-1dp5vir {{
      color: var(--text) !important;
    }}
    .card{{background:var(--card);border-radius:14px;padding:16px;backdrop-filter:blur(6px);box-shadow:0 10px 30px rgba(0,0,0,0.5);}}
    .hero{{background:radial-gradient(1200px 500px at top left, rgba(122,252,255,0.08), transparent), var(--card);
           padding:26px; border-radius:18px; color:var(--text); 
           box-shadow:0 14px 40px rgba(2,6,23,0.6); animation:float 4s ease-in-out infinite;}}
    @keyframes float{{0%{{transform:translateY(0);}}50%{{transform:translateY(-6px);}}100%{{transform:translateY(0);}}}}
    .muted{{color:var(--muted);}}
    a, .accent{{color:var(--accent);}}
    .menu-btn{{padding:12px;border-radius:12px;transition:all .18s;border:1px solid rgba(255,255,255,0.06);}}
    .menu-btn:hover{{transform:translateX(6px);}}
    .progress{{height:8px;border-radius:8px;background:rgba(255,255,255,0.08);overflow:hidden;}}
    .progress > div{{height:100%;background:linear-gradient(90deg,var(--accent),#b8fffd);width:0%;transition:width .6s ease;}}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)

apply_theme(st.session_state.theme_name)

# Sidebar with Theme quick button
menu = st.sidebar.radio("Navigate", ["🏠 Overview","🧾 ITR Assistant","🧩 Regime Manager","🤖 Autopilot","🎨 Themes","📰 Newsletter","⚙️ Settings"], index=0)

# ---------- Data & Config ----------
DEFAULT_CFG = {
    "regimes": {
        "old": {"name":"Old Regime","cess_percent":4,"slabs":[{"upto":250000,"rate":0},{"upto":500000,"rate":5},{"upto":1000000,"rate":20},{"upto":None,"rate":30}],
                "deduction_limits":{"80C":150000,"80D":25000,"home_loan_interest":200000,"80G":0},
                "explanation":"Legacy regime with broader deductions."},
        "new": {"name":"New Regime","cess_percent":4,"slabs":[{"upto":300000,"rate":0},{"upto":600000,"rate":5},{"upto":900000,"rate":10},{"upto":1200000,"rate":15},{"upto":1500000,"rate":20},{"upto":2000000,"rate":25},{"upto":None,"rate":30}],
                "deduction_limits":{"80C":0,"80D":0,"home_loan_interest":0,"80G":0},
                "explanation":"Simplified slabs; limited deductions."}
    },
    "sources": [], "_last_sync": None
}
if "cfg" not in st.session_state:
    if os.path.exists("regimes.yaml"):
        try:
            with open("regimes.yaml","r",encoding="utf-8") as f: st.session_state.cfg=yaml.safe_load(f)
        except Exception as e:
            st.session_state.cfg=DEFAULT_CFG; log(f"load regimes.yaml failed: {e}")
    else:
        st.session_state.cfg=DEFAULT_CFG

def calc_tax_contrib(taxable, slabs):
    parts=[]; tax=0.0; rem=taxable; lower=0.0
    for s in slabs:
        upto=s.get("upto"); rate=float(s.get("rate",0))/100.0
        if upto is None:
            amt=max(0.0, rem); t = amt*rate; tax+=t; parts.append((f"{lower:+,.0f}+", rate*100, amt, t)); break
        slab_amt = max(0.0, min(rem, float(upto)-lower))
        t = slab_amt*rate; tax+=t
        parts.append((f"{lower:,.0f}-{float(upto):,.0f}", rate*100, slab_amt, t))
        rem-=slab_amt; lower=float(upto)
        if rem<=0: break
    return parts, tax

def calc_tax(taxable, slabs, cess):
    parts, pre = calc_tax_contrib(taxable, slabs)
    tax = pre + pre*(float(cess)/100.0)
    return max(0.0,tax), parts

def compute(incomes,deductions,cfg):
    total=sum(float(v) for v in incomes.values())
    out={}
    for key,reg in cfg.get("regimes",{}).items():
        dl=reg.get("deduction_limits",{}) or {}
        used=0.0
        for dkey,amt in deductions.items():
            lim = dl.get(dkey, None)
            a=float(amt)
            used += a if lim is None else min(a, float(lim))
        taxable=max(0.0, total-used)
        tax, parts = calc_tax(taxable, reg.get("slabs",[]), reg.get("cess_percent",4))
        out[key]={"name":reg.get("name",key),"tax":tax,"taxable":taxable,"ded_used":used,"explanation":reg.get("explanation",""),"parts":parts}
    return total, out

# ---------- Images dynamic fetch with fallback ----------
FALLBACKS=[
 "assets/images/step1_collect_docs.png",
 "assets/images/step2_choose_regime.png",
 "assets/images/step3_enter_income.png",
 "assets/images/step4_apply_deductions.png",
 "assets/images/step5_preview_tax.png",
 "assets/images/step6_submit_everify.png",
]
DYNAMIC_URLS=[
 "https://raw.githubusercontent.com/placeholder/steps/main/step1.png",
 "https://raw.githubusercontent.com/placeholder/steps/main/step2.png",
 "https://raw.githubusercontent.com/placeholder/steps/main/step3.png",
 "https://raw.githubusercontent.com/placeholder/steps/main/step4.png",
 "https://raw.githubusercontent.com/placeholder/steps/main/step5.png",
 "https://raw.githubusercontent.com/placeholder/steps/main/step6.png",
]

def get_step_image(idx):
    try:
        url=DYNAMIC_URLS[idx]
        r=requests.get(url, timeout=3)
        if r.status_code==200 and r.content:
            b64=base64.b64encode(r.content).decode("ascii")
            return f"data:image/png;base64,{b64}"
    except Exception as e:
        pass
    return FALLBACKS[idx]

# ---------- Newsletter fetch ----------
NEWS_SOURCES=["https://www.incometax.gov.in/iec/foportal/en/news-and-updates","https://www.incometax.gov.in/iec/foportal/rss"]
def fetch_news(max_items=8):
    items=[]
    # try RSS
    try:
        feed = feedparser.parse(NEWS_SOURCES[1])
        for e in feed.get("entries", [])[:max_items]:
            items.append({"title":e.get("title","(untitled)"),"link":e.get("link","#"),"published":str(e.get("published","")), "summary":e.get("summary","")})
    except Exception as e:
        log(f"rss fail: {e}")
    if not items:
        # HTML scrape
        for src in NEWS_SOURCES:
            try:
                r=requests.get(src, timeout=10); r.raise_for_status()
                soup=BeautifulSoup(r.text,"html.parser")
                for a in soup.select("a, li")[:max_items*2]:
                    txt=a.get_text(" ", strip=True)
                    href=a.get("href","#")
                    if txt and len(txt)>25:
                        if not href.startswith("http"): href = requests.compat.urljoin(src, href)
                        items.append({"title":txt, "link":href, "published":"", "summary":""})
                    if len(items)>=max_items: break
                if items: break
            except Exception as e:
                log(f"news html fail: {e}")
    return items[:max_items]

def newsletter_slider():
    if "news" not in st.session_state or st.button("🔄 Refresh News"):
        st.session_state.news = fetch_news(6)
    news = st.session_state.get("news", [])
    if not news:
        st.caption("No news found right now.")
        return
    count=len(news); idx=int(time.time()//3)%count
    item=news[idx]
    st.markdown(f"**Latest ({idx+1}/{count})**")
    st.markdown(f"[{item['title']}]({item['link']})")
    if item.get("summary"): st.caption(item["summary"])

# ---------- Overview ----------
if menu=="🏠 Overview":
    st.markdown("<div class='hero'><h2>Welcome to ITR Assistant v20</h2><p class='muted'>Dynamic regimes • Animated guidance • Beginner-first UX</p></div>", unsafe_allow_html=True)
    left, right = st.columns([2,1], gap="large")
    with left:
        st.markdown("<div class='card'><h4>How it works</h4></div>", unsafe_allow_html=True)
        expl = [
            ("Collect", "Gather Form 16, AIS/26AS, bank/passbook interest, capital statements."),
            ("Compare", "Enter income & deductions. We calculate taxes under all regimes."),
            ("Decide", "We recommend the best regime, with reasoning and slab breakdown."),
            ("File", "Follow the tailored step-by-step guide or launch Copilot to open the portal."),
            ("Export", "Download a detailed PDF for records and CA handoff.")
        ]
        for i,(t,d) in enumerate(expl,1):
            st.markdown(f"<div class='card menu-btn'><b>{i}. {t}</b><div class='muted'>{d}</div></div>", unsafe_allow_html=True)
    with right:
        st.markdown("<div class='card'><h4>📰 Newsletter</h4><div class='muted'>Auto-updates from the official site</div></div>", unsafe_allow_html=True)
        newsletter_slider()

# ---------- ITR Assistant ----------
if menu=="🧾 ITR Assistant":
    st.markdown("<div class='card'><h3>ITR Assistant — guided</h3><div class='muted'>We show final taxes for both Old and New regimes, recommend the best, and provide a step-by-step filing guide.</div></div>", unsafe_allow_html=True)
    try:
        with st.expander("Personal details", expanded=True):
            name = st.text_input("Full name")
            pan = st.text_input("PAN").upper()
            fy = st.selectbox("Financial Year", ["2025-26","2024-25","2023-24"], index=1)
        with st.expander("Income heads", expanded=True):
            salary = st.number_input("Salary (₹)", value=700000.0, step=1000.0)
            business = st.number_input("Business (₹)", value=0.0, step=1000.0)
            capg = st.number_input("Capital gains (₹)", value=20000.0, step=1000.0)
            other = st.number_input("Other income (₹)", value=5000.0, step=500.0)
        with st.expander("Deductions", expanded=True):
            d80c = st.number_input("80C (₹)", value=150000.0, step=1000.0)
            d80d = st.number_input("80D (₹)", value=25000.0, step=1000.0)
            home = st.number_input("Home loan interest (₹)", value=200000.0, step=1000.0)
            d80g = st.number_input("80G donations (₹)", value=0.0, step=500.0)
        incomes = {"salary":salary,"business":business,"capital_gains":capg,"other":other}
        deductions = {"80C":d80c,"80D":d80d,"home_loan_interest":home,"80G":d80g}
        total, out = compute(incomes, deductions, st.session_state.cfg)
        df = pd.DataFrame(out).T.reset_index().rename(columns={"index":"regime"})
        df_disp = df[["regime","name","tax","taxable","ded_used","explanation"]].rename(columns={"name":"Regime Name","tax":"Tax (₹)","taxable":"Taxable (₹)","ded_used":"Deductions Used (₹)","explanation":"Explanation"})
        colA, colB, colC = st.columns(3)
        with colA: st.metric("Total Income", f"₹{total:,.0f}")
        with colB:
            # show old/new if available
            tx_old = out.get("old",{}).get("tax", None)
            tx_new = out.get("new",{}).get("tax", None)
            if tx_old is not None and tx_new is not None:
                st.metric("Final Tax (Old)", f"₹{tx_old:,.0f}")
                st.metric("Final Tax (New)", f"₹{tx_new:,.0f}")
        with colC:
            st.metric("Best tax (min across regimes)", f"₹{df['tax'].min():,.0f}")
        st.dataframe(df_disp.style.format({"Tax (₹)":"{:.0f}","Taxable (₹)":"{:.0f}","Deductions Used (₹)":"{:.0f}"}), height=260)
        st.plotly_chart(px.bar(df_disp, x="Regime Name", y="Tax (₹)", title="Tax comparison"), use_container_width=True)
        best_key = df.loc[df["tax"].idxmin(),"regime"]; best_reg = st.session_state.cfg["regimes"][best_key]
        st.success(f"Best regime: {best_reg.get('name',best_key)} — Estimated tax: ₹{df['tax'].min():,.0f}")
        # tailored step list + pictures
        with st.expander("Step‑by‑step filing (tailored to your best regime)", expanded=True):
            steps = [
                ("Collect documents", "Form 16, AIS/26AS, interest certs, capital statements", 0),
                (f"Choose {best_reg.get('name',best_key)}", "In the e‑filing portal, select 'New/Old Regime' under tax regime choice", 1),
                ("Enter income details", "Fill Salary, Business/Profession, Capital Gains, Other Sources", 2),
                ("Apply deductions", "Enter eligible deductions; the app capped per regime", 3),
                ("Preview tax", "Verify computed tax, cess, and any surcharge", 4),
                ("Submit & e‑verify", "Use Aadhaar OTP, NetBanking, or DSC to e‑verify", 5)
            ]
            cols = st.columns(3)
            for i,(t,d,img_i) in enumerate(steps):
                with cols[i%3]:
                    st.image(get_step_image(img_i), use_column_width=True, caption=t)
                    st.caption(d)
        with st.expander("How to use Copilot (Autopilot) to file"):
            copilot_steps = [
                "Open the Autopilot page and enter the portal URL + username (PAN/Aadhaar).",
                "Click 'Launch browser'. A secure browser starts on the official site.",
                "Complete login and OTP manually (Autopilot will never bypass OTP).",
                "Follow the tailored filing steps shown above; keep cross-checking AIS/26AS.",
                "On submission, e‑verify using Aadhaar OTP / NetBanking / DSC and save the acknowledgement."
            ]
            for i,s in enumerate(copilot_steps,1):
                st.write(f"{i}. {s}")
        # Export PDF
        if st.button("Export Detailed PDF"):
            try:
                bar = px.bar(df_disp, x="Regime Name", y="Tax (₹)"); bar_path="v20_bar.png"; bar.write_image(bar_path)
                buffer = io.BytesIO(); doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=24,leftMargin=24,topMargin=24,bottomMargin=24)
                styles = getSampleStyleSheet()
                styles.add(ParagraphStyle(name="Small", fontSize=9, leading=11))
                story=[]
                story.append(Paragraph("ITR Detailed Summary (v20)", styles["Title"])); story.append(Spacer(1,6))
                story.append(Paragraph(f"Generated: {datetime.datetime.utcnow().isoformat()}", styles["Small"])); story.append(Spacer(1,6))
                story.append(Paragraph(f"Name: {name or '-'} | PAN: {pan or '-'} | FY: {fy}", styles["Normal"])); story.append(Spacer(1,8))
                # Summary table
                comp=[["Regime","Taxable (₹)","Tax (₹)","Deductions Used (₹)"]]
                for _,r in df_disp.iterrows():
                    comp.append([r["Regime Name"], f"{r['Taxable (₹)']:,.0f}", f"{r['Tax (₹)']:,.0f}", f"{r['Deductions Used (₹)']:,.0f}"])
                tc = Table(comp, hAlign="LEFT"); tc.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.5,colors.grey),("ALIGN",(1,1),(-1,-1),"RIGHT")]))
                story.append(Paragraph("Tax Comparison", styles["Heading2"])); story.append(tc); story.append(Spacer(1,6))
                story.append(RLImage(bar_path, width=15*cm, height=9*cm)); story.append(Spacer(1,8))
                # Best regime
                story.append(Paragraph("Recommended Regime", styles["Heading2"]))
                story.append(Paragraph(f"{best_reg.get('name',best_key)} — Estimated tax: ₹{df['tax'].min():,.0f}", styles["Normal"]))
                story.append(Paragraph(best_reg.get("explanation",""), styles["Italic"])); story.append(Spacer(1,6))
                # Slab breakdown table for best regime
                story.append(Paragraph("Slab Breakdown (Best Regime)", styles["Heading2"]))
                parts = out[best_key]["parts"]
                br=[["Slab Range (₹)","Rate %","Amount (₹)","Tax (₹)"]]
                for rng, rate, amt, ttx in parts:
                    br.append([rng, f"{rate:.0f}", f"{amt:,.0f}", f"{ttx:,.0f}"])
                tb = Table(br, hAlign="LEFT"); tb.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.5,colors.grey),("ALIGN",(1,1),(-1,-1),"RIGHT")]))
                story.append(tb); story.append(Spacer(1,6))
                # Step-by-step with images
                story.append(Paragraph("Step-by-step Filing (Tailored)", styles["Heading2"]))
                step_cap = ["Collect documents","Choose Regime","Enter income","Apply deductions","Preview tax","Submit & e‑verify"]
                for i,label in enumerate(step_cap):
                    story.append(Paragraph(f"{i+1}. {label}", styles["Normal"]))
                    img_path = FALLBACKS[i] if os.path.exists(FALLBACKS[i]) else None
                    if img_path: story.append(RLImage(img_path, width=14*cm, height=7*cm))
                story.append(Spacer(1,8))
                # Copilot steps
                story.append(Paragraph("Using Copilot (Autopilot)", styles["Heading2"]))
                for i,s in enumerate(copilot_steps,1):
                    story.append(Paragraph(f"{i}. {s}", styles["Normal"]))
                doc.build(story); buffer.seek(0)
                st.download_button("Download PDF", data=buffer.getvalue(), file_name="ITR_Detailed_v20.pdf", mime="application/pdf")
            except Exception as e:
                st.error(f"PDF failed: {e}"); log(f"pdf err: {e}\n{traceback.format_exc()}")
    except Exception as e:
        st.error("ITR page error"); log(f"itr err: {e}\n{traceback.format_exc()}")

# ---------- Regime Manager ----------
if menu=="🧩 Regime Manager":
    st.markdown("<div class='card'><h3>Regime Manager</h3><div class='muted'>Add official sources to auto-update regimes. Outdated regimes are marked then removed later.</div></div>", unsafe_allow_html=True)
    try:
        c1,c2 = st.columns([2,1])
        with c1:
            st.subheader("Active config (editable)")
            cfg_txt = yaml.safe_dump(st.session_state.cfg, sort_keys=False)
            edited = st.text_area("regimes.yaml", value=cfg_txt, height=420)
            if st.button("Apply edited config"):
                try:
                    newc = yaml.safe_load(edited)
                    if not isinstance(newc, dict) or "regimes" not in newc: st.error("Invalid config")
                    else: st.session_state.cfg = newc; st.success("Applied")
                except Exception as e:
                    st.error(f"Parse error: {e}"); log(f"cfg parse err: {e}")
        with c2:
            st.subheader("Trusted sources")
            srcs = st.text_area("One URL per line", value="\n".join(st.session_state.cfg.get("sources", [])), height=200)
            if st.button("Save sources"):
                st.session_state.cfg["sources"] = [s.strip() for s in srcs.splitlines() if s.strip()]; st.success("Saved sources")
            if st.button("Fetch remote configs now"):
                remote, src = fetch_from_sources(st.session_state.cfg.get("sources", []))
                if remote:
                    st.write("Preview from:", src); st.json(remote)
                    if st.button("Merge & apply"):
                        try:
                            merged = merge_configs(st.session_state.cfg, remote, grace_days=30)
                            st.session_state.cfg = merged; st.success("Merged")
                        except Exception as e:
                            st.error(f"Merge failed: {e}"); log(f"merge err: {e}")
                else:
                    st.info("No valid remote configs found.")
            if st.button("Save to disk"):
                try:
                    with open("regimes.yaml","w",encoding="utf-8") as f: yaml.safe_dump(st.session_state.cfg, f, sort_keys=False)
                    st.success("Saved regimes.yaml")
                except Exception as e:
                    st.error(f"Save failed: {e}"); log(f"save err: {e}")
    except Exception as e:
        st.error("Regime Manager error"); log(f"reg mgr err: {e}\n{traceback.format_exc()}")

# ---------- Autopilot ----------
if menu=="🤖 Autopilot":
    st.markdown("<div class='card'><h3>Copilot / Autopilot</h3><div class='muted'>Opens the e‑filing portal; you handle login & OTP.</div></div>", unsafe_allow_html=True)
    try:
        url = st.text_input("Login URL", value="https://www.incometax.gov.in/")
        user = st.text_input("Username (PAN/Aadhaar)")
        headless = st.checkbox("Headless browser", value=False)
        if st.button("Launch browser"):
            ok,msg = run_autopilot_login(url, user, headless=headless)
            st.success(msg) if ok else st.error(msg)
    except Exception as e:
        st.error("Autopilot error"); log(f"autopilot err: {e}\n{traceback.format_exc()}")

# ---------- Themes Page ----------
if menu=="🎨 Themes":
    st.markdown("<div class='card'><h3>Themes</h3><div class='muted'>Choose a preset or craft your own. Saved themes persist across sessions.</div></div>", unsafe_allow_html=True)
    try:
        preset_names = list(st.session_state.themes.keys())
        chosen = st.selectbox("Preset", preset_names, index=preset_names.index(st.session_state.theme_name) if st.session_state.theme_name in preset_names else 0)
        if st.button("Apply preset"):
            st.session_state.theme_name = chosen
            apply_theme(chosen)
            st.experimental_rerun()
        st.divider()
        st.subheader("Custom theme")
        cur = st.session_state.themes.get(st.session_state.theme_name, list(st.session_state.themes.values())[0])
        bg = st.color_picker("Background", cur["bg"])
        card = st.color_picker("Card", cur["card"])
        text = st.color_picker("Text", cur["text"])
        muted = st.color_picker("Muted", cur["muted"])
        accent = st.color_picker("Accent", cur["accent"])
        custom_name = st.text_input("Save as (theme name)", value="My Theme")
        if st.button("Preview custom"):
            st.session_state.themes["__preview__"]={"bg":bg,"card":card,"text":text,"muted":muted,"accent":accent}
            st.session_state.theme_name="__preview__"
            apply_theme("__preview__"); st.experimental_rerun()
        if st.button("Save custom"):
            st.session_state.themes[custom_name]={"bg":bg,"card":card,"text":text,"muted":muted,"accent":accent}
            save_themes(st.session_state.themes)
            st.success(f"Saved theme '{custom_name}'")
    except Exception as e:
        st.error("Theme error"); log(f"theme err: {e}\n{traceback.format_exc()}")

# ---------- Newsletter Standalone ----------
if menu=="📰 Newsletter":
    st.markdown("<div class='card'><h3>Official News</h3><div class='muted'>Latest updates from the Income Tax website.</div></div>", unsafe_allow_html=True)
    try:
        newsletter_slider()
    except Exception as e:
        st.error("News error"); log(f"news err: {e}\n{traceback.format_exc()}")

# ---------- Settings ----------
if menu=="⚙️ Settings":
    st.markdown("<div class='card'><h3>Settings & Diagnostics</h3></div>", unsafe_allow_html=True)
    try:
        if st.button("Reset session"):
            for k in list(st.session_state.keys()): del st.session_state[k]
            st.success("Session cleared. Reload page.")
        if os.path.exists(LOG):
            if st.button("Clear log"): os.remove(LOG); st.success("Log cleared.")
        st.markdown("#### Log tail")
        if os.path.exists(LOG):
            with open(LOG,"r",encoding="utf-8") as f: st.text("".join(f.readlines()[-200:]))
        else: st.caption("No logs yet.")
        st.markdown("#### Health checks")
        try: import reportlab; st.success("reportlab OK")
        except Exception as e: st.error(f"reportlab missing: {e}")
        try: import plotly; st.success("plotly OK")
        except Exception as e: st.error(f"plotly missing: {e}")
        st.caption("Tip: Use 'Regime Manager' to add trusted YAML/JSON sources for automatic regime updates.")
    except Exception as e:
        st.error("Settings error"); log(f"settings err: {e}\n{traceback.format_exc()}")
