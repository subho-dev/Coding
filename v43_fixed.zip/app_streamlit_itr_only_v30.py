# app_streamlit_itr_only.py - merged 
import os, io, time, traceback, yaml, glob
import streamlit as st, pandas as pd, numpy as np, requests, feedparser
import plotly.express as px
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from fetcher import fetch_from_sources
from schema_downloader import decide_applicable_itr, download_schema_for_ay, bulk_fallback_all_years
from autopilot import launch_headless_chrome, CAHelper

# ===== Inlined Topbar + Chat + Auth UI (all inside app file) =====
import streamlit.components.v1 as components, html

_topbar_html = r"""
<style>
:root{--tb-bg:rgba(8,10,16,0.9);--tb-fg:#e8eefc;--tb-accent:#4f8cff;--tb-border:rgba(255,255,255,0.08)}
.itrtopbar{position:fixed;top:0;left:0;right:0;height:62px;display:flex;align-items:center;justify-content:flex-end;padding:10px 18px;z-index:99999;background:var(--tb-bg);backdrop-filter:blur(6px);border-bottom:1px solid var(--tb-border)}
.itrtopbar .right{display:flex;gap:10px;align-items:center}
.chip{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:12px;background:rgba(255,255,255,0.03);color:var(--tb-fg);cursor:pointer;border:1px solid var(--tb-border);font-weight:600;transition:all .12s ease}
.chip:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(0,0,0,0.35)}
.chip.primary{background:linear-gradient(90deg,var(--tb-accent),#7c5cff);color:white;border:none}
.chip.select select{background:transparent;border:none;color:inherit;outline:none;font-weight:600}
.avatar img{width:36px;height:36px;border-radius:10px;display:block}
/* Chat modal */
.chat-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);backdrop-filter:blur(3px);display:none;z-index:100000;align-items:center;justify-content:center}
.chat-modal{width:680px;max-height:82vh;background:linear-gradient(180deg, rgba(12,14,20,0.96), rgba(9,11,16,0.98));border-radius:14px;border:1px solid var(--tb-border);display:flex;flex-direction:column;overflow:hidden;color:var(--tb-fg)}
.chat-head{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid rgba(255,255,255,0.03)}
.chat-body{padding:12px;overflow:auto;flex:1;background:linear-gradient(180deg, rgba(6,8,12,0.0), rgba(0,0,0,0.03))}
.chat-input{display:flex;gap:8px;padding:12px;border-top:1px solid rgba(255,255,255,0.03)}
.chat-input input{flex:1;padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,0.04);background:rgba(255,255,255,0.02);color:var(--tb-fg)}

.auth-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.45);display:none;align-items:center;justify-content:center;z-index:100000}
.auth-card{width:460px;border-radius:12px;background:linear-gradient(180deg, rgba(10,12,18,0.98), rgba(8,10,15,0.98));border:1px solid var(--tb-border);color:var(--tb-fg);overflow:hidden}
.auth-head{padding:12px 14px;border-bottom:1px solid rgba(255,255,255,0.03);display:flex;justify-content:space-between;align-items:center}
.auth-body{padding:14px}
.auth-body input{width:100%;padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.04);margin:6px 0;background:rgba(255,255,255,0.02);color:var(--tb-fg)}
.auth-body button{width:100%;padding:10px;border-radius:8px;border:none;margin-top:8px;background:var(--tb-accent);color:white;font-weight:700}
.st-emotion-cache-tn0cau {row-gap:0rem !important}
.small-muted{font-size:13px;opacity:0.8;color:rgba(255,255,255,0.8)}

</style>

/* Loading overlay (tic-tac-toe mini-game) */
#loading_overlay{position:fixed;inset:0;background:linear-gradient(180deg, rgba(2,6,23,0.9), rgba(4,8,16,0.95));display:flex;align-items:center;justify-content:center;z-index:100001;color:#fff}
#loading_card{width:360px;padding:20px;border-radius:12px;background:rgba(255,255,255,0.03);box-shadow:0 10px 30px rgba(0,0,0,0.6);text-align:center}
#ttt_board{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:10px 0}
.ttt_cell{width:80px;height:80px;border-radius:8px;background:rgba(255,255,255,0.02);display:flex;align-items:center;justify-content:center;font-size:36px;cursor:pointer;user-select:none}
.ttt_cell.disabled{cursor:not-allowed;opacity:0.6}
#ttt_status{font-size:14px;opacity:0.9;margin-top:8px}
#ttt_controls{display:flex;gap:8px;justify-content:center;margin-top:12px}
#ttt_controls button{padding:8px 12px;border-radius:8px;border:none;background:rgba(255,255,255,0.05);color:white;cursor:pointer}


<div class="itrtopbar" id="itrtopbar">
<!-- Loading overlay with mini tic-tac-toe game (auto-hides when topbar JS finishes) -->
<div id="loading_overlay" aria-hidden="false">
  <div id="loading_card" role="dialog" aria-modal="true" aria-label="Loading">
    <div style="font-weight:700;font-size:18px">Loading — play a quick game while we prepare things</div>
    <div id="ttt_board" role="grid" aria-label="Tic Tac Toe">
      <div class="ttt_cell" data-cell="0" role="button" tabindex="0"></div>
      <div class="ttt_cell" data-cell="1" role="button" tabindex="0"></div>
      <div class="ttt_cell" data-cell="2" role="button" tabindex="0"></div>
      <div class="ttt_cell" data-cell="3" role="button" tabindex="0"></div>
      <div class="ttt_cell" data-cell="4" role="button" tabindex="0"></div>
      <div class="ttt_cell" data-cell="5" role="button" tabindex="0"></div>
      <div class="ttt_cell" data-cell="6" role="button" tabindex="0"></div>
      <div class="ttt_cell" data-cell="7" role="button" tabindex="0"></div>
      <div class="ttt_cell" data-cell="8" role="button" tabindex="0"></div>
    </div>
    <div id="ttt_status">Your turn — X</div>
    <div id="ttt_controls">
      <button id="ttt_reset">Reset</button>
      <button id="ttt_skip">Skip & Continue</button>
    </div>
  </div>
</div>

  <div class="right">
    <div class="chip select" id="theme_chip"><span>🎨</span><select id="theme_select"><option value="auto">Auto</option><option value="neo-dark">Neo Dark</option><option value="ocean">Ocean</option><option value="sunrise">Sunrise</option><option value="plus">＋ Themes</option></select></div>
    <div class="chip select" id="lang_chip"><span>🌐</span><select id="lang_select"><option value="en">English</option><option value="hi">हिन्दी</option></select></div>
    <div class="chip" id="call_chip"><span>📞</span><span class="small-muted">Call</span></div>
    <div class="chip primary" id="chat_chip"><span class="small-muted">Ask the CA</span><span>🤖</span></div>
    <div class="chip" id="login_chip"><span>🔐</span><span class="small-muted">Login</span></div>
    <div class="chip avatar" id="profile_chip" style="display:none"><img id="profile_img" src=""></div>
  </div>
</div>

<div class="chat-overlay" id="chat_overlay">
  <div class="chat-modal" id="chat_modal">
    <div class="chat-head"><div><strong>Ask the CA</strong></div><div><button id="min_btn">_</button>&nbsp;<button id="close_btn">×</button></div></div>
    <div class="chat-body" id="chat_body"></div>
    <div class="chat-input"><input id="chat_input" placeholder="Type your question..."><button id="chat_send">Send</button></div>
  </div>
</div>

<div class="auth-overlay" id="auth_overlay">
  <div class="auth-card">
    <div class="auth-head"><strong>Welcome</strong><div><button id="auth_close">×</button></div></div>
    <div class="auth-body">
      <div id="login_section">
        <input id="login_user" placeholder="Username"><input id="login_pass" placeholder="Password" type="password">
        <button id="login_submit">Login</button>
        <button id="guest_submit" style="background:transparent;border:1px solid rgba(255,255,255,0.06);">Continue as Guest</button>
        <div class="small-muted">No account? <a href="#" id="show_signup">Signup</a></div>
        <div id="login_msg" class="small-muted"></div>
      </div>
      <div id="signup_section" style="display:none">
        <input id="su_user" placeholder="Username"><input id="su_pass" placeholder="Password" type="password">
        <input id="su_email" placeholder="Email"><input id="su_name" placeholder="Full name"><input id="su_phone" placeholder="Phone">
        <button id="signup_submit">Create account</button>
        <div class="small-muted">Already a user? <a href="#" id="show_login">Login</a></div>
        <div id="signup_msg" class="small-muted"></div>
      </div>
    </div>
  </div>
</div>

<script>
(async function(){
  // Helper for toggling overlays
  const chatOverlay = document.getElementById('chat_overlay');
  const chatModal = document.getElementById('chat_modal');
  const chatBody = document.getElementById('chat_body');
  const chatInput = document.getElementById('chat_input');
  const chatSend = document.getElementById('chat_send');
  const chatChip = document.getElementById('chat_chip');
  const authOverlay = document.getElementById('auth_overlay');
  const loginChip = document.getElementById('login_chip');
  const profileChip = document.getElementById('profile_chip');
  const profileImg = document.getElementById('profile_img');
  const themeSelect = document.getElementById('theme_select');
  const langSelect = document.getElementById('lang_select');
  const callChip = document.getElementById('call_chip');

  function openChat(){ chatOverlay.style.display='flex'; chatBody.innerHTML=''; resetTimers(); }

  async function saveProfileToServer(user, profile){ await fetch('/profile/'+encodeURIComponent(user), {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(profile)}); }
  async function loadProfileFromServer(user){ try{ const r=await fetch('/profile/'+encodeURIComponent(user)); const j=await r.json(); return j.ok?j:{} }catch(e){return {}} }

  function closeChat(){ chatOverlay.style.display='none'; clearTimers(); }
  function minimizeChat(){ chatOverlay.style.display='none'; /* show small dock if required */ }

  chatChip.onclick = openChat;
  document.getElementById('close_btn').onclick = closeChat;
  document.getElementById('min_btn').onclick = minimizeChat;

  // Chat send
  async function sendMsg(){
    const m = chatInput.value.trim(); if(!m) return;
    addMsg(m,'user'); chatInput.value='';
    const stop = showTyping();
    try{
      const resp = await fetch('/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({session_id: (await (await fetch('/_session')).json()).username || 'default', message: m})});
      const j = await resp.json();
      stop(); addMsg(j.reply || 'No reply','bot');
    }catch(e){ stop(); addMsg('Error contacting backend.','bot'); }
  }
  chatSend.onclick = sendMsg;
  chatInput.addEventListener('keydown',(e)=>{ if(e.key==='Enter') sendMsg(); });

  function addMsg(t, who){
    const d = document.createElement('div'); d.style.padding='8px 10px'; d.style.margin='8px'; d.style.borderRadius='10px'; d.style.maxWidth='80%';
    if(who==='user'){ d.style.background='rgba(255,255,255,0.04)'; d.style.marginLeft='auto'; d.style.textAlign='right'; }
    else { d.style.background='rgba(255,255,255,0.02)'; d.style.marginRight='auto'; }
    d.textContent = t; chatBody.appendChild(d); chatBody.scrollTop = chatBody.scrollHeight;
  }
  function showTyping(){
    const d = document.createElement('div'); d.textContent='Thinking...'; d.style.opacity='0.8'; d.style.margin='8px'; chatBody.appendChild(d); chatBody.scrollTop = chatBody.scrollHeight;
    const iv = setInterval(()=>{ d.textContent = d.textContent+'.'; if(d.textContent.length>20) d.textContent='Thinking...'; }, 700);
    return ()=>{ clearInterval(iv); d.remove(); };
  }

  // Theme select: write query param and reload (keeps Streamlit simple)
  themeSelect.onchange = async function(e){
    const val = e.target.value;
    if(val==='plus'){ const qs = new URLSearchParams(window.location.search); qs.set('page','Themes'); window.location.search = qs.toString(); return; }
    try{ const r = await fetch('/theme/list'); const j = await r.json(); if(j.ok){ const found = j.themes.find(t=>t.name===val); if(found){ applyTheme(found.config); } } }catch(e){ console.error(e);}
  };
  // Lang select sets query param
  langSelect.onchange = function(e){ const qs = new URLSearchParams(window.location.search); qs.set('lang', e.target.value); window.location.search = qs.toString(); };

  // Call
  callChip.onclick = function(){ const num = window.stCallNumber || ''; if(num) window.location.href = 'tel:'+num; };

  // Auth handlers (calls backend endpoints)
  loginChip.onclick = function(){ authOverlay.style.display='flex'; };
  document.getElementById('auth_close').onclick = function(){ authOverlay.style.display='none'; };

  document.getElementById('show_signup').onclick = function(e){ e.preventDefault(); document.getElementById('login_section').style.display='none'; document.getElementById('signup_section').style.display='block'; };
  document.getElementById('show_login').onclick = function(e){ e.preventDefault(); document.getElementById('login_section').style.display='block'; document.getElementById('signup_section').style.display='none'; };

  document.getElementById('guest_submit').onclick = async function(){
    try{ const r=await fetch('/guest_login',{method:'POST'}); const j=await r.json(); if(j.ok){ await fetch('/_session', {method:'POST',headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'set_user', username: j.username})}); authOverlay.style.display='none'; showProfile(j.username); await fetch('/profile_upsert/'+encodeURIComponent(j.username), {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email:j.email, full_name:j.full_name, phone:j.phone, data:j.data||{}})}); } }catch(e){}
  };

  document.getElementById('login_submit').onclick = async function(){
    const payload = {username: document.getElementById('login_user').value, password: document.getElementById('login_pass').value};
    try{ const r=await fetch('/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); const j=await r.json(); if(j.ok){ await fetch('/_session', {method:'POST',headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'set_user', username: j.username})}); authOverlay.style.display='none'; showProfile(j.username); await fetch('/profile_upsert/'+encodeURIComponent(j.username), {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email:j.email, full_name:j.full_name, phone:j.phone, data:j.data||{}})}); } else { document.getElementById('login_msg').textContent = j.error || 'Login failed'; } }catch(e){ document.getElementById('login_msg').textContent='Login error'; }
  };

  document.getElementById('signup_submit').onclick = async function(){
    const payload = {username: document.getElementById('su_user').value, password: document.getElementById('su_pass').value, email: document.getElementById('su_email').value, full_name: document.getElementById('su_name').value, phone: document.getElementById('su_phone').value};
    try{ const r=await fetch('/signup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); const j=await r.json(); if(j.ok){ await fetch('/_session', {method:'POST',headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'set_user', username: j.username})}); authOverlay.style.display='none'; showProfile(j.username); await fetch('/profile_upsert/'+encodeURIComponent(j.username), {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email:j.email, full_name:j.full_name, phone:j.phone, data:j.data||{}})}); } else { document.getElementById('signup_msg').textContent = j.error || 'Signup failed'; } }catch(e){ document.getElementById('signup_msg').textContent='Signup error'; }
  };

  async function showProfile(user){
    const prof = await loadProfileFromServer(user);
    try{ if(prof && prof.full_name){ /* set profile in UI */ } }catch(e){}
    // Load ITR saved data
    try{ const r = await fetch('/itr/load/'+encodeURIComponent(user)); const j=await r.json(); if(j.ok && j.data){ window._loaded_itr = j.data; /* front-end can use this to pre-fill fields via Streamlit if needed */ } }catch(e){}

    try{
      const r = await fetch('/profile/'+encodeURIComponent(user)); const j = await r.json();
      if(j.ok){ profileChip.style.display='flex'; profileImg.src = 'data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="36" height="36" rx="8" fill="#1f6feb"/><text x="50%" y="55%" font-size="16" text-anchor="middle" fill="#fff">'+(j.full_name?j.full_name.charAt(0).toUpperCase():'U')+'</text></svg>'); loginChip.style.display='none'; /* profile cached in server session/database */ }
    }catch(e){ console.error(e); }
  }

  // On load, if user exists in localStorage show profile
  (function(){ const resp = await fetch('/_session'); const ss = await resp.json(); if(ss.username) showProfile(ss.username); hideLoadingOverlaySoon(700);})();

  // Simple idle timers: minimize after 30s, close after 5min
  let idleTimer=null, longTimer=null;
  function resetTimers(){ clearTimers(); idleTimer = setTimeout(minimizeChat, 30*1000); longTimer = setTimeout(closeChat, 5*60*1000); }
  function clearTimers(){ if(idleTimer) clearTimeout(idleTimer); if(longTimer) clearTimeout(longTimer); }
  document.addEventListener('mousemove', resetTimers, {passive:true}); document.addEventListener('keydown', resetTimers, {passive:true});


// --- Tic-tac-toe mini-game logic and overlay hide helpers ---
function initTicTacToe(){
  try{
    const board = document.getElementById('ttt_board');
    const cells = Array.from(board.querySelectorAll('.ttt_cell'));
    const status = document.getElementById('ttt_status');
    let state = Array(9).fill(null);
    let turn = 'X';
    let finished = false;

    const winLines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];

    function checkWin(){
      for(const [a,b,c] of winLines){
        if(state[a] && state[a]===state[b] && state[a]===state[c]) return state[a];
      }
      return state.includes(null)?null:'draw';
    }

    function render(){
      cells.forEach((cell,i)=>{
        cell.textContent = state[i] || '';
        cell.classList.toggle('disabled', !!state[i] || finished);
      });
      const w = checkWin();
      if(w === 'draw'){ status.textContent = "It's a draw."; finished=true; }
      else if(w){ status.textContent = w + " wins!"; finished=true; }
      else { status.textContent = (turn==='X'?'Your turn — X':'Computer thinking — O'); }
    }

    async function computerMove(){
      // simple random AI
      if(finished) return;
      status.textContent = 'Computer thinking — O';
      await new Promise(r=>setTimeout(r,450));
      const empties = state.map((v,i)=>v?null:i).filter(v=>v!==null);
      if(empties.length===0) { render(); return; }
      const idx = empties[Math.floor(Math.random()*empties.length)];
      state[idx] = 'O';
      turn='X'; render();
    }

    cells.forEach((cell,i)=>{
      cell.addEventListener('click', async ()=>{
        if(finished || state[i]) return;
        state[i] = 'X';
        turn='O';
        render();
        const w = checkWin();
        if(!w) await computerMove();
        render();
      });
      cell.addEventListener('keydown', async (e)=>{
        if(e.key==='Enter' || e.key===' ') cell.click();
      });
    });

    document.getElementById('ttt_reset').addEventListener('click', ()=>{
      state = Array(9).fill(null); turn='X'; finished=false; render();
    });

    document.getElementById('ttt_skip').addEventListener('click', ()=>{
      // hide overlay and continue
      const ov = document.getElementById('loading_overlay');
      if(ov) ov.style.display='none';
    });

    render();
  }catch(e){
    console.error("TTT init error", e);
  }
}

// Hide overlay when topbar initializations are done
function hideLoadingOverlaySoon(delayMs){
  setTimeout(()=>{ try{ const ov = document.getElementById('loading_overlay'); if(ov) ov.style.display='none'; }catch(e){} }, delayMs||800);
}

// Ensure overlay is dismissed eventually even on partial failures
window.addEventListener('error', ()=>hideLoadingOverlaySoon(2000));
window.addEventListener('load', ()=>hideLoadingOverlaySoon(1200));
initTicTacToe();

// If the script is an async IIFE, attempt to hide overlay at the end of it by calling this function explicitly.
// The IIFE (async function(){ ... })(); will call hideLoadingOverlaySoon() near its end.
})();
</script>
"""

# Use components.html to inject - height 0 so it runs and injects into page DOM
components.html(_topbar_html, height=0)
# ===== End Inlined Topbar =====
import re

# ---- Server-side DB helper for app ----
import sqlite3, json as _json, atexit
APP_DB = os.environ.get("APP_DB", "data/app.db")
def app_db_conn():
    os.makedirs(os.path.dirname(APP_DB), exist_ok=True)
    conn = sqlite3.connect(APP_DB, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def get_profile_for_user(username):
    if not username: return {}
    c = app_db_conn(); cur = c.cursor()
    cur.execute("SELECT username,email,full_name,phone,data FROM profiles WHERE username=?", (username,))
    r = cur.fetchone(); c.close()
    if not r: return {}
    try: data = _json.loads(r["data"] or "{}")
    except: data={}
    return {"username": r["username"], "email": r["email"], "full_name": r["full_name"], "phone": r["phone"], "data": data}

# On app start, ensure DB exists and defaults are in place (calls FastAPI defaults endpoint optional)
try:
    conn_tmp = app_db_conn(); conn_tmp.close()
except Exception as e:
    st.error("Failed to create app DB: "+str(e))

st.markdown("""<style>
.main, .block-container, [data-testid="stSidebar"], [data-testid="stBottomBlockContainer"] { 
  scroll-behavior:smooth; transition: all .18s ease-in-out;
}
</style>""", unsafe_allow_html=True)


# ===== Injected Topbar + Backend Mount =====

# ---- Theme & Language from query params ----
qp = st.query_params
if 'theme' in qp:
    st.session_state['theme'] = qp.get('theme')
if 'lang' in qp:
    st.session_state['lang'] = qp.get('lang')
# Inject CSS variables for theme if present
def theme_css(theme):
    if theme == 'neo-dark':
        return ":root{--tb-bg:rgba(9,11,18,.82);--tb-fg:#f0f3ff;--tb-accent:#7aa2ff;--tb-border:rgba(255,255,255,.16);}"
    if theme == 'ocean':
        return ":root{--tb-bg:rgba(4,18,28,.80);--tb-fg:#e8f4ff;--tb-accent:#27c4ff;--tb-border:rgba(255,255,255,.14);}"
    if theme == 'sunrise':
        return ":root{--tb-bg:rgba(34,19,16,.80);--tb-fg:#fff6f0;--tb-accent:#ff8a4b;--tb-border:rgba(255,255,255,.18);}"
    return ""
st.markdown(f"<style>{theme_css(st.session_state.get('theme',''))}</style>", unsafe_allow_html=True)


# ----- User profile integration -----
import sqlite3, json
USERS_DB = os.environ.get("USERS_DB", "data/users.sqlite3")
def load_profile_for(user):
    if not user: return {}
    try:
        con = sqlite3.connect(USERS_DB); cur=con.cursor()
        cur.execute("SELECT username,email,full_name,phone,data FROM users WHERE username=?", (user,))
        r=cur.fetchone(); con.close()
        if not r: return {}
        u,email,full_name,phone,data = r
        try: parsed = json.loads(data or "{}")
        except: parsed = {}
        return {"username":u,"email":email,"full_name":full_name,"phone":phone,"data":parsed}
    except Exception as e:
        return {}
# Check for query param override to prefill fields
_user_q = st.query_params.get("_user", [None])[0]
if _user_q:
    prof = load_profile_for(_user_q)
    if prof:
        # expose profile to client-side for JS and prefill default forms via session_state
        st.session_state['profile'] = prof
        st.markdown(f"<script>window.itr_profile = {json.dumps(prof)};</script>", unsafe_allow_html=True)

import threading, uvicorn, types
from fastapi import FastAPI
from server.fastapi_server import app as _fastapi_app
from server.voice_bg import background_bootstrap

# bootstrap voice downloads (background)
background_bootstrap()

# Mount FastAPI on the same server via st.experimental_singleton-like approach
if "uvicorn_thread" not in st.session_state:
    def run_server():
        uvicorn.run(_fastapi_app, host="0.0.0.0", port=8000, log_level="warning")
    t = threading.Thread(target=run_server, daemon=True)
    t.start()
    st.session_state["uvicorn_thread"]=True

# Serve topbar assets
# st.markdown(f"<style>{open('', encoding='utf-8').read()}</style>", unsafe_allow_html=True)
# st.components.v1.html(open("", encoding='utf-8').read(), height=0)

# Language/theme handlers (simple session flags)
lang = st.query_params.get("_lang_sel", [st.session_state.get("lang","en")])[0]
st.session_state["lang"]=lang
theme_sel = st.query_params.get("_theme_sel", [st.session_state.get("theme","auto")])[0]
st.session_state["theme"]=theme_sel

# Expose phone number for call button
st.session_state.setdefault("call_number","+919999999999")  # change in Settings page
st.markdown(f"<script>window.stCallNumber='{st.session_state['call_number']}';</script>", unsafe_allow_html=True)

# smooth page transitions via CSS
st.markdown("""
<style>
.reportview-container .main .block-container{transition:opacity .25s ease-in-out; }
</style>
""", unsafe_allow_html=True)
# ===== End Injected =====


def use_regex(input_text):
    pattern = re.compile(r"[1-9]"+"\. "+".*", re.IGNORECASE)
    output = pattern.findall(input_text)
    final_output = []
    for value in output:
        value = value.replace("</p>","")
        final_output.append(value)
    return final_output

st.set_page_config(page_title="ITR Assistant", layout="wide", initial_sidebar_state="expanded")
LOG="itr_log.txt"

def log(msg):
    try:
        with open(LOG,"a",encoding="utf-8") as f: f.write(f"{time.time()} - {msg}\n")
    except: pass

# Theme system
THEME_FILE="themes.yaml"
DEFAULT_THEMES={"Neo Dark":{"bg":"#0b0f1a","card":"#111827","text":"#E5F0FF","muted":"#9FB8D6","accent":"#7AFCFF"},
                "Ink Black":{"bg":"#00040A","card":"#0B1220","text":"#F1F5F9","muted":"#98A2B3","accent":"#00E5A8"},
                "Light Contrast":{"bg":"#F6FAFF","card":"#FFFFFF","text":"#0B1220","muted":"#5B6777","accent":"#006D77"}}
def load_themes():
    if os.path.exists(THEME_FILE):
        try:
            with open(THEME_FILE,"r",encoding="utf-8") as f: return yaml.safe_load(f)
        except: return DEFAULT_THEMES.copy()
    return DEFAULT_THEMES.copy()
def save_themes(th): 
    try:
        with open(THEME_FILE,"w",encoding="utf-8") as f: yaml.safe_dump(th,f,sort_keys=False)
    except Exception as e: log(f"save themes err {e}")

if "themes" not in st.session_state: st.session_state.themes = load_themes()
if "theme_name" not in st.session_state: st.session_state.theme_name = list(st.session_state.themes.keys())[0]
def apply_theme(name):
    th = st.session_state.themes.get(name, list(st.session_state.themes.values())[0])
    css = f"""
    <style>
    :root{{--bg:{th['bg']};--card:{th['card']};--text:{th['text']};--muted:{th['muted']};--accent:{th['accent']};}}
    .appview-container{{background:var(--bg);}}
    .card{{background:var(--card);border-radius:12px;padding:14px;color:var(--text);margin-bottom:12px}}
    .hero{{background:linear-gradient(90deg,#03396c,#006d77);padding:20px;border-radius:12px;color:var(--text);margin-bottom:12px}}
    .muted{{color:var(--muted)}}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)
apply_theme(st.session_state.theme_name)

menu = st.sidebar.radio("Navigate", ["🏠 Overview","🧾 ITR Assistant","🧩 Regime Manager","🤖 Autopilot","🎨 Themes","⚙️ Settings"], index=0)
# "📰 Newsletter"
# defaults
DEFAULT_CFG = {"regimes":{"old":{"name":"Old Regime","cess_percent":4,"slabs":[{"upto":250000,"rate":0},{"upto":500000,"rate":5},{"upto":1000000,"rate":20},{"upto":None,"rate":30}],"deduction_limits":{"80C":150000},"explanation":"Old Regime"},"new":{"name":"New Regime","cess_percent":4,"slabs":[{"upto":300000,"rate":0},{"upto":600000,"rate":5},{"upto":900000,"rate":10},{"upto":1200000,"rate":15},{"upto":1500000,"rate":20},{"upto":2000000,"rate":25},{"upto":None,"rate":30}],"deduction_limits":{"80C":0},"explanation":"New Regime"}},"sources":[]}

if "cfg" not in st.session_state:
    if os.path.exists("regimes.yaml"):
        try:
            with open("regimes.yaml","r",encoding="utf-8") as f: st.session_state.cfg = yaml.safe_load(f)
        except Exception:
            st.session_state.cfg = DEFAULT_CFG.copy()
    else:
        st.session_state.cfg = DEFAULT_CFG.copy()

# tax calc utilities
def calc_tax_contrib(taxable, slabs):
    parts=[]; tax=0.0; rem=taxable; lower=0.0
    for s in slabs:
        upto=s.get("upto"); rate=float(s.get("rate",0))/100.0
        if upto is None:
            amt=max(0.0,rem); t=amt*rate; tax+=t; parts.append((f"{lower:+,.0f}+", rate*100, amt, t)); break
        slab_amt = max(0.0, min(rem, float(upto)-lower)); t=slab_amt*rate; tax+=t; parts.append((f"{lower:,.0f}-{float(upto):,.0f}", rate*100, slab_amt, t))
        rem-=slab_amt; lower=float(upto)
        if rem<=0: break
    return parts, tax
def calc_tax(taxable, slabs, cess):
    parts, pre = calc_tax_contrib(taxable, slabs)
    tax = pre + pre*(float(cess)/100.0)
    return max(0.0,tax), parts
def compute(incomes,deductions,cfg):
    total=sum(float(v) for v in incomes.values())
    out={}
    for key,reg in cfg.get("regimes",{}).items():
        dl=reg.get("deduction_limits",{}) or {}
        used=0.0
        for dkey,amt in deductions.items():
            lim=dl.get(dkey,None); a=float(amt)
            used += a if lim is None else min(a, float(lim))
        taxable=max(0.0, total-used)
        tax, parts = calc_tax(taxable, reg.get("slabs",[]), reg.get("cess_percent",4))
        out[key]={"name":reg.get("name",key),"tax":tax,"taxable":taxable,"ded_used":used,"explanation":reg.get("explanation",""),"parts":parts}
    return total, out
def chat_bot_call():
    # Floating Action Button (FAB) on all pages

    # ===== Start local FastAPI backend in a background thread =====
    def _ensure_backend():
        if st.session_state.get("_backend_started"):
            return
        import threading, uvicorn, sys, importlib, time
        sys.path.append(os.path.dirname(__file__))
        # import the app
        from server.app import app as _fastapi_app
        def _run():
            uvicorn.run(_fastapi_app, host="127.0.0.1", port=7860, log_level="warning")

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        # small wait for port to open
        time.sleep(0.5)
        st.session_state["_backend_started"] = True

    _ensure_backend()

    # ================== Chatbot Settings Page (v30.1) ==================
    def chatbot_settings_page():
        st.title("🤖 Chatbot Settings")

        st.subheader("General")
        demo_mode = st.checkbox("Enable Demo Mode", value=False, key="demo_mode_checkbox")
        if demo_mode:
            st.info("Demo Mode Active – You are seeing sample CA Q&A responses.")

        st.subheader("Voice Settings")
        voice_enabled = st.checkbox("Enable Voice Features", value=False, key="voice_checkbox")
        if voice_enabled:
            mode = st.radio("Choose Mode", ["Auto (Online+Offline fallback)", "Online Only", "Offline Only"], index=0)

        st.subheader("Themes")
        theme = st.radio("Chatbot Theme", ["Auto", "Dark", "Light"], index=0)

        st.subheader("Hotkeys")
        st.markdown("**Ctrl+Shift+C** → Open Chatbot instantly")
        st.markdown("**Ctrl+D** → Toggle Demo Mode")

        st.success("Settings saved automatically and persist across sessions.")

    # Add navigation tab for settings (if multipage app structure exists)
    if "page" in st.session_state and st.session_state.page == "Chatbot Settings":
        chatbot_settings_page()

# ----- Theme Editor Page -----
if st.query_params.get("page", [None])[0] == "Themes":
    st.title("Theme Editor")
    st.markdown("Create or edit themes. Saved themes are stored in the app DB.")
    col1, col2 = st.columns(2)
    with col1:
        name = st.text_input("Theme name", value="custom-theme")
        bg = st.color_picker("Background color", "#0b0f1a")
        fg = st.color_picker("Foreground color", "#e8eefc")
        accent = st.color_picker("Accent color", "#4f8cff")
        if st.button("Save theme"):
            payload = {"name": name, "config": {"bg": bg, "fg": fg, "accent": accent}}
            try:
                r = requests.post("http://127.0.0.1:8000/theme/save", json=payload, timeout=5)
                st.success("Saved theme")
            except Exception as e:
                st.error("Failed to save theme: "+str(e))
    with col2:
        st.markdown("Existing themes")
        try:
            r = requests.get("http://127.0.0.1:8000/theme/list", timeout=5); j=r.json()
            if j.get("themes"):
                for t in j["themes"]:
                    st.write(t["name"], t["config"])
        except Exception as e:
            st.info("No themes found or failed to fetch: "+str(e))
    st.stop()
# automatically ensure schemas at startup in background
def ensure_schemas_background(years=None):
    import threading
    years = years or ["2025-26","2024-25","2023-24"]
    def job():
        try:
            from schema_downloader import bulk_fallback_all_years
            bulk_fallback_all_years(years, dest_root=".")
        except Exception as e:
            log(f"background schema fetch error: {e}")
    if "schema_thread" not in st.session_state:
        t = threading.Thread(target=job, daemon=True); t.start(); st.session_state.schema_thread=True

ensure_schemas_background()

# Pages
if menu=="🏠 Overview":
    st.markdown('<div class="hero"><h2>ITR Assistant </h2><p class="muted">Schema-aware • Autopilot • Themeable • Beginner-friendly</p></div>', unsafe_allow_html=True)
    left,right = st.columns([2,1], gap="large")
    with left:
        steps = [("Collect Documents","Gather Form16, AIS/26AS, bank interest, capital statements."),
                 ("Enter Income","Enter salary, business, capital gains, other income."),
                 ("Deductions","Enter deductions you will claim; app caps per regime."),
                 ("Compare & Choose","We compute taxes under available regimes and recommend the best."),
                 ("File","Use Copilot to open portal and follow steps; OTP remains manual."),
                 ("Export","Save detailed PDF with schema references.")]
        for i,(t,d) in enumerate(steps,1):
            st.markdown(f'<div class="card"><b>{i}. {t}</b><div class="muted">{d}</div></div>', unsafe_allow_html=True)
    with right:
        try:
            rss = "https://www.incometax.gov.in/iec/foportal/"
            feed = feedparser.parse(rss)
            parent_str = feed.feed.get("summary")
            op = use_regex(parent_str)
            items = [{"title": e[2::], "link": ""} for e in op]
            if not items:
                st.caption("No news available right now.")
            else:
                idx = int(time.time()//3) % len(items)
                it = items[idx];
                st.markdown(f'<div class="card"><h4>📰 Newsletter</h4><div class="muted"><a href="https://www.incometax.gov.in/iec/foportal/">{it["title"]}</a></div></div>',
                            unsafe_allow_html=True)
                # st.markdown(f"{it['title']}")
                if st.button("🔄 Refresh News"):
                    pass
        except Exception as e:
            st.error("News error"); log(str(e))

        chat_bot_call()


if menu=="🧾 ITR Assistant":
    st.markdown('<div class="card"><h3>ITR Assistant — schema-aware</h3><div class="muted">Select AY, enter income & deductions; we auto-suggest ITR and can fetch official schema.</div></div>', unsafe_allow_html=True)
    try:
        col1,col2 = st.columns([2,1])
        with col1:
            name = st.text_input("Full name")
            pan = st.text_input("PAN").upper()
            fy = st.selectbox("Assessment Year (AY)", ["2025-26","2024-25","2023-24"], index=1)
            salary = st.number_input("Salary (₹)", value=700000.0)
            business = st.number_input("Business (₹)", value=0.0)
            capg = st.number_input("Capital gains (₹)", value=0.0)
            other = st.number_input("Other income (₹)", value=5000.0)
            d80c = st.number_input("80C (₹)", value=150000.0)
            d80d = st.number_input("80D (₹)", value=25000.0)
            home = st.number_input("Home loan interest (₹)", value=200000.0)
            d80g = st.number_input("80G (₹)", value=0.0)
        with col2:
            resident = st.checkbox("Resident?", value=True)
            presumptive = st.checkbox("Presumptive income (44AD/44ADA/44AE)?", value=False)
            multi_house = st.checkbox("Multiple house property?", value=False)
            st.markdown("### Schema tools")
            if st.button("Fetch schema for selected AY/ITR (headless)"):
                itr_id = decide_applicable_itr({"salary":salary,"business":business,"capital_gains":capg,"other":other,"presumptive":presumptive,"multiple_house_property":multi_house})
                try:
                    folder,msg = download_schema_for_ay(fy, itr_id, dest_root=".")
                    st.success(f"{msg} -> {folder}")
                except Exception as e:
                    st.error(f"Schema fetch failed: {e}")
            if st.button("Bulk prefetch schemas (all AYs)"):
                try:
                    years=["2025-26","2024-25","2023-24"]
                    msgs = bulk_fallback_all_years(years, dest_root=".")
                    st.success("Bulk attempt done. See logs for details.")
                except Exception as e:
                    st.error(f"Bulk fetch failed: {e}")
        incomes = {"salary":salary,"business":business,"capital_gains":capg,"other":other}
        deductions = {"80C":d80c,"80D":d80d,"home_loan_interest":home,"80G":d80g}
        total, out = compute(incomes,deductions,st.session_state.cfg)
        df = pd.DataFrame(out).T.reset_index().rename(columns={"index":"regime"})
        st.metric("Total Income", f"₹{total:,.0f}"); st.dataframe(df[["name","tax","taxable","ded_used"]].rename(columns={"name":"Regime","tax":"Tax (₹)","taxable":"Taxable (₹)","ded_used":"Deductions Used (₹)"}).style.format({"Tax (₹)":"{:.0f}"}), height=240)
        st.plotly_chart(px.bar(pd.DataFrame(out).T.reset_index().rename(columns={"index":"regime"}) , x="regime", y="tax"), use_container_width=True)
        itr_id = decide_applicable_itr({"salary":salary,"business":business,"capital_gains":capg,"other":other,"presumptive":presumptive,"multiple_house_property":multi_house})
        st.info(f"Suggested ITR: {itr_id.upper()}")
        with st.expander("Step-by-step filing (with screenshots if available)", expanded=True):
            steps = ["Login to e-filing portal","Select AY and regime","Enter incomes","Apply deductions","Preview & submit","E-verify"]
            cols = st.columns(3)
            for i,s in enumerate(steps):
                idx = i%3
                img = f"assets/images/step{i+1}.png"
                if os.path.exists(img):
                    cols[idx].image(img, use_container_width=True, caption=s)
                else:
                    cols[idx].write(s)
        with st.expander("How to use Copilot (interactive)", expanded=False):
            st.write("Copilot launches headless browser and a helper chat. You must complete login & OTP manually for security.")
            if st.button("Launch Copilot (headless)"):
                try:
                    schema_dir = os.path.join(".", f"regimes_schema_{fy}")
                    driver = launch_headless_chrome("https://www.incometax.gov.in/iec/foportal/downloads/income-tax-returns", download_dir=schema_dir, headless=True)
                    st.session_state.driver = True; st.success("Headless browser launched. Complete login & OTP in the opened session.")
                    # start CA helper
                    if "ca_helper" not in st.session_state or st.session_state.get("ca_helper_dir")!=schema_dir:
                        helper = CAHelper(schema_dir); helper.start(); st.session_state.ca_helper = helper; st.session_state.ca_helper_dir = schema_dir
                except Exception as e:
                    st.error(f"Copilot launch failed: {e}")
            if st.button(""):
                q = st.text_input("Question for CA")
                if q:
                    helper = st.session_state.get("ca_helper", None)
                    if helper:
                        helper.ask(q); time.sleep(0.2); ans = helper.get_answer(timeout=2)
                        if ans: st.info(ans)
                    else:
                        st.warning("Start Copilot first to enable the CA helper.")
        if st.button("Export PDF (detailed)"):
            try:
                buffer = io.BytesIO(); doc = SimpleDocTemplate(buffer, pagesize=A4)
                styles = getSampleStyleSheet(); story=[]
                story.append(Paragraph("ITR Summary", styles["Title"])); story.append(Spacer(1,6))
                story.append(Paragraph(f"Name: {name} | PAN: {pan} | AY: {fy}", styles["Normal"])); story.append(Spacer(1,6))
                comp=[["Regime","Taxable","Tax","Deductions Used"]]
                for k,v in out.items():
                    comp.append([v["name"], f"{v['taxable']:,.0f}", f"{v['tax']:,.0f}", f"{v['ded_used']:,.0f}"])
                tc = Table(comp); tc.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.5,"#444444")])); story.append(tc)
                doc.build(story); buffer.seek(0); st.download_button("Download PDF", data=buffer.getvalue(), file_name="ITR_Summary.pdf", mime="application/pdf")
            except Exception as e:
                st.error(f"PDF failed: {e}"); log(str(e))
    except Exception as e:
        st.error("ITR Assistant error"); log(str(e))

if menu=="🧩 Regime Manager":
    st.markdown('<div class="card"><h3>Regime Manager</h3><div class="muted">Edit regimes in table and save to yaml/json sources.</div></div>', unsafe_allow_html=True)
    try:
        regs = st.session_state.cfg.get("regimes",{})
        rows = []
        for key,reg in regs.items():
            rows.append({"key":key,"name":reg.get("name",""),"cess":reg.get("cess_percent",4),"slabs":yaml.safe_dump(reg.get("slabs",[])),"deduction_limits":yaml.safe_dump(reg.get("deduction_limits",{})),"explanation":reg.get("explanation","")})
        df = pd.DataFrame(rows)
        edited = st.data_editor(df, use_container_width=True, num_rows="dynamic")
        if st.button("Save config from table"):
            newr={}
            for _,r in edited.iterrows():
                try:
                    slabs = yaml.safe_load(r["slabs"] or "[]"); dlims = yaml.safe_load(r["deduction_limits"] or "{}")
                    newr[r["key"]] = {"name":r["name"], "cess_percent":float(r["cess"]), "slabs":slabs, "deduction_limits":dlims, "explanation": r["explanation"]}
                except Exception as e:
                    st.error(f"Parse error: {e}"); raise
            st.session_state.cfg["regimes"] = newr; st.success("Saved to session. Use Save to disk to persist.")
        if st.button("Save to disk (regimes.yaml)"):
            with open("regimes.yaml","w",encoding="utf-8") as f: yaml.safe_dump(st.session_state.cfg, f, sort_keys=False)
            st.success("Saved regimes.yaml")
    except Exception as e:
        st.error("Regime Manager error"); log(str(e))

if menu=="🤖 Autopilot":
    st.markdown('<div class="card"><h3>Autopilot</h3><div class="muted">Start headless Chrome and keep helper alive for guided filing.</div></div>', unsafe_allow_html=True)
    try:
        ay = st.selectbox("Schema AY", ["2025-26","2024-25","2023-24"], index=1)
        itr = st.selectbox("ITR form", ["itr-1","itr-2","itr-3","itr-4"], index=0)
        schema_dir = os.path.join(".", f"regimes_schema_{ay}")
        if st.button("Start Autopilot & helper"):
            try:
                driver = launch_headless_chrome("https://www.incometax.gov.in/iec/foportal/downloads/income-tax-returns", download_dir=schema_dir, headless=True)
                st.session_state.driver_alive = True
                st.success("Headless Chrome started. The helper has access to schemas in " + schema_dir)
                if "ca_helper" not in st.session_state or st.session_state.ca_helper_dir != schema_dir:
                    helper = CAHelper(schema_dir); helper.start(); st.session_state.ca_helper = helper; st.session_state.ca_helper_dir = schema_dir
            except Exception as e:
                st.error(f"Autopilot start failed: {e}"); log(str(e))
        if st.button("Stop Autopilot & helper"):
            try:
                if "ca_helper" in st.session_state: st.session_state.ca_helper.stop()
                st.session_state.driver_alive = False; st.success("Stopped helper")
            except Exception as e:
                st.error(f"Stop failed: {e}"); log(str(e))
        if st.button(" (example)"):
            q = st.text_input("Question to CA (schema-aware)")
            if q and "ca_helper" in st.session_state:
                st.session_state.ca_helper.ask(q); time.sleep(0.2); ans = st.session_state.ca_helper.get_answer(timeout=2)
                if ans:
                    st.info(ans)
                else:
                    st.warning("No answer yet.")
    except Exception as e:
        st.error("Autopilot error"); log(str(e))

if menu=="🎨 Themes":
    st.markdown('<div class="card"><h3>Themes</h3><div class="muted">Presets + Custom colors (saved to themes.yaml)</div></div>', unsafe_allow_html=True)
    try:
        names = list(st.session_state.themes.keys())
        sel = st.selectbox("Preset", names, index=names.index(st.session_state.theme_name) if st.session_state.theme_name in names else 0)
        if st.button("Apply preset"):
            st.session_state.theme_name = sel
            apply_theme(sel)
            st.query_params["theme"]=sel
        cur = st.session_state.themes.get(st.session_state.theme_name, list(st.session_state.themes.values())[0])
        bg = st.color_picker("Background", cur["bg"])
        card = st.color_picker("Card", cur["card"])
        text = st.color_picker("Text", cur["text"])
        muted = st.color_picker("Muted", cur["muted"])
        accent = st.color_picker("Accent", cur["accent"])
        name = st.text_input("Save as theme name", value="My Theme")
        if st.button("Save custom theme"):
            st.session_state.themes[name] = {"bg":bg,"card":card,"text":text,"muted":muted,"accent":accent}
            save_themes(st.session_state.themes); st.success("Saved theme")
    except Exception as e:
        st.error(e)
        log(str(e))

# if menu=="📰 Newsletter":
#     st.markdown('<div class="card"><h3>Newsletter</h3><div class="muted">Official Income Tax updates</div></div>', unsafe_allow_html=True)
#     try:
#         rss = "https://www.incometax.gov.in/iec/foportal/"
#         feed = feedparser.parse(rss)
#         parent_str = feed.feed.get("summary")
#         op = use_regex(parent_str)
#         items = [{"title": e[2::], "link":""} for e in op]
#         if not items:
#             st.caption("No news found.")
#         else:
#             idx = int(time.time()//3) % len(items)
#             it = items[idx]
#             st.markdown(it['title'])
#             if st.button("🔄 Next News"):
#                 pass
#     except Exception as e:
#         st.error("News fetch error"); log(str(e))

if menu=="⚙️ Settings":
    st.markdown('<div class="card"><h3>Settings & Diagnostics</h3></div>', unsafe_allow_html=True)
    try:
        if st.button("Reset session"):
            for k in list(st.session_state.keys()): del st.session_state[k]
            st.success("Session cleared")
        if os.path.exists(LOG) and st.button("Clear log"): os.remove(LOG); st.success("Log cleared")
        st.markdown("#### Log tail")
        if os.path.exists(LOG):
            with open(LOG,"r",encoding="utf-8") as f: st.text("".join(f.readlines()[-200:]))
        else:
            st.caption("No logs yet.")
    except Exception as e:
        st.error("Settings error"); log(str(e))



# ===============================================================