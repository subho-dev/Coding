
import os, threading, time, shutil, sys
VOSK_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

def ensure_vosk(models_dir="models/vosk"):
    os.makedirs(models_dir, exist_ok=True)
    target = os.path.join(models_dir, "vosk-model-small-en-us-0.15")
    if os.path.exists(target): return
    try:
        import requests, zipfile, io
        r = requests.get(VOSK_URL, stream=True, timeout=60); r.raise_for_status()
        z = zipfile.ZipFile(io.BytesIO(r.content)); z.extractall(models_dir)
    except Exception:
        pass

def background_bootstrap():
    threading.Thread(target=ensure_vosk, daemon=True).start()
