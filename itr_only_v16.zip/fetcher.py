
# fetcher.py - dynamic regime fetcher with merge & deprecation (v16)
import requests, yaml, json, logging, traceback, datetime
from bs4 import BeautifulSoup
logger = logging.getLogger("regime_fetcher_v16")

def try_load_remote(url, timeout=10):
    try:
        r = requests.get(url, timeout=timeout)
        r.raise_for_status()
        text = r.text.strip()
        try:
            return r.json()
        except Exception:
            pass
        try:
            return yaml.safe_load(text)
        except Exception:
            pass
    except Exception as e:
        logger.debug(f"load remote failed {url}: {e}")
    return None

def discover_links(html, base):
    soup = BeautifulSoup(html, "html.parser")
    links = []
    for a in soup.find_all("a", href=True):
        href = a['href']
        if any(href.lower().endswith(ext) for ext in [".yaml",".yml",".json"]):
            links.append(href if href.startswith("http") else requests.compat.urljoin(base, href))
    return links

def fetch_from_sources(sources):
    for src in sources:
        try:
            r = requests.get(src, timeout=10); r.raise_for_status()
            data = try_load_remote(src)
            if data and isinstance(data, dict) and "regimes" in data:
                return data, src
            links = discover_links(r.text, src)
            for link in links:
                data2 = try_load_remote(link)
                if data2 and isinstance(data2, dict) and "regimes" in data2:
                    return data2, link
        except Exception as e:
            logger.debug(f"source failed {src}: {e}")
            continue
    return None, None

def merge_configs(local_cfg, remote_cfg, grace_days=30):
    now = datetime.datetime.utcnow().isoformat()
    local = local_cfg.get("regimes", {})
    remote = remote_cfg.get("regimes", {})
    for k,v in remote.items():
        local[k] = v
        meta = local[k].setdefault("_meta", {})
        meta["source"] = remote_cfg.get("_source", "remote")
        meta["fetched_at"] = now
        meta.pop("deprecated", None)
    # mark deprecated local regimes not in remote
    for k in list(local.keys()):
        if k not in remote:
            meta = local[k].setdefault("_meta", {})
            if "deprecated" not in meta:
                meta["deprecated"] = now
            else:
                dt = datetime.datetime.fromisoformat(meta["deprecated"])
                if (datetime.datetime.utcnow() - dt).days > grace_days:
                    local.pop(k, None)
    local_cfg["regimes"] = local
    local_cfg["_last_sync"] = now
    return local_cfg
