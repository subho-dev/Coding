
ITR Assistant v16
-----------------
- Fully dynamic, auto-update capable regime manager with safe merge and deprecation.
- Animated, unique overview guiding new users step-by-step.
- No hardcoded regimes; default local config present as fallback.
- Beginner-friendly explanations, PDF export, Autopilot scaffold.
Run:
1) python -m venv .venv && source .venv/bin/activate
2) pip install -r requirements.txt
3) streamlit run app_streamlit_itr_only_v16.py
Notes:
- Remote fetching depends on sources providing machine-readable JSON/YAML; parsing HTML/PDF is heuristic.
- The app requires network access to fetch remote configs.
