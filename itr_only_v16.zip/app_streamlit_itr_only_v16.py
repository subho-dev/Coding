
# app_streamlit_itr_only_v16.py - v16: dynamic, animated, fully interactive overview
import os, io, time, traceback, json, datetime
import streamlit as st, pandas as pd, numpy as np, yaml
import plotly.express as px
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
from reportlab.lib.styles import getSampleStyleSheet
from fetcher import fetch_from_sources, merge_configs
from autopilot import run_autopilot_login, store_credentials

st.set_page_config(page_title="ITR Assistant v16", page_icon="✨", layout="wide", initial_sidebar_state="expanded")

LOG="itr_v16_log.txt"
def log(msg):
    try:
        with open(LOG,"a",encoding="utf-8") as f:
            f.write(f"{datetime.datetime.utcnow().isoformat()} - {msg}\\n")
    except: pass

# CSS: unique look, animated hero, floating cards
st.markdown(\"\"\"
<style>
:root{--bg:#071126;--card:rgba(255,255,255,0.04);--accent:#7afcff;--muted:#9fb8d6;}
.appview-container{background:linear-gradient(180deg,#071126,#02243b);}
.hero{background:linear-gradient(90deg,#03396c,#006d77); padding:24px; border-radius:14px; color:white; box-shadow:0 14px 40px rgba(2,6,23,0.6); animation:float 3s ease-in-out infinite;}
@keyframes float{0%{transform:translateY(0);}50%{transform:translateY(-6px);}100%{transform:translateY(0);}}
.card{background:var(--card);border-radius:12px;padding:14px;backdrop-filter:blur(6px);box-shadow:0 10px 30px rgba(0,0,0,0.5);transition:transform .18s;}
.card:hover{transform:translateY(-6px);}
.menu{display:flex;flex-direction:column;gap:8px;}
.menu-btn{padding:10px;border-radius:10px;transition:all .18s;}
.menu-btn:hover{transform:translateX(6px);}
.progress{height:8px;border-radius:8px;background:rgba(255,255,255,0.04);overflow:hidden;}
.progress > div{height:100%;background:linear-gradient(90deg,var(--accent),#b8fffd);width:0%;transition:width .6s ease;}
.small{color:var(--muted);font-size:13px;}
</style>
\"\"\", unsafe_allow_html=True)

# Sidebar modern menu
st.sidebar.markdown(\"<div class='card'><strong>✨ ITR Assistant v16</strong><div class='small'>Dynamic, auto-updating regimes & animated overview</div></div>\", unsafe_allow_html=True)
menu = st.sidebar.radio("Navigate", ["🏠 Overview","🧾 ITR Assistant","🧩 Regime Manager","🤖 Autopilot","⚙️ Settings"], index=0)

# load/default config
DEFAULT = {
    "regimes": {
        "old": {"name":"Old Regime","cess_percent":4,"slabs":[{"upto":250000,"rate":0},{"upto":500000,"rate":5},{"upto":1000000,"rate":20},{"upto":None,"rate":30}],"deduction_limits":{"80C":150000,"80D":25000,"home_loan_interest":200000},"explanation":"Standard old regime with common deductions."},
        "new": {"name":"New Regime","cess_percent":4,"slabs":[{"upto":300000,"rate":0},{"upto":600000,"rate":5},{"upto":900000,"rate":10},{"upto":1200000,"rate":15},{"upto":1500000,"rate":20},{"upto":2000000,"rate":25},{"upto":None,"rate":30}],"deduction_limits":{"80C":0,"80D":0,"home_loan_interest":0},"explanation":"New simplified regime with lower slabs but fewer deductions."}
    },
    "sources": [], "_last_sync": None
}
if "cfg" not in st.session_state:
    cfgf = "regimes.yaml"
    if os.path.exists(cfgf):
        try:
            with open(cfgf,"r",encoding="utf-8") as f: st.session_state.cfg = yaml.safe_load(f)
        except Exception as e:
            st.session_state.cfg = DEFAULT; log(f"load regimes.yaml failed: {e}")
    else:
        st.session_state.cfg = DEFAULT

def validate_cfg(cfg):
    return isinstance(cfg, dict) and "regimes" in cfg and isinstance(cfg["regimes"], dict)

def calc_tax(taxable, slabs, cess):
    tax=0.0; rem=taxable; lower=0.0
    for s in slabs:
        upto = s.get("upto"); rate=float(s.get("rate",0))/100.0
        if upto is None:
            tax += max(0,rem)*rate; break
        slab_amt = max(0.0,min(rem,float(upto)-lower)); tax += slab_amt*rate; rem -= slab_amt; lower=float(upto)
        if rem<=0: break
    tax += tax*(float(cess)/100.0); return max(0.0,tax)

def compute(incomes,deductions,cfg):
    try:
        total=sum(float(v) for v in incomes.values())
        out={}
        for k,reg in cfg.get("regimes",{}).items():
            dl = reg.get("deduction_limits",{}) or {}
            used=0.0
            for dk,amt in deductions.items():
                lim = dl.get(dk,None); a=float(amt)
                used += a if lim is None else min(a,float(lim))
            taxable = max(0.0, total-used)
            tax = calc_tax(taxable, reg.get("slabs",[]), reg.get("cess_percent",4))
            out[k] = {"name":reg.get("name",k),"tax":tax,"taxable":taxable,"ded_used":used,"explanation":reg.get("explanation","")}
        return total,out,None
    except Exception as e:
        return 0.0,{},str(e)

# ---------- Animated Overview ----------
if menu == "🏠 Overview":
    st.markdown(\"<div class='hero card'><h2>Welcome to ITR Assistant v16</h2><p class='small'>An interactive, beginner-friendly guide — auto-updates when tax regimes are published.</p></div>\", unsafe_allow_html=True)
    st.write("")
    # Animated steps with progress bar
    steps = ["1. Enter personal & income details","2. Enter deductions","3. Compare regimes & choose","4. Export PDF & follow filing guide","5. Use Autopilot to open e-filing portal"]
    for i,s in enumerate(steps):
        cols = st.columns([1,9])
        with cols[0]:
            st.markdown(f\"<div class='card menu-btn'>{i+1}</div>\", unsafe_allow_html=True)
        with cols[1]:
            st.markdown(f\"<div class='card'><strong>{s}</strong><div class='small'>Click into ITR Assistant to start — each step includes tips and examples for newcomers.</div></div>\", unsafe_allow_html=True)
    st.markdown('<div class="progress"><div style="width:50%"></div></div>', unsafe_allow_html=True)
    st.info(\"Tip: Configure trusted sources in Regime Manager to enable automatic updates when official regimes are published.\")

# ---------- ITR Assistant ----------
if menu == "🧾 ITR Assistant":
    st.markdown('<div class="card"><h3>ITR Assistant — Step-by-step</h3><div class="small">Each field has help text; hover for guidance. Beginners: follow the steps in Overview first.</div></div>', unsafe_allow_html=True)
    try:
        # Stepper style using expanders
        with st.expander(\"Personal details\", expanded=True):
            st.write(\"Why: Included in PDF & for clarity. PAN is required for filing.\")
            name = st.text_input(\"Full name\", key=\"v16_name\"); pan = st.text_input(\"PAN\", key=\"v16_pan\").upper()
            contact = st.text_input(\"Contact (optional)\", key=\"v16_contact\")
        with st.expander(\"Income (enter all heads)\", expanded=True):
            st.write(\"Examples: Salary from employer, business income, capital gains, interest.\")
            salary = st.number_input(\"Salary (₹)\", value=700000.0, step=1000.0, key=\"v16_salary\")
            business = st.number_input(\"Business (₹)\", value=0.0, step=1000.0, key=\"v16_business\")
            capg = st.number_input(\"Capital gains (₹)\", value=20000.0, step=1000.0, key=\"v16_capg\")
            other = st.number_input(\"Other income (₹)\", value=5000.0, step=500.0, key=\"v16_other\")
        with st.expander(\"Deductions (enter amounts you claim)\", expanded=True):
            st.write(\"The app applies deduction caps dynamically from the active regime configuration.\")
            d80c = st.number_input(\"80C (₹)\", value=150000.0, step=1000.0, key=\"v16_80c\")
            d80d = st.number_input(\"80D (₹)\", value=25000.0, step=1000.0, key=\"v16_80d\")
            home = st.number_input(\"Home loan interest (₹)\", value=200000.0, step=1000.0, key=\"v16_home\")
            d80g = st.number_input(\"80G donations (₹)\", value=0.0, step=500.0, key=\"v16_80g\")
        incomes = {\"salary\":salary,\"business\":business,\"capital_gains\":capg,\"other\":other}
        deductions = {\"80C\":d80c,\"80D\":d80d,\"home_loan_interest\":home,\"80G\":d80g}
        total, out, err = compute(incomes,deductions,st.session_state.cfg)
        if err:
            st.error(\"Computation failed: \" + str(err))
        else:
            st.metric(\"Total Income\", f\"₹{total:,.0f}\")
            df = pd.DataFrame(out).T.reset_index().rename(columns={\"index\":\"regime\"})
            df_disp = df[[\"regime\",\"name\",\"tax\",\"taxable\",\"ded_used\",\"explanation\"]].rename(columns={\"name\":\"Regime Name\",\"tax\":\"Tax (₹)\",\"taxable\":\"Taxable (₹)\",\"ded_used\":\"Deductions Used (₹)\",\"explanation\":\"Explanation\"})
            st.dataframe(df_disp.style.format({\"Tax (₹)\":\"{:.0f}\",\"Taxable (₹)\":\"{:.0f}\",\"Deductions Used (₹)\":\"{:.0f}\"}), height=240)
            st.plotly_chart(px.bar(df_disp, x=\"Regime Name\", y=\"Tax (₹)\", title=\"Tax comparison\"), use_container_width=True)
            best = df.loc[df[\"tax\"].idxmin(), \"regime\"]
            st.success(f\"Recommended regime: {st.session_state.cfg['regimes'][best].get('name',best)}\")
            with st.expander(\"Detailed filing guide (for newbies)\"):
                st.write(\"This guide walks through each filing step with examples and checks. Use the PDF export to save and share.\")
                st.write(\"1) Collect documents: Form16, Form26AS, bank statements. 2) Verify TDS & incomes. 3) Pick regime. 4) Enter in ITR form. 5) Upload proofs. 6) E-verify.\")
            if st.button(\"Export PDF Summary\"):
                try:
                    bar = px.bar(df_disp, x=\"Regime Name\", y=\"Tax (₹)\"); bar_path = \"v16_bar.png\"; bar.write_image(bar_path)
                    buffer = io.BytesIO(); doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=24,leftMargin=24,topMargin=24,bottomMargin=24)
                    styles = getSampleStyleSheet(); story = []
                    story.append(Paragraph(\"ITR Summary v16\", styles['Title'])); story.append(Spacer(1,6))
                    story.append(Paragraph(f\"Generated: {datetime.datetime.utcnow().isoformat()}\", styles['Normal'])); story.append(Spacer(1,6))
                    inc_table = [[\"Component\",\"Amount (₹)\"],[\"Salary\",f\"{salary:,.0f}\"],[\"Business\",f\"{business:,.0f}\"],[\"CapG\",f\"{capg:,.0f}\"],[\"Other\",f\"{other:,.0f}\"],[\"Total\",f\"{total:,.0f}\"]]
                    t = Table(inc_table); t.setStyle(TableStyle([(\"GRID\",(0,0),(-1,-1),0.5,colors.grey),(\"ALIGN\",(1,1),(1,-1),\"RIGHT\")])); story.append(t); story.append(Spacer(1,6))
                    comp = [[\"Regime\",\"Taxable\",\"Tax\",\"Deductions Used\"]]
                    for _,r in df_disp.iterrows():
                        comp.append([r['Regime Name'], f\"{r['Taxable (₹)']:,.0f}\", f\"{r['Tax (₹)']:,.0f}\", f\"{r['Deductions Used (₹)']:,.0f}\"])
                    tc = Table(comp); tc.setStyle(TableStyle([(\"GRID\",(0,0),(-1,-1),0.5,colors.grey),(\"ALIGN\",(1,1),(-1,-1),\"RIGHT\")])); story.append(tc)
                    doc.build(story); buffer.seek(0); st.download_button(\"Download PDF\", data=buffer.getvalue(), file_name=\"ITR_Summary_v16.pdf\", mime=\"application/pdf\")
                except Exception as e:
                    st.error(f\"PDF failed: {e}\"); log(f\"pdf err: {e}\\n{traceback.format_exc()}\")
    except Exception as e:
        st.error(\"ITR page error\"); log(f\"itr err: {e}\\n{traceback.format_exc()}\")

# ---------- Regime Manager (auto-update & safe merge) ----------
if menu == "🧩 Regime Manager":
    st.markdown('<div class=\"card\"><h3>Regime Manager</h3><div class=\"small\">Add trusted sources (official sites) and fetch remote configs. Merge after review.</div></div>', unsafe_allow_html=True)
    try:
        col1,col2 = st.columns([2,1])
        with col1:
            st.subheader(\"Active configuration (editable)\"); cfg_txt = yaml.safe_dump(st.session_state.cfg, sort_keys=False)
            edited = st.text_area(\"Edit regimes.yaml\", value=cfg_txt, height=420)
            if st.button(\"Apply edited config\"):
                try:
                    newc = yaml.safe_load(edited); valid = validate_cfg(newc)
                    if not valid: st.error(\"Invalid config\"); log(\"Invalid config apply attempt\")
                    else: st.session_state.cfg = newc; st.success(\"Applied in-memory\")
                except Exception as e:
                    st.error(f\"Parse error: {e}\"); log(f\"apply err: {e}\")
        with col2:
            st.subheader(\"Trusted sources\"); srcs = st.text_area(\"One URL per line\", value=\"\\n\".join(st.session_state.cfg.get('sources', [])), height=200)
            if st.button(\"Save sources\"):
                st.session_state.cfg['sources'] = [s.strip() for s in srcs.splitlines() if s.strip()]; st.success(\"Saved in-memory\")
            if st.button(\"Fetch remote configs now\"):
                sources = st.session_state.cfg.get('sources', [])
                if not sources: st.warning(\"No sources configured\")
                else:
                    remote, src = fetch_from_sources(sources)
                    if remote:
                        st.write(\"Remote config preview from:\", src); st.json(remote)
                        if st.button(\"Merge & apply remote config now\"):
                            try:
                                merged = merge_configs(st.session_state.cfg, remote, grace_days=30)
                                st.session_state.cfg = merged; st.success(\"Merged & applied in-memory\")
                            except Exception as e:
                                st.error(f\"Merge failed: {e}\"); log(f\"merge err: {e}\")
                    else:
                        st.info(\"No remote config found at provided sources.\")
            if st.button(\"Save to disk (regimes.yaml)\"):
                try:
                    with open('regimes.yaml','w',encoding='utf-8') as f: yaml.safe_dump(st.session_state.cfg, f, sort_keys=False)
                    st.success(\"Saved regimes.yaml\")
                except Exception as e:
                    st.error(f\"Save failed: {e}\"); log(f\"save err: {e}\")
    except Exception as e:
        st.error(\"Regime Manager error\"); log(f\"reg mgr err: {e}\\n{traceback.format_exc()}\")

# ---------- Autopilot & Settings ----------
if menu == "🤖 Autopilot":
    st.markdown('<div class=\"card\"><h3>Autopilot</h3><div class=\"small\">Opens e-filing portal. OTP must be entered manually.</div></div>', unsafe_allow_html=True)
    try:
        url = st.text_input(\"Login URL\", value=\"https://www.incometax.gov.in/\"); user = st.text_input(\"Username (PAN/Aadhaar)\")
        if st.button(\"Launch browser\"):
            ok,msg = run_autopilot_login(url,user); st.success(msg) if ok else st.error(msg); log(msg if not ok else 'Autopilot launched')
    except Exception as e:
        st.error(\"Autopilot error\"); log(f\"autopilot err: {e}\\n{traceback.format_exc()}\")

if menu == "⚙️ Settings":
    st.markdown('<div class=\"card\"><h3>Settings & Diagnostics</h3></div>', unsafe_allow_html=True)
    try:
        if st.button(\"Reset session state\"):
            for k in list(st.session_state.keys()): del st.session_state[k]; st.success(\"Session cleared\")
        if os.path.exists(LOG):
            if st.button(\"Clear log\"): os.remove(LOG); st.success(\"Log cleared\")
        st.markdown(\"#### Log tail\")
        if os.path.exists(LOG):
            with open(LOG,'r',encoding='utf-8') as f: st.text(''.join(f.readlines()[-200:]))
        else: st.caption('No logs yet.')
        st.markdown('#### Environment checks')
        try: import reportlab; st.success('reportlab OK') 
        except Exception as e: st.error(f'reportlab missing: {e}')
        try: import plotly; st.success('plotly OK')
        except Exception as e: st.error(f'plotly missing: {e}')
    except Exception as e:
        st.error('Settings error'); log(f\"settings err: {e}\\n{traceback.format_exc()}\")
