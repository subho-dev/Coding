(function(){
  const STATE={mode:'popup',demo:localStorage.getItem('cbv29.demo')==='true',voice:localStorage.getItem('cbv29.voice')==='true',theme:localStorage.getItem('cbv29.theme')||'dark',first:localStorage.getItem('cbv29.first')==='yes',lastActivity:Date.now(),newMsg:false};
  const root=document.createElement('div');root.className='cb-app cb-hidden';root.dataset.theme=STATE.theme;document.body.appendChild(root);
  const fab=document.createElement('div');fab.className='cb-fab';fab.title='Open Chat (Ctrl+Shift+C)';fab.innerHTML='💬<span class="badge"></span>';document.body.appendChild(fab);const badge=fab.querySelector('.badge');
  const dock=document.createElement('div');dock.className='cb-dock min';dock.innerHTML='<span class="glow"></span><span class="text">Chatbot ready</span>';document.body.appendChild(dock);
  const overlay=document.createElement('div');overlay.className='cb-overlay';const panel=document.createElement('div');panel.className='cb-panel';root.appendChild(overlay);root.appendChild(panel);
  const header=document.createElement('div');header.className='cb-header';header.innerHTML=`
    <div style="display:flex;align-items:center;gap:8px">
      <strong>CA Chatbot</strong>
      <button class="cb-iconbtn theme">🌓</button>
    </div>
    <div style="display:flex;gap:10px;align-items:center">
      <label style="font-size:12px">Voice <input class="voice" type="checkbox" ${STATE.voice?'checked':''}></label>
      <label style="font-size:12px">Demo <input class="demo" type="checkbox" ${STATE.demo?'checked':''}></label>
      <button class="cb-iconbtn close">✖</button>
    </div>`;
  const body=document.createElement('div');body.className='cb-body';
  const footer=document.createElement('div');footer.className='cb-footer';
  footer.innerHTML=`<input type="file" class="file" multiple>
    <textarea class="cb-textarea" placeholder="Type your question…"></textarea>
    <button class="cb-send">Send</button>`;
  panel.appendChild(header);panel.appendChild(body);panel.appendChild(footer);

  const banner=document.createElement('div');banner.className='cb-banner';banner.textContent='Demo Mode Active — sample CA Q&A loaded.';body.appendChild(banner);
  const toast=document.createElement('div');toast.className='cb-toast';document.body.appendChild(toast);

  function showToast(t,kind){toast.textContent=t;toast.className='cb-toast show ' + (kind==='demo'?'demo':(kind==='live'?'live':''));setTimeout(()=> toast.className='cb-toast',1600);}
  function addMsg(from, html){const w=document.createElement('div');w.className='cb-msg ' + (from==='user'?'user':'bot');const b=document.createElement('div');b.className='cb-bubble';b.innerHTML=html;w.appendChild(b);body.appendChild(w);body.scrollTop=body.scrollHeight;}
  function loader(){const w=document.createElement('div');w.className='cb-msg bot';const b=document.createElement('div');b.className='cb-bubble';b.innerHTML='<span class="cb-loader"><span class="cb-dot"></span><span class="cb-dot"></span><span class="cb-dot"></span></span> Thinking…';w.appendChild(b);body.appendChild(w);body.scrollTop=body.scrollHeight;return w;}

  function summarizeText(txt){
    try{ const o=JSON.parse(txt); const keys=Object.keys(o); let s=`JSON with ${keys.length} keys: ${keys.slice(0,20).join(', ')}.`;
      if(o && o.properties){ const p=Object.keys(o.properties); s += ` Schema properties: ${p.slice(0,25).join(', ')}.`; if(o.required) s += ` Required: ${o.required.join(', ')}.`; }
      return s;
    }catch(_){}
    if(/^[\s\S]*?:/m.test(txt)){ const ks=Array.from(txt.matchAll(/^(\s*)([\w\-\.\[\]]+)\s*:/gm)).slice(0,20).map(m=>m[2]); return 'YAML-like keys: ' + ks.join(', ') + ' .'; }
    if(/<([A-Za-z0-9:_-]+)(\s|>)/.test(txt)){ const tags=Array.from(txt.matchAll(/<([A-Za-z0-9:_-]+)(\s|>)/g)).map(m=>m[1]); const u=[...new Set(tags)].slice(0,20); return 'XML-like elements: ' + u.join(', ') + ' .'; }
    const words = txt.split(/\s+/).filter(Boolean); return 'Text ~'+words.length+' words. Preview: ' + words.slice(0,30).join(' ') + '…';
  }

  async function handleFiles(fs){
    for(const f of fs){
      addMsg('user','📎 ' + f.name);
      const L = loader();
      const ext=(f.name.split('.').pop()||'').toLowerCase();
      try{
        let sum='';
        if(['json','xml','yml','yaml','txt','md'].includes(ext)){
          const t = await f.text(); sum = summarizeText(t);
        }else if(ext==='pdf'){
          const buf = await f.arrayBuffer();
          const t = new TextDecoder().decode(new Uint8Array(buf).subarray(0,6000));
          sum = 'PDF detected. Quick scan: ' + summarizeText(t);
        }else if(['png','jpg','jpeg','webp','bmp'].includes(ext)){
          sum = 'Image detected. For OCR, enable offline helper.';
        }else sum='Unsupported type. Try JSON/XML/YAML/PDF/Image.';
        L.querySelector('.cb-bubble').innerHTML = sum;
        if(window.speechSynthesis && STATE.voice){ try{ speechSynthesis.speak(new SpeechSynthesisUtterance(sum)); }catch(e){} }
        STATE.newMsg = true; badge.style.display='inline-block';
      }catch(e){ L.querySelector('.cb-bubble').innerHTML='Failed: '+e.message; }
    }
  }

  async function ask(q){
    if(!q.trim()) return;
    addMsg('user', q);
    STATE.lastActivity = Date.now();
    const L = loader();
    let a='';
    if(STATE.demo){
      const s=q.toLowerCase();
      if(s.includes('old')&&s.includes('new')&&s.includes('regime')) a='Old: higher deductions + higher rates; New: lower rates with minimal deductions. Choose based on deduction size.';
      else a='Demo Mode: Ask tax questions or drop a file to summarize.';
    }else{
      try{
        if(window.askCA){
          a = await Promise.race([ window.askCA(q), new Promise((_,rej)=>setTimeout(()=>rej(new Error('timeout')),18000)) ]);
        }else{
          a = 'Live placeholder. Connect window.askCA(question) → Promise<string>.';
        }
      }catch(e){ a = 'Backend error: '+e.message; }
    }
    L.querySelector('.cb-bubble').innerHTML = a;
    if(window.speechSynthesis && STATE.voice){ try{ speechSynthesis.speak(new SpeechSynthesisUtterance(a)); }catch(e){} }
    STATE.newMsg = true; badge.style.display='inline-block';
  }

  addMsg('bot','Welcome! Ask tax/finance or drop JSON/XML/PDF/YAML/Image to summarize.');

  header.querySelector('.theme').onclick = ()=>{ root.dataset.theme = (root.dataset.theme==='light'?'dark':'light'); localStorage.setItem('cbv29.theme', root.dataset.theme); };
  header.querySelector('.close').onclick = ()=> closeUI();
  header.querySelector('.voice').onchange = (e)=>{ STATE.voice = e.target.checked; localStorage.setItem('cbv29.voice', STATE.voice); showToast(STATE.voice?'Voice Enabled':'Voice Disabled'); };
  header.querySelector('.demo').onchange = (e)=>{ STATE.demo = e.target.checked; localStorage.setItem('cbv29.demo', STATE.demo); updateBanner(); showToast(STATE.demo?'Demo Mode ON':'Live Mode ON', STATE.demo?'demo':'live'); };

  const fileInput = footer.querySelector('.file');
  const ta = footer.querySelector('.cb-textarea');
  const send = footer.querySelector('.cb-send');
  fileInput.onchange = ()=> handleFiles(fileInput.files);
  send.onclick = ()=>{ ask(ta.value); ta.value=''; };
  ta.addEventListener('keydown', e=>{ if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); send.click(); }});

  document.addEventListener('keydown', e=>{
    const k = e.key.toLowerCase();
    if((e.ctrlKey||e.metaKey)&&e.shiftKey&&k==='c'){ e.preventDefault(); root.classList.contains('cb-hidden')? openUI(): closeUI(); }
    if((e.ctrlKey||e.metaKey)&&!e.shiftKey&&k==='d'){ e.preventDefault(); STATE.demo=!STATE.demo; localStorage.setItem('cbv29.demo', STATE.demo); updateBanner(); showToast(STATE.demo?'Demo Mode ON':'Live Mode ON', STATE.demo?'demo':'live'); }
  });

  function openUI(){ root.classList.remove('cb-hidden'); if(STATE.mode==='full'){ root.classList.add('cb-full'); } else { root.classList.remove('cb-full'); } STATE.newMsg = false; badge.style.display='none'; }
  function closeUI(){ root.classList.add('cb-hidden'); }

  // Inactivity minimize
  setInterval(()=>{
    const inactive = Date.now() - STATE.lastActivity;
    if(inactive > 60000 && !root.classList.contains('cb-hidden')){
      closeUI(); dock.style.display='flex'; dock.querySelector('.text').textContent = 'Minimized — tap to resume';
    }
  }, 3000);

  fab.onclick = ()=> openUI();
  overlay.onclick = ()=> closeUI();
  dock.onclick = ()=> { openUI(); dock.style.display='none'; };

  // First-time setup
  if(!STATE.first){
    setTimeout(()=>{
      const setup=document.createElement('div'); setup.className='cb-setup show'; setup.innerHTML='<strong>Optional voice</strong> — enable anytime in header. Click to dismiss.';
      document.body.appendChild(setup);
      setup.onclick=()=>{ setup.remove(); localStorage.setItem('cbv29.first','yes'); };
    }, 600);
  }

  function setMode(m){ STATE.mode = (m==='full'?'full':'popup'); if(!root.classList.contains('cb-hidden')) openUI(); }
  function setTheme(t){ root.dataset.theme = t; localStorage.setItem('cbv29.theme', t); }
  function enableDemo(v){ STATE.demo = !!v; localStorage.setItem('cbv29.demo', STATE.demo); updateBanner(); }
  function enableVoice(v){ STATE.voice = !!v; localStorage.setItem('cbv29.voice', STATE.voice); }

  function updateBanner(){ banner.classList.toggle('show', STATE.demo); }

  // Open via query param
  try{ const u=new URLSearchParams(location.search); const m=u.get('chatbot'); if(m){ setMode(m); openUI(); } }catch(e){}

  window.CAChatbotV29 = { open: ()=>openUI(), close: ()=>closeUI(), setMode: setMode, setTheme: setTheme, enableDemo: enableDemo, enableVoice: enableVoice, ask: ask };
})();