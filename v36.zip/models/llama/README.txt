Place llama-2-7b-chat.ggmlv3.q4_0.bin here when downloaded.
