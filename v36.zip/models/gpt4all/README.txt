Place gpt4all-j.bin here when downloaded.
