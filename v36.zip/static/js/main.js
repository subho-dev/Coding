
/* main.js - UI behavior for top menu, chatbot and fcb */
document.addEventListener('DOMContentLoaded', ()=>{
  // Menu active highlighting and page switching
  document.querySelectorAll('.menu-item').forEach(a=>{
    a.addEventListener('click', (e)=>{
      e.preventDefault();
      document.querySelectorAll('.menu-item').forEach(x=>x.classList.remove('active'));
      a.classList.add('active');
      const key = a.dataset.key;
      document.querySelectorAll('.page').forEach(p=> p.style.display = p.id===key ? 'block' : 'none');
    });
  });

  // Simple i18n (English/Hindi) stub - real translations to be loaded or extended
  const strings = {
    en: { 'Ask a question':'Ask a question', 'Launch Copilot':'Launch Copilot (headless)' },
    hi: { 'Ask a question':'प्रश्न पूछें', 'Launch Copilot':'कॉपायलट लॉन्च (हेडलैस)' }
  };
  const langSelect = document.getElementById('langSelect');
  langSelect.addEventListener('change', ()=>{
    const lang = langSelect.value;
    // apply simple replacements (example)
    document.querySelectorAll('[data-i18n]').forEach(el=>{
      const key = el.dataset.i18n;
      el.textContent = strings[lang][key] || el.textContent;
    });
  });

  // Theme selector placeholder: move themes to top
  const themeSelector = document.getElementById('themeSelector');
  themeSelector.innerHTML = '<select id="themeSelect"><option value="default">Theme</option><option value="dark">Dark</option><option value="light">Light</option></select>';
  document.getElementById('themeSelect').addEventListener('change', e=>{
    if(e.target.value==='light'){
      document.documentElement.style.setProperty('--bg','#f6f7fb');
      document.documentElement.style.setProperty('--text','#0b1220');
    } else {
      document.documentElement.style.removeProperty('--bg');
      document.documentElement.style.removeProperty('--text');
    }
  });

  // Chat modal logic
  const chatToggle = document.getElementById('chatToggle');
  const chatModal = document.getElementById('chatModal');
  const chatBackdrop = document.getElementById('chatBackdrop');
  const minimizeBtn = document.getElementById('minimizeBtn');
  const closeBtn = document.getElementById('closeBtn');
  const fcb = document.getElementById('fcb');
  const sendBtn = document.getElementById('sendBtn');
  const userInput = document.getElementById('userInput');
  const messages = document.getElementById('messages');

  let inactivityTimer = null;
  let closeTimer = null;

  function openChat(){
    chatModal.style.display='flex';
    chatModal.classList.add('fade-in');
    chatModal.setAttribute('aria-hidden','false');
    fcb.classList.add('hidden');
    resetInactivityTimers();
  }
  function minimizeChat(){
    chatModal.style.display='none';
    chatModal.setAttribute('aria-hidden','true');
    fcb.classList.remove('hidden');
  }
  function closeChat(){
    chatModal.style.display='none';
    chatModal.setAttribute('aria-hidden','true');
    fcb.classList.add('hidden');
  }

  chatToggle.addEventListener('click', openChat);
  chatBackdrop.addEventListener('click', ()=>{ minimizeChat(); });
  minimizeBtn.addEventListener('click', ()=>{ minimizeChat(); });
  closeBtn.addEventListener('click', ()=>{ closeChat(); });

  // fcb draggable & click opens chat
  fcb.addEventListener('click', ()=>{ openChat(); });
  fcb.addEventListener('mousedown', startDrag);
  let dragging=false, dragOffset={x:0,y:0};
  function startDrag(e){
    dragging=true; dragOffset.x = e.clientX - fcb.offsetLeft; dragOffset.y = e.clientY - fcb.offsetTop;
    document.addEventListener('mousemove', onDrag);
    document.addEventListener('mouseup', stopDrag);
  }
  function onDrag(e){
    if(!dragging) return;
    let x = e.clientX - dragOffset.x;
    let y = e.clientY - dragOffset.y;
    x = Math.max(8, Math.min(window.innerWidth - fcb.offsetWidth - 8, x));
    y = Math.max(80, Math.min(window.innerHeight - fcb.offsetHeight - 8, y));
    fcb.style.left = x + 'px'; fcb.style.top = y + 'px'; fcb.style.right = 'auto'; fcb.style.bottom = 'auto';
  }
  function stopDrag(){ dragging=false; document.removeEventListener('mousemove', onDrag); document.removeEventListener('mouseup', stopDrag); }

  // Inactivity timers: 30s -> minimize to FCB with green dot; 5min -> close completely
  function resetInactivityTimers(){
    if(inactivityTimer) clearTimeout(inactivityTimer);
    if(closeTimer) clearTimeout(closeTimer);
    inactivityTimer = setTimeout(()=>{ minimizeChat(); showGreenDot(); }, 30*1000);
    closeTimer = setTimeout(()=>{ closeChat(); }, 5*60*1000);
  }
  function showGreenDot(){ fcb.textContent = '💬•'; }
  function clearGreenDot(){ fcb.textContent = '💬'; }

  // Interactions reset timers
  [sendBtn, userInput, chatModal, document].forEach(el=>{
    el.addEventListener ? el.addEventListener('click', resetInactivityTimers) : null;
    el.addEventListener ? el.addEventListener('keydown', resetInactivityTimers) : null;
  });

  // send message handler (calls backend /api/chat)
  async function sendMessage(){
    const text = userInput.value.trim();
    if(!text) return;
    appendMessage('user', text);
    userInput.value='';
    resetInactivityTimers();
    appendMessage('assistant', '...'); // placeholder
    try{
      const res = await fetch('/api/chat', {
        method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({message:text})
      });
      const data = await res.json();
      // replace last assistant placeholder
      const last = messages.querySelectorAll('.msg.assistant');
      if(last.length) last[last.length-1].textContent = data.reply || 'No response';
    }catch(e){
      const last = messages.querySelectorAll('.msg.assistant');
      if(last.length) last[last.length-1].textContent = 'Error contacting server. Using fallback response.';
    }
  }
  sendBtn.addEventListener('click', sendMessage);
  userInput.addEventListener('keydown', (e)=>{ if(e.key==='Enter') sendMessage(); });

  function appendMessage(who, text){
    const d = document.createElement('div');
    d.className = 'msg '+who;
    d.textContent = text;
    messages.appendChild(d);
    messages.scrollTop = messages.scrollHeight;
  }

  // Launch Copilot button behaviour -> open Autopilot menu
  document.getElementById('launchCopilot').addEventListener('click', ()=>{
    document.querySelectorAll('.menu-item').forEach(x=>x.classList.remove('active'));
    const ap = document.querySelector('[data-key="itr"]');
    ap.classList.add('active');
    document.querySelectorAll('.page').forEach(p=> p.style.display = p.id==='itr' ? 'block' : 'none');
    // option to open autopilot - backend will handle actual chrome launching
    fetch('/api/autopilot/start', {method:'POST'}).then(r=>console.log('Autopilot started')).catch(e=>console.error(e));
  });

  // initial setup
  resetInactivityTimers();
});
