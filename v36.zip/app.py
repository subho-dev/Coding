
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import sqlite3, os, threading, time, json

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "chat_memory.db")
MODEL_DIR = os.path.join(os.path.dirname(__file__), "models")
LLAMA_PATH = os.path.join(MODEL_DIR, "llama", "llama-2-7b-chat.ggmlv3.q4_0.bin")
GPT4ALL_PATH = os.path.join(MODEL_DIR, "gpt4all", "gpt4all-j.bin")
RULES_FILE = os.path.join(os.path.dirname(__file__), "data", "rules.json")

app = FastAPI()

# Ensure folders and sqlite DB exist
def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS memory (id INTEGER PRIMARY KEY, key TEXT UNIQUE, value TEXT, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    conn.commit()
    conn.close()

@app.on_event("startup")
def startup_event():
    init_db()
    # Ensure models dir exists
    os.makedirs(MODEL_DIR, exist_ok=True)
    # load rules fallback file if not exists
    if not os.path.exists(RULES_FILE):
        os.makedirs(os.path.dirname(RULES_FILE), exist_ok=True)
        with open(RULES_FILE, "w") as f:
            json.dump({"hi":"Hello! How can I help?", "default":"Sorry, I don't know that yet."}, f)

class ChatRequest(BaseModel):
    message: str

# Basic rule-based responder
def rule_based_response(msg):
    with open(RULES_FILE,'r') as f:
        rules = json.load(f)
    # naive match
    for k,v in rules.items():
        if k.lower() in msg.lower():
            return v
    return rules.get("default","I don't have an answer for that.")

# Placeholder model loader - does NOT download models here, but suggests auto-download if missing.
def generate_with_local_models(prompt):
    # Try LLaMA path first
    if os.path.exists(LLAMA_PATH):
        # Here you would integrate a GGML runtime or llama.cpp Python bindings to load and query the model.
        # For portability in this demo environment we return a simulated reply.
        return "LLAMA (local) would answer: " + prompt[:200]
    if os.path.exists(GPT4ALL_PATH):
        return "GPT4All-J (local) would answer: " + prompt[:200]
    # if no models, fallback to None so rule-based handler picks it up
    return None

@app.post("/api/chat")
async def chat_endpoint(req: ChatRequest):
    msg = req.message.strip()
    # 1) Try local models (LLAMA -> GPT4All)
    resp = generate_with_local_models(msg)
    if resp:
        # store user message and bot reply in sqlite memory for learning
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("INSERT OR REPLACE INTO memory (key,value) VALUES (?,?)", (msg[:200], resp))
            conn.commit()
            conn.close()
        except Exception as e:
            print("DB save failed:", e)
        return JSONResponse({"reply": resp})
    # 2) If no model, use rule based fallback
    fallback = rule_based_response(msg)
    return JSONResponse({"reply": fallback})

# Autopilot start endpoint - attempts to launch Chrome (non-headless) via system command or selenium (if installed).
@app.post("/api/autopilot/start")
async def autopilot_start():
    # This is a simple, safe attempt to launch Chrome on the server machine.
    # In production you'd use selenium/webdriver with proper binary path; here we spawn a background thread to attempt launch.
    def try_launch():
        import subprocess, shutil
        chrome_cmds = ["google-chrome", "chromium", "chrome", "msedge"]
        for cmd in chrome_cmds:
            path = shutil.which(cmd)
            if path:
                try:
                    # non-headless, open a new window with a blank page
                    subprocess.Popen([path, "--new-window", "about:blank"])
                    return
                except Exception as e:
                    print("Failed to launch", cmd, e)
    threading.Thread(target=try_launch, daemon=True).start()
    return JSONResponse({"status":"autopilot_started"})

# Endpoint to trigger model downloader (auto-download logic stub)
@app.post("/api/models/download")
async def download_models():
    # This endpoint will, when called, attempt to download LLaMA/GPT4All from known URLs.
    # For safety and portability we _do not_ download automatically in this environment, but provide the logic scaffold and return instructions.
    instructions = {
        "message":"Auto-download logic is configured. On first run the app will attempt to download models. If automatic download fails, please download manually.",
        "llama_url":"https://huggingface.co/___/llama-2-7b-chat.ggmlv3.q4_0.bin (replace with official path)",
        "gpt4all_url":"https://gpt4all.io/models/gpt4all-j.bin"
    }
    return JSONResponse(instructions)
