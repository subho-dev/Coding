
# Updated Project (v36) - Changes summary

This update includes:
- Top fixed menu (call button, language switcher, theme selector, chatbot in top menu)
- Chatbot modal with backdrop, draggable FCB, inactivity timers (30s minimize, 5min close)
- Frontend improvements and modernized UI (CSS + animations)
- FastAPI backend `app.py` enhanced: sqlite auto-creation, /api/chat, /api/autopilot/start, model download stub
- Offline model auto-download logic scaffold (does not embed heavy models in zip).

## Auto-download LLM logic
On first run the backend will attempt to download models into these paths (if implemented on your environment):
- `./models/llama/llama-2-7b-chat.ggmlv3.q4_0.bin`
- `./models/gpt4all/gpt4all-j.bin`

If automatic download fails, download manually and place the files in the directories above.
Recommended sources:
- LLaMA ggml builds (example mirrors & community uploads) - check Hugging Face or metalearning community releases.
- GPT4All-J: https://gpt4all.io/ (as a fallback)

## Running the app locally (example)

1. Create a Python virtualenv and install dependencies:
```
python -m venv venv
source venv/bin/activate
pip install fastapi uvicorn python-multipart
# Optionally: install transformers, gpt4all, llama-cpp-python as needed for local model support
```

2. Start the server:
```
uvicorn app:app --reload
```

3. Point your browser to `http://localhost:8000`

## Notes & Next steps
- The app includes scaffolding to integrate llama.cpp/ggml or GPT4All Python APIs. Uncomment and integrate the preferred runtime (llama-cpp-python, gpt4all, or a custom binding) into `app.py`'s `generate_with_local_models` function.
- Autopilot endpoint tries to open Chrome on the host machine via standard commands. For more robust control, integrate Selenium or Playwright (see comments in `app.py`).
- The existing rule-based responses remain as a fallback and are located at `data/rules.json`

