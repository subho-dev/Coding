
# schema_downloader.py
import os, time, shutil, re, pathlib
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

PORTAL_URL = "https://incometax.gov.in/iec/foportal/downloads/income-tax-returns"

def safe_name(s):
    return re.sub(r'[^A-Za-z0-9_\-\.]', '_', s)

def headless_driver(download_dir):
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-gpu")
    prefs = {"download.default_directory": str(download_dir), "download.prompt_for_download": False, "safebrowsing.enabled": True}
    opts.add_experimental_option("prefs", prefs)
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=opts)
    return driver

def decide_applicable_itr(user):
    # same heuristic as before
    salary = float(user.get('salary',0) or 0)
    business = float(user.get('business',0) or 0)
    capital = float(user.get('capital_gains',0) or 0)
    presumptive = bool(user.get('presumptive', False))
    multi_house = bool(user.get('multiple_house_property', False))
    total = salary + business + capital + float(user.get('other',0) or 0)
    if business>0:
        if presumptive and total<=5e6:
            return "itr-4"
        return "itr-3"
    if capital>0 or multi_house:
        return "itr-2"
    if total<=5e6 and capital==0 and business==0:
        return "itr-1"
    return "itr-2"

def download_schema_for_ay(fin_year, itr_id, dest_root="."):
    folder = os.path.join(dest_root, f"regimes_schema_{fin_year}", itr_id)
    pathlib.Path(folder).mkdir(parents=True, exist_ok=True)
    # if already exists any schema file, skip
    for f in os.listdir(folder):
        if f.lower().endswith(('.json','.xsd','.zip')):
            return folder, "already present"
    tmp = os.path.join(folder, "_tmp_dl"); pathlib.Path(tmp).mkdir(parents=True, exist_ok=True)
    driver = headless_driver(tmp)
    try:
        driver.get(PORTAL_URL)
        wait = WebDriverWait(driver, 20)
        # select AY by id
        sel = wait.until(EC.presence_of_element_located((By.ID, "edit-field-assessment-year-taxonomy-t-target-id")))
        try:
            Select(sel).select_by_visible_text(fin_year)
        except Exception:
            # try value match
            for opt in sel.find_elements(By.TAG_NAME, "option"):
                if fin_year in opt.text:
                    opt.click(); break
        time.sleep(1.0)
        # click itr button by id
        btn = wait.until(EC.element_to_be_clickable((By.ID, itr_id)))
        btn.click(); time.sleep(0.8)
        # click schema link
        link = None
        try:
            link = wait.until(EC.element_to_be_clickable((By.PARTIAL_LINK_TEXT, "Schema")))
        except Exception:
            # try xpath
            link = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(translate(text(),'SCHEMA','schema'),'schema')]")))
        link.click()
        # wait for download
        done=False; tries=0
        while not done and tries<120:
            time.sleep(0.5); tries+=1
            files = [f for f in os.listdir(tmp) if not f.endswith('.crdownload')]
            if files: done=True
        if not done:
            raise RuntimeError("download timeout")
        for f in os.listdir(tmp):
            shutil.move(os.path.join(tmp,f), os.path.join(folder,f))
        shutil.rmtree(tmp, ignore_errors=True)
        return folder, "downloaded"
    finally:
        try: driver.quit()
        except: pass

def bulk_fallback_all_years(fin_years, itr_ids=("itr-1","itr-2","itr-3","itr-4"), dest_root="."):
    msgs=[]
    for fy in fin_years:
        for itr in itr_ids:
            try:
                folder,msg = download_schema_for_ay(fy, itr, dest_root=dest_root)
                msgs.append(f"{fy}/{itr}: {msg}")
            except Exception as e:
                msgs.append(f"{fy}/{itr}: failed {e}")
    return msgs
