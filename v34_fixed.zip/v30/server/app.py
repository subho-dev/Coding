
from fastapi import FastAPI, Body, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any
import time, math, json
from io import BytesIO
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from sympy import sympify, Eq
from sympy import *
import traceback

app = FastAPI(title="Local CA Chatbot API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str
    history: List[Dict[str, str]] = []

def _handle_math(q: str) -> str:
    try:
        expr = q.strip().lstrip('= ')
        if not expr:
            return ""
        res = sympify(expr).evalf()
        return f"{expr} = {res}"
    except Exception:
        return ""

# tiny CA knowledge base / heuristics
CA_KB = {
    "gst registration threshold": "As per prevailing norms, GST registration is required if aggregate turnover exceeds ₹20 lakh (₹10 lakh for special category states). Certain businesses must register regardless of turnover.",
    "tds section 194c": "Section 194C: TDS on payments to contractors—1% if payee is individual/HUF; 2% otherwise. Thresholds and aggregate limits apply; no TDS if single payment ≤ ₹30,000 and aggregate ≤ ₹1,00,000 (check latest circulars).",
    "audit 44ab": "Tax audit u/s 44AB is mandatory if total sales/turnover/gross receipts exceed the prescribed limits (commonly ₹1 crore; enhanced thresholds may apply with digital transactions)."
}

def ca_answer(q: str) -> str:
    ql = q.lower()
    # math shortcut
    if ql.strip().startswith('='):
        m = _handle_math(q)
        if m: return m
    # heuristics
    for k,v in CA_KB.items():
        if k in ql:
            return v
    if 'gst' in ql and 'rate' in ql:
        return "GST rates vary (0%, 5%, 12%, 18%, 28%) depending on goods/services classification per HSN/SAC; apply input tax credit rules and reverse charge where applicable."
    if 'tds' in ql and ('rate' in ql or 'threshold' in ql):
        return "TDS rates depend on section (e.g., 192, 194C, 194J). Identify nature of payment, PAN availability, and residency. Apply surcharge/cess where applicable."
    if 'advance tax' in ql:
        return "Advance tax is payable in installments for individuals/corporates with tax liability ≥ ₹10,000 after TDS/TCS. Due dates typically: 15 Jun, 15 Sep, 15 Dec, 15 Mar (check latest AY dates)."
    # generic fallback
    return ("I'm a local CA assistant. Please provide context: nature of transaction, amounts, AY, and assessee type. "
            "I can compute tax brackets, explain compliance sections, or draft computation templates.")

@app.post("/api/chat")
def chat(req: ChatRequest):
    q = req.message or ""
    try:
        # code execution fenced block
        if "```" in q:
            code = q.split("```")
            if len(code) >= 3:
                lang = code[1].strip().lower()
                src = code[2]
                if 'python' in lang or lang == '':
                    import contextlib, io
                    buf = io.StringIO()
                    g = {"__builtins__":{"print":print, "range":range, "len":len, "sum":sum}}
                    l = {}
                    try:
                        with contextlib.redirect_stdout(buf):
                            exec(src, g, l)
                        out = buf.getvalue()
                        return {"reply": out if out else "(no output)"}
                    except Exception as e:
                        return {"reply": f"Execution error: {e}"}
        # smart math (= ...)
        if q.strip().startswith('='):
            m = _handle_math(q)
            if m: 
                return {"reply": m}
        # CA heuristics
        return {"reply": ca_answer(q)}
    except Exception as e:
        return {"reply": f"Error: {e}"}

class ExportRequest(BaseModel):
    history: List[Dict[str,str]]

@app.post("/api/export_pdf")
def export_pdf(req: ExportRequest):
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    story = [Paragraph("ASK THE CA — Conversation", styles['Title']), Spacer(1,12)]
    for m in req.history:
        who = m.get("role","user").capitalize()
        story.append(Paragraph(f"<b>{who}:</b> {m.get('text','')}", styles['BodyText']))
        story.append(Spacer(1,6))
    doc.build(story)
    pdf = buf.getvalue()
    return Response(content=pdf, media_type="application/pdf")

@app.get("/api/health")
def health():
    return {"ok": True}
