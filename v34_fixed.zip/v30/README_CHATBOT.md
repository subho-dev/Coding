# ITR Assistant – v34 fixed

- Chatbot FAB integrated (ASK THE CA) with minimize/maximize/close + unread badge + auto-minimize after 30s + PDF export.
- Uses local FastAPI backend autostarted by Streamlit (no manual server).
- No external/paid APIs; math via SymPy; CA heuristics built-in; supports running fenced Python code.
- Removed broken React embed and `onclick` string that caused React minified error #231.
- Newsletter section unchanged.

Run:
```bash
pip install -r requirements.txt
streamlit run app_streamlit_itr_only_v30.py
```
