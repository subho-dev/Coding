ITR + Stock Assistant v11
-------------------------
Further polished UI and animations, enhanced ITR assistant, unified features.
Run:
1. python -m venv venv
2. source venv/bin/activate
3. pip install -r requirements.txt
4. streamlit run app_streamlit_v11.py
