
# autopilot.py - minimal scaffold
import keyring, getpass, time, traceback
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

SERVICE_NAME = "itr_assistant_service"

def store_credentials(username, password):
    try:
        keyring.set_password(SERVICE_NAME, username, password)
        return True, "Stored"
    except Exception as e:
        return False, str(e)

def retrieve_password(username):
    try:
        return keyring.get_password(SERVICE_NAME, username)
    except Exception:
        return None

def run_autopilot_login(login_url, username, password=None, headless=False):
    try:
        if password is None:
            password = retrieve_password(username)
            if password is None:
                password = getpass.getpass("Enter password: ")
                store_credentials(username, password)
        options = webdriver.ChromeOptions()
        if headless:
            options.add_argument("--headless=new")
        driver = webdriver.Chrome(options=options)
        driver.get(login_url)
        time.sleep(2)
        return True, "Browser opened (manual OTP required)"
    except Exception as e:
        return False, str(e)
