
# exchange_utils.py - fetch S&P500 tickers via Wikipedia
import pandas as pd, requests, traceback
def fetch_sp500_tickers():
    try:
        tables = pd.read_html("https://en.wikipedia.org/wiki/List_of_S%26P_500_companies")
        df = tables[0]
        return sorted(df['Symbol'].tolist())
    except Exception as e:
        traceback.print_exc()
        return []

def prepare_nse_symbol(symbol):
    if symbol.endswith(".NS"): return symbol
    return f"{symbol}.NS"

def fetch_nse_list_from_exchange():
    return []
