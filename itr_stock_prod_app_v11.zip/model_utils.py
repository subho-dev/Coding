
# model_utils.py - simplified ensemble helpers
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestRegressor
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from prophet import Prophet
from sklearn.metrics import mean_squared_error
import math, traceback

def add_lag_features(df, lags=10):
    df = df.sort_values("date").copy()
    for i in range(1, lags+1):
        df[f"lag_{i}"] = df["close"].shift(i)
    df["target"] = df["close"].shift(-1)
    return df.dropna()

def train_rf(df, lags=10):
    try:
        df_f = add_lag_features(df, lags=lags)
        X = df_f[[f"lag_{i}" for i in range(1,lags+1)]].values
        y = df_f["target"].values
        if len(X) < 30:
            return None
        m = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=1)
        m.fit(X, y)
        last = X[-1].reshape(1,-1)
        pred = float(m.predict(last)[0])
        return {"model": m, "next_pred": pred}
    except Exception:
        return None

def train_es(df):
    try:
        es = ExponentialSmoothing(df["close"], trend="add", seasonal=None, damped_trend=True)
        f = es.fit(optimized=True)
        pred = float(f.forecast(1)[0])
        return {"pred": pred}
    except Exception:
        return None

def train_prophet(df):
    try:
        p_df = df[["date","close"]].rename(columns={"date":"ds","close":"y"})
        m = Prophet(daily_seasonality=False, weekly_seasonality=True, yearly_seasonality=True)
        m.fit(p_df)
        future = m.make_future_dataframe(periods=1, freq="D")
        fc = m.predict(future)
        pred = float(fc["yhat"].iloc[-1])
        return {"pred": pred}
    except Exception:
        return None

def ensemble_predict(df):
    try:
        preds = []
        rf = train_rf(df)
        if rf: preds.append(rf["next_pred"])
        es = train_es(df)
        if es: preds.append(es["pred"])
        pr = train_prophet(df)
        if pr: preds.append(pr["pred"])
        if not preds: return None
        return {"ensemble": float(sum(preds)/len(preds)), "components": {"rf": rf.get("next_pred") if rf else None, "es": es.get("pred") if es else None, "prophet": pr.get("pred") if pr else None}}
    except Exception:
        return None

def backtest_strategy(df, model_func=None):
    return None
