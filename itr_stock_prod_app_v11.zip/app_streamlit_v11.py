
# app_streamlit_v11.py - v11: UI polish, animations, advanced ITR assistant
import streamlit as st, pandas as pd, numpy as np, json, os, time, traceback
from datetime import datetime
from fuzzywuzzy import process
from exchange_utils import fetch_sp500_tickers, prepare_nse_symbol, fetch_nse_list_from_exchange
from model_utils import ensemble_predict, backtest_strategy
from autopilot import run_autopilot_login, store_credentials
import plotly.express as px, plotly.graph_objects as go

st.set_page_config(layout="wide", page_title="ITR + Stock Assistant v11", initial_sidebar_state="expanded",
                   page_icon="💼")

LOG_PATH = os.path.join(os.getcwd(), "itr_v11_log.txt")
def log(msg):
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(f"{datetime.utcnow().isoformat()} - {msg}\n")
    except:
        pass

# CSS animations and modern card styles
st.markdown("""
<style>
:root { --accent: #00b4d8; --bg: #0b1220; --card:#081022; --muted:#9fb3c8; }
.header {background: linear-gradient(90deg, #05204a, #024b6b); padding:18px; color:white; border-radius:12px; box-shadow: 0 8px 30px rgba(2, 36, 59, 0.6);}
.hero {display:flex; align-items:center; gap:18px;}
.hero h1 {margin:0; font-size:28px;}
.kpi {background: linear-gradient(90deg,#0f172a,#07172a); padding:12px; border-radius:10px; color:white;}
.card {background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01)); padding:14px; border-radius:10px; color:#e6f0ff; box-shadow: 0 4px 18px rgba(0,0,0,0.4);}
.small {color:#bcd7ec; font-size:13px;}
.button-gradient {background: linear-gradient(90deg, #00b4d8, #0077b6); color:white; padding:8px 12px; border-radius:8px; border: none;}
.anim-fade {animation: fadeIn 0.9s ease-in-out;}
@keyframes fadeIn { from {opacity:0; transform: translateY(8px);} to {opacity:1; transform: translateY(0);} }
</style>
""", unsafe_allow_html=True)

# Header / Hero
st.markdown(f"<div class='header anim-fade'><div class='hero'><div><h1>💼 ITR + Stock Assistant — v11</h1><div class='small'>Slick UI, animated charts, richer ITR assistant — demo</div></div></div></div>", unsafe_allow_html=True)
st.write("")

# Sidebar with icons and theme toggles (visual only)
st.sidebar.title("Navigate")
page = st.sidebar.radio("Go to", ["Dashboard","ITR Assistant","Stock Explorer","Invest Planner","Backtesting","Autopilot","Settings"])
st.sidebar.markdown("---")
if st.sidebar.button("Load S&P 500"):
    try:
        tickers = fetch_sp500_tickers(); st.session_state['tickers']=tickers; st.sidebar.success(f"Loaded {len(tickers)}")
    except Exception as e:
        st.sidebar.error("Load failed"); log(f"load sp500 error: {e}")

# Helper functions
@st.cache_data(ttl=3600)
def load_universe(key):
    try:
        if key=="S&P 500": return fetch_sp500_tickers()
        if key=="NSE": return fetch_nse_list_from_exchange()
    except Exception as e:
        log(f"load_universe err: {e}"); return []
    return []

def fetch_history(symbol, period="1y"):
    try:
        import yfinance as yf
        df = yf.Ticker(symbol).history(period=period, interval="1d", actions=False)
        if df is None or df.empty: return pd.DataFrame()
        df = df.reset_index()[['Date','Open','High','Low','Close','Volume']].rename(columns={'Date':'date','Close':'close','Open':'open','High':'high','Low':'low','Volume':'volume'})
        df['date'] = pd.to_datetime(df['date'])
        return df
    except Exception as e:
        log(f"fetch_history {symbol} err: {e}"); return pd.DataFrame()

def calc_tax_from_slabs(taxable, slabs, cess=4):
    tax=0.0; rem=taxable; lower=0.0
    for slab in slabs:
        upto=slab.get('upto'); rate=slab.get('rate',0)/100.0
        if upto is None: tax += max(0,rem)*rate; break
        slab_amt = max(0.0, min(rem, upto-lower)); tax += slab_amt*rate; rem -= slab_amt; lower=upto
        if rem<=0: break
    tax += tax*(cess/100.0); return tax

BUILTIN = {
    'old': {'slabs':[{'upto':250000,'rate':0},{'upto':500000,'rate':5},{'upto':1000000,'rate':20},{'upto':None,'rate':30}], 'ded_limits':{'80C':150000,'80D':25000}},
    'new': {'slabs':[{'upto':300000,'rate':0},{'upto':600000,'rate':5},{'upto':900000,'rate':10},{'upto':1200000,'rate':15},{'upto':1500000,'rate':20},{'upto':2000000,'rate':25},{'upto':None,'rate':30}], 'ded_limits':{'80C':0,'80D':0}}
}

# ---------------- Dashboard ----------------
if page=="Dashboard":
    st.markdown("<div class='card'><h3>Overview</h3><div class='small'>Quick KPIs & actions</div></div>", unsafe_allow_html=True)
    k1,k2,k3,k4 = st.columns(4)
    k1.metric("Tickers", len(st.session_state.get('tickers', [])))
    k2.metric("Models", "RF + ETS + Prophet")
    k3.metric("Version", "v11")
    k4.metric("Updated", datetime.utcnow().strftime("%Y-%m-%d"))
    st.markdown("---")
    # Animated loading demonstration
    st.write("Quick demo: animated progress for data refresh")
    if st.button("Simulate data refresh"):
        prog = st.progress(0)
        for i in range(20):
            time.sleep(0.05); prog.progress((i+1)*5)
        st.success("Refresh complete")

# ---------------- ITR Assistant ----------------
if page=="ITR Assistant":
    st.markdown("<div class='card'><h3>ITR Assistant — Dynamic & Visual</h3><div class='small'>Enter incomes & deductions, visualize tax outcomes, and get suggestions.</div></div>", unsafe_allow_html=True)
    try:
        tabs = st.tabs(["Quick","Detailed","Sensitivity","Guide"])
        # Quick tab
        with tabs[0]:
            c1,c2 = st.columns([2,1])
            with c1:
                salary = st.number_input("Salary (₹)", value=700000.0, key="v11_salary")
                business = st.number_input("Business (₹)", value=0.0, key="v11_business")
                capg = st.number_input("Capital Gains (₹)", value=20000.0, key="v11_capg")
                other = st.number_input("Other income (₹)", value=5000.0, key="v11_other")
            with c2:
                st.write("Deductions")
                c80c = st.slider("80C", 0, 150000, 150000, step=1000, key="v11_80c")
                c80d = st.slider("80D", 0, 100000, 25000, step=1000, key="v11_80d")
                home = st.slider("Home loan interest", 0, 500000, 200000, step=1000, key="v11_home")
            total = salary + business + capg + other
            st.metric("Total income", f"₹{total:,.0f}")
            # compute and show bar + pie + marginal curve
            try:
                regs = st.session_state.get('remote_regime', None) or {'regimes': {'old': {'slabs': BUILTIN['old']['slabs'], 'deduction_limits':BUILTIN['old']['ded_limits'], 'cess_percent':4}, 'new': {'slabs': BUILTIN['new']['slabs'], 'deduction_limits':BUILTIN['new']['ded_limits'], 'cess_percent':4}}}
                ded = {'80C': float(c80c), '80D': float(c80d), 'home_loan_interest': float(home)}
                out = {}
                for k,r in regs['regimes'].items():
                    dl = r.get('deduction_limits',{})
                    used=0.0
                    for key,val in ded.items():
                        lim = dl.get(key, None); used += val if lim is None else min(val, lim)
                    taxable = max(0.0, total - used); tax = calc_tax_from_slabs(taxable, r.get('slabs',[]), r.get('cess_percent',4))
                    out[k] = {'tax':tax,'taxable':taxable,'ded':used}
                df = pd.DataFrame.from_dict(out, orient='index').reset_index().rename(columns={'index':'regime'})
                st.plotly_chart(px.bar(df, x='regime', y='tax', title='Estimated tax by regime'), use_container_width=True)
                best = df.loc[df['tax'].idxmin()]['regime']
                st.success(f"Recommended regime: {best} ✅")
                pie = pd.DataFrame({'label':['Deductions used','Taxable Income'],'value':[out[best]['ded'], out[best]['taxable']]})
                st.plotly_chart(px.pie(pie, names='label', values='value', title=f'Breakdown — {best}'), use_container_width=True)
                # marginal tax curve
                tv = np.linspace(max(0,total-300000), total+100000, 60)
                taxes = [calc_tax_from_slabs(t, regs['regimes'][best]['slabs'], regs['regimes'][best].get('cess_percent',4)) for t in tv]
                mt = px.line(x=tv, y=taxes, labels={'x':'Taxable Income','y':'Tax (₹)'}, title='Marginal tax curve')
                st.plotly_chart(mt, use_container_width=True)
            except Exception as e:
                st.error("Computation failed"); log(f"itr quick err: {e}")
        # Detailed tab
        with tabs[1]:
            st.markdown("### Detailed income & deduction templates")
            try:
                with st.expander("Income components"):
                    st.text_input("Employer name", key="v11_employer"); st.text_input("PAN", key="v11_pan")
                with st.expander("Deductions details"):
                    st.slider("80C - ELSS/PPF/EPF etc", 0, 150000, st.session_state.get('v11_80c',150000), key="v11_80c_d")
                    st.slider("80D - Health insurance", 0, 100000, st.session_state.get('v11_80d',25000), key="v11_80d_d")
                    st.number_input("80G Donations (₹)", value=0.0, key="v11_80g_d")
                if st.button("Run detailed compute"):
                    st.info("Computing..."); time.sleep(0.4); st.success("Done")
            except Exception as e:
                st.error("Details error"); log(f"details err: {e}")
        # Sensitivity tab
        with tabs[2]:
            st.markdown("### Sensitivity: animate 80C effect")
            try:
                steps = st.slider("Animation steps", 5, 30, 12, key="v11_steps")
                sweep = list(range(0,150001, max(1,150000//steps)))
                sweep_data=[]
                regs = st.session_state.get('remote_regime', None) or {'regimes': {'old': {'slabs': BUILTIN['old']['slabs'], 'deduction_limits':BUILTIN['old']['ded_limits'], 'cess_percent':4}, 'new': {'slabs': BUILTIN['new']['slabs'], 'deduction_limits':BUILTIN['new']['ded_limits'], 'cess_percent':4}}}
                for v in sweep:
                    for k,r in regs['regimes'].items():
                        dl = r.get('deduction_limits',{}); used=0.0
                        for key,val in {'80C':v,'80D':st.session_state.get('v11_80d',25000),'home_loan_interest':st.session_state.get('v11_home',200000)}.items():
                            lim = dl.get(key, None); used += val if lim is None else min(val, lim)
                        taxable = max(0.0, sum([st.session_state.get('v11_salary',700000), st.session_state.get('v11_business',0), st.session_state.get('v11_capg',20000), st.session_state.get('v11_other',5000)]) - used)
                        tax = calc_tax_from_slabs(taxable, r.get('slabs',[]), r.get('cess_percent',4))
                        sweep_data.append({'80C':v, 'regime':k, 'tax':tax})
                sdf = pd.DataFrame(sweep_data)
                fig = px.line(sdf, x='80C', y='tax', color='regime', title='Tax vs 80C (sensitivity)')
                fig.update_traces(mode='lines+markers')
                st.plotly_chart(fig, use_container_width=True)
            except Exception as e:
                st.error("Sensitivity failed"); log(f"sensitivity err: {e}")
        # Guide tab with checklist
        with tabs[3]:
            st.markdown("### Filing Guide & Checklist")
            st.write("Step-by-step interactive guide (check items as you complete).")
            st.checkbox("Collect Form16", key="v11_chk1"); st.checkbox("Collect investment proofs", key="v11_chk2"); st.checkbox("Download Form26AS", key="v11_chk3")
            if st.button("Show guide pdf (demo)"):
                st.info("This is a demo — generate and attach your documents in production.")
    except Exception as e:
        st.error("ITR assistant error"); log(f"itr err: {e}"); st.exception(e)

# ---------------- Stock Explorer ----------------
if page=="Stock Explorer":
    st.markdown("<div class='card'><h3>Stock Explorer — Interactive Charts</h3></div>", unsafe_allow_html=True)
    try:
        uni = st.selectbox("Universe", ["S&P 500","NSE"])
        if st.button("Load tickers"):
            st.session_state['tickers'] = load_universe("S&P 500" if uni=="S&P 500" else "NSE"); st.success("Loaded tickers")
        tickers = st.session_state.get('tickers', [])[:500]
        search = st.text_input("Search (fuzzy)", "")
        if search and tickers:
            try:
                filtered = [t for t,_ in process.extract(search, tickers, limit=200)]
            except Exception:
                filtered = [t for t in tickers if search.upper() in t.upper()][:200]
        else:
            filtered = tickers
        symbol = st.selectbox("Symbol", filtered)
        if symbol:
            if uni=="NSE" and not symbol.endswith(".NS"): symbol = prepare_nse_symbol(symbol)
            df = fetch_history(symbol, period="1y")
            if df.empty:
                st.warning("No data for symbol")
            else:
                df['sma20'] = df['close'].rolling(20).mean()
                candle = go.Figure(data=[go.Candlestick(x=df['date'], open=df['open'], high=df['high'], low=df['low'], close=df['close'], name='OHLC')])
                candle.add_trace(go.Scatter(x=df['date'], y=df['sma20'], line=dict(color='#ffd966', width=1), name='SMA20'))
                candle.update_layout(height=600)
                st.plotly_chart(candle, use_container_width=True)
                try:
                    pred = ensemble_predict(df[['date','close']].rename(columns={'date':'date'}))
                    if pred: st.metric("Ensemble prediction", f"₹{pred['ensemble']:.2f}")
                except Exception as e:
                    st.warning("Prediction not available"); log(f"predict err: {e}")
    except Exception as e:
        st.error("Stock explorer failed"); log(f"stock explorer err: {e}"); st.exception(e)

# ---------------- Invest Planner, Backtesting, Autopilot (compact) ----------------
if page=="Invest Planner":
    st.title("Investment Planner")
    st.info("Heuristic recommendations and portfolio simulation available. Use Stock Explorer to pick symbols.")

if page=="Backtesting":
    st.title("Backtesting")
    sym = st.text_input("Symbol for backtest", value="AAPL")
    if st.button("Run backtest"):
        df = fetch_history(sym, period="2y")
        if df.empty or len(df)<80: st.error("Not enough data")
        else:
            res = backtest_strategy(df, None)
            st.write(res if res else "No result")

if page=="Autopilot":
    st.title("Autopilot (Selenium scaffold)")
    url = st.text_input("Login URL"); user = st.text_input("Username")
    if st.button("Store password securely"):
        import getpass; pwd = getpass.getpass("Enter password (terminal)"); ok,msg = store_credentials(user, pwd); st.success("Stored" if ok else f"Store failed: {msg}")
    if st.button("Launch autopilot"):
        ok,msg = run_autopilot_login(url, user, password=None, headless=False)
        if ok: st.success(msg)
        else: st.error(f"Autopilot failed: {msg}"); log(f"autopilot err: {msg}")

if page=="Settings":
    st.title("Settings & Logs")
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH,"r",encoding="utf-8") as f:
            tail = f.readlines()[-200:]
            st.text("".join(tail[-50:]))
    st.write("Requirements in requirements.txt")

st.markdown("---")
st.caption("v11 — polished UI, animated charts, enhanced ITR assistant. Demo only. Not financial advice.")
