
ITR Assistant v24 - Production-ready snapshot
- All requested features merged: dynamic schema downloads, schema-aware assistant, editable regime manager table,
  theme manager fixed, autopilot helper, newsletter, detailed PDF.
- Uses webdriver-manager to fetch chromedriver at runtime. If you want a binary included, upload exact chromedriver for your OS & Chrome.
Run:
1) python -m venv .venv
2) source .venv/bin/activate   # Windows: .venv\Scripts\activate
3) pip install -r requirements.txt
4) streamlit run app_streamlit_itr_only_v24.py


# Chatbot Integration (No external paid APIs)

## Run
```bash
pip install -r requirements.txt
bash run.sh
```
- Backend: http://localhost:7860 (FastAPI)
- Frontend: http://localhost:8080/web/index.html

## Embed on any page (popup/fullscreen/inline)
Place this in your HTML (host `web/assets` statically):
```html
<script>window.CB_ASSET_BASE="/web/assets/";window.CB_OPTIONS={apiBase:"/api",mode:"popup",title:"Assistant"};</script>
<script src="/web/assets/embed_custom.js"></script>
```

## Optional: Use a local LLM via Ollama (free)
Install [Ollama], run `ollama run llama3.1`, then start backend with:
```bash
USE_OLLAMA=1 OLLAMA_MODEL=llama3.1 uvicorn server.app:app --host 0.0.0.0 --port 7860
```
When Ollama is not available, the built-in math & Python engines answer computational and coding questions.
