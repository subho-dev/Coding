#!/usr/bin/env bash
set -e
export PYTHONUNBUFFERED=1
# Start FastAPI backend
uvicorn server.app:app --host 0.0.0.0 --port 7860 &
# Serve static files (web) via Python http.server
cd web && python -m http.server 8080
