
import asyncio
import json
import os
import re
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
import traceback

# Optional adapters
USE_OLLAMA = os.environ.get("USE_OLLAMA", "0") == "1"
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.1")
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434/api/generate")

app = FastAPI(title="Local Chatbot Backend", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    messages: list
    stream: bool = True
    system_prompt: str | None = None

def _safe_eval_math(expr: str) -> str:
    try:
        import sympy as sp
        x = sp.sympify(expr)
        return str(sp.simplify(x))
    except Exception as e:
        return f"[math engine error] {e}"

def _run_python(code: str, time_limit_sec: float = 3.0) -> str:
    """
    Sandbox-ish python execution with restricted builtins.
    Not bulletproof but safer for quick demos.
    """
    import multiprocessing as mp
    import sys

    def _target(code, out):
        try:
            import io, contextlib
            buf = io.StringIO()
            rglobals = {"__builtins__": {"print": print, "range": range, "len": len, "str": str, "int": int, "float": float}}
            with contextlib.redirect_stdout(buf):
                exec(code, rglobals, {})
            out.put(buf.getvalue() or "[no output]")
        except Exception as e:
            out.put("ERROR: " + str(e))

    q = mp.Queue()
    p = mp.Process(target=_target, args=(code, q))
    p.start()
    p.join(timeout=time_limit_sec)
    if p.is_alive():
        p.terminate()
        return "ERROR: execution timed out"
    try:
        return q.get_nowait()
    except Exception:
        return "[no output]"

async def _ollama_generate(prompt: str):
    import aiohttp
    payload = {"model": OLLAMA_MODEL, "prompt": prompt, "stream": True}
    async with aiohttp.ClientSession() as session:
        async with session.post(OLLAMA_URL, json=payload) as resp:
            async for line in resp.content:
                try:
                    obj = json.loads(line.decode("utf-8"))
                    chunk = obj.get("response", "")
                    if chunk:
                        yield chunk
                except Exception:
                    continue

def _local_reasoner(messages: list[str]):
    """
    Tiny heuristic assistant that can handle math and run python when asked.
    """
    user_text = ""
    for m in reversed(messages):
        if m.get("role") == "user":
            user_text = m.get("content", "")
            break

    # Math detection
    if re.search(r"^=|[*+/\\-]|\\bsolve\\b|\\bderive\\b|\\bintegrate\\b", user_text):
        result = _safe_eval_math(user_text.replace("=", "").strip())
        yield f"**Result:** {result}"
        return

    code_match = re.search(r"```(?:python)?\\n([\\s\\S]*?)```", user_text)
    if code_match:
        code = code_match.group(1)
        output = _run_python(code)
        yield f"**Output:**\\n```\n{output}\n```"
        return

    # Fallback: helpful canned response
    yield "I'm a local, privacy-friendly assistant. Ask me to solve math like `= 2*(3+4)^2` or run Python by sending a code block:\n```python\nprint(2+2)\n```"

@app.get("/api/health")
async def health():
    return {"status": "ok"}

@app.post("/api/chat")
async def chat(body: ChatRequest):
    messages = body.messages
    stream = body.stream
    system_prompt = body.system_prompt or "You are a concise, helpful assistant."

    if USE_OLLAMA:
        async def token_stream():
            yield ""
            async for tok in _ollama_generate(system_prompt + "\\n" + messages[-1]["content"]):
                yield tok
        if stream:
            return StreamingResponse(token_stream(), media_type="text/plain")
        else:
            text = ""
            async for t in _ollama_generate(system_prompt + "\\n" + messages[-1]["content"]):
                text += t
            return JSONResponse({"text": text})
    else:
        def token_stream_local():
            for tok in _local_reasoner(messages):
                yield tok
        if stream:
            return StreamingResponse(token_stream_local(), media_type="text/plain")
        else:
            text = "".join(list(_local_reasoner(messages)))
            return JSONResponse({"text": text})
