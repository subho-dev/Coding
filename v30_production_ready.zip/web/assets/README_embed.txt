// If your site serves frontend from a different origin, set apiBase to the full URL:
// window.Chatbot.mount("#chatbot",{apiBase:"http://localhost:7860/api"});