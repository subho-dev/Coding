/*! lightweight embed without Streamlit globals */
(function(){
  function inject(){
    if(window.__CB_EMBED_LOADED__) return; window.__CB_EMBED_LOADED__=true;
    const s = document.createElement("script");
    s.src = (window.CB_ASSET_BASE || "/web/assets/") + "chat.js";
    s.onload = function(){
      window.Chatbot.mount(document.body, window.CB_OPTIONS || {apiBase:"/api"});
    };
    document.head.appendChild(s);
    const l = document.createElement("link");
    l.rel="stylesheet"; l.href=(window.CB_ASSET_BASE || "/web/assets/") + "chat.css";
    document.head.appendChild(l);
  }
  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", inject);
  }else{ inject(); }
})();