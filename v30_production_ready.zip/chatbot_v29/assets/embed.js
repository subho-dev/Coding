(function(){/* Chatbot v29 core - see README for features */
const STATE={mode:'popup',demoMode:(localStorage.getItem('cbv29.demoMode')==='true'),voice:{enabled:(localStorage.getItem('cbv29.voice.enabled')==='true'),mode:(localStorage.getItem('cbv29.voice.mode')||'auto')},firstTime:(localStorage.getItem('cbv29.firstTimeSeen')==='yes'),theme:(localStorage.getItem('cbv29.theme')||'dark'),lastActivityAt:Date.now(),newMsg:false};
try{const p=new URLSearchParams(location.search);const m=p.get('chatbot');if(m==='full')STATE.mode='full';if(m==='popup')STATE.mode='popup';if(m==='off')return;}catch(e){}
const css=`:root{--cb-bg:#0b1320;--cb-fg:#e6e9ef;--cb-accent:#3aa1ff;--cb-muted:#9aa4b2;--cb-card:#141b2d;--cb-border:#23304a;--cb-toast-demo:#16a34a;--cb-toast-live:#2563eb}
[data-cb-theme="light"]{--cb-bg:#f7f8fb;--cb-fg:#111827;--cb-accent:#2563eb;--cb-muted:#4b5563;--cb-card:#fff;--cb-border:#e5e7eb}
.cbv29 *{box-sizing:border-box;font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Arial}
.cbv29{position:fixed;inset:0;display:none;z-index:2147483000}
.cbv29.open{display:block}
.cbv29 .overlay{position:absolute;inset:0;background:rgba(0,0,0,.45);animation:cb-fade .2s ease}
.cbv29 .panel{position:absolute;right:0;top:0;bottom:0;width:min(720px,100%);background:var(--cb-bg);color:var(--cb-fg);border-left:1px solid var(--cb-border);transform:translateX(8%);opacity:0;animation:cb-slide .22s ease forwards}
.cbv29.full .panel{left:0;right:0;width:100%;border-left:none}
.cbv29 header{display:flex;align-items:center;gap:10px;justify-content:space-between;padding:12px 16px;border-bottom:1px solid var(--cb-border);background:var(--cb-card);position:sticky;top:0;z-index:2}
.cbv29 .body{position:absolute;top:56px;bottom:64px;left:0;right:0;overflow:auto;padding:16px}
.cbv29 .msg{display:flex;gap:10px;margin-bottom:12px}
.cbv29 .bubble{padding:10px 12px;background:var(--cb-card);border:1px solid var(--cb-border);border-radius:10px;max-width:85%}
.cbv29 .msg.user .bubble{background:#2563eb22}
.cbv29 footer{position:absolute;bottom:0;left:0;right:0;padding:8px;background:var(--cb-card);border-top:1px solid var(--cb-border);display:flex;gap:8px;align-items:center}
.cbv29 textarea{flex:1;min-height:44px;max-height:120px;resize:vertical;padding:8px 10px;background:var(--cb-bg);color:var(--cb-fg);border:1px solid var(--cb-border);border-radius:8px}
.cbv29 .fab{position:fixed;right:18px;bottom:18px;width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:var(--cb-accent);color:#fff;box-shadow:0 8px 24px rgba(0,0,0,.25);z-index:2147482999;cursor:pointer}
.cbv29 .fab .badge{position:absolute;top:-4px;right:-4px;background:#ef4444;color:#fff;font-size:11px;padding:2px 6px;border-radius:999px;display:none}
.cbv29 .fab.pulse{animation:cb-breathe 2.8s ease-in-out infinite}
.cbv29 .banner{position:sticky;top:0;background:linear-gradient(90deg, rgba(20,120,60,.15), transparent);border:1px dashed var(--cb-border);padding:6px 10px;border-radius:8px;margin-bottom:8px;display:none}
.cbv29 .banner.show{display:block}
.cbv29 .loader{display:inline-flex;gap:4px;align-items:center}
.cbv29 .dot{width:6px;height:6px;border-radius:50%;background:var(--cb-muted);animation:cb-bounce 1.4s infinite}
.cbv29 .dot:nth-child(2){animation-delay:.15s}.cbv29 .dot:nth-child(3){animation-delay:.3s}
.cbv29 .toast{position:fixed;left:50%;transform:translateX(-50%);bottom:20px;padding:10px 14px;border-radius:999px;color:#fff;display:none;box-shadow:0 6px 18px rgba(0,0,0,.2)}
.cbv29 .toast.show{display:block;animation:cb-fade .18s ease}
.cbv29 .toast.demo{background:var(--cb-toast-demo)}.cbv29 .toast.live{background:var(--cb-toast-live)}
@keyframes cb-fade{from{opacity:0}to{opacity:1}}@keyframes cb-slide{from{transform:translateX(8%);opacity:0}to{transform:translateX(0);opacity:1}}@keyframes cb-bounce{0%,80%,100%{transform:scale(.75);opacity:.6}40%{transform:scale(1);opacity:1}}@keyframes cb-breathe{0%,100%{box-shadow:0 8px 24px rgba(0,0,0,.20)}50%{box-shadow:0 8px 24px rgba(0,0,0,.35)}}`;
const root=document.createElement('div');root.className='cbv29';root.dataset.cbTheme=STATE.theme;root.innerHTML=`<style>${css}</style>
<div class="fab" title="Open Chat (Ctrl+Shift+C)">💬<span class="badge"></span></div>
<div class="overlay"></div>
<div class="panel"><header><div style="display:flex;align-items:center;gap:8px"><strong>CA Chatbot</strong><button class="theme iconbtn" title="Toggle theme">🌓</button></div>
<div style="display:flex;gap:10px;align-items:center"><label style="font-size:12px">Voice <input class="voice" type="checkbox" ${STATE.voice.enabled?'checked':''}></label>
<label style="font-size:12px">Demo <input class="demo" type="checkbox" ${STATE.demoMode?'checked':''}></label>
<button class="close">✖</button></div></header>
<div class="body"><div class="banner">Demo Mode Active — sample CA Q&A loaded.</div>
<div class="msg"><div class="bubble">Welcome! Ask tax/finance or drop JSON/XML/PDF/YAML/Image to summarize.</div></div></div>
<footer><input type="file" class="file" multiple><textarea placeholder="Type your question…"></textarea><button class="send">Send</button></footer></div>
<div class="toast"></div>`;document.documentElement.appendChild(root);
const el={fab:root.querySelector('.fab'),badge:root.querySelector('.badge'),panel:root.querySelector('.panel'),overlay:root.querySelector('.overlay'),body:root.querySelector('.body'),ta:root.querySelector('textarea'),send:root.querySelector('.send'),file:root.querySelector('.file'),toast:root.querySelector('.toast'),banner:root.querySelector('.banner'),theme:root.querySelector('.theme'),voice:root.querySelector('.voice'),demo:root.querySelector('.demo')};
function openUI(f=true){root.classList.add('open');if(STATE.mode==='full'){root.classList.add('full')}else{root.classList.remove('full')}STATE.newMsg=false;el.badge.style.display='none'}
function closeUI(){root.classList.remove('open')}
function addMsg(from, html){const w=document.createElement('div');w.className='msg '+(from==='user'?'user':'bot');const b=document.createElement('div');b.className='bubble';b.innerHTML=html;w.appendChild(b);el.body.appendChild(w);el.body.scrollTop=el.body.scrollHeight}
function loader(){const w=document.createElement('div');w.className='msg bot';const b=document.createElement('div');b.className='bubble';b.innerHTML='<span class="loader"><span class="dot"></span><span class="dot"></span><span class="dot"></span></span> Thinking…';w.appendChild(b);el.body.appendChild(w);el.body.scrollTop=el.body.scrollHeight;return w}
function toast(t,k){el.toast.textContent=t;el.toast.className='toast show '+(k==='demo'?'demo':(k==='live'?'live':''));setTimeout(()=>el.toast.className='toast',1600)}
function summarizeText(txt){try{const o=JSON.parse(txt);const keys=Object.keys(o);let s=`JSON with ${keys.length} keys: ${keys.slice(0,20).join(', ')}.`;if(o.properties){const p=Object.keys(o.properties);s+=` Schema properties: ${p.slice(0,25).join(', ')}.`;if(o.required)s+=` Required: ${o.required.join(', ')}.`;}return s}catch(_){if(/^[\s\S]*?:/m.test(txt)){const ks=Array.from(txt.matchAll(/^(\s*)([\w\-\.\[\]]+)\s*:/gm)).slice(0,20).map(m=>m[2]);return 'YAML-like keys: '+ks.join(', ')+' .'}
if(/<([A-Za-z0-9:_-]+)(\s|>)/.test(txt)){const tags=Array.from(txt.matchAll(/<([A-Za-z0-9:_-]+)(\s|>)/g)).map(m=>m[1]);const u=[...new Set(tags)].slice(0,20);return 'XML-like elements: '+u.join(', ')+' .'}
const words=txt.split(/\s+/).filter(Boolean);return 'Text ~'+words.length+' words. Preview: '+words.slice(0,30).join(' ')+'…';}}
async function handleFiles(fs){for(const f of fs){addMsg('user','📎 '+f.name);const L=loader();const ext=(f.name.split('.').pop()||'').toLowerCase();try{let sum='';if(['json','xml','yml','yaml','txt','md'].includes(ext)){const t=await f.text();sum=summarizeText(t)}else if(ext==='pdf'){const buf=await f.arrayBuffer();const t=new TextDecoder().decode(new Uint8Array(buf).subarray(0,5000));sum='PDF detected. Quick scan: '+summarizeText(t)}else if(['png','jpg','jpeg','webp','bmp'].includes(ext)){sum='Image detected. For OCR summary, enable offline helper.'}else{sum='Unsupported type. Try JSON/XML/YAML/PDF/Image.'}L.querySelector('.bubble').innerHTML=sum; if(window.speechSynthesis && STATE.voice.enabled){try{speechSynthesis.speak(new SpeechSynthesisUtterance(sum))}catch(e){}} STATE.newMsg=true;el.badge.style.display='inline-block';}catch(e){L.querySelector('.bubble').innerHTML='Failed: '+e.message}}}
async function ask(q){if(!q.trim())return;addMsg('user',q);STATE.lastActivityAt=Date.now();const L=loader();let a='';if(STATE.demoMode){if(q.toLowerCase().includes('old')&&q.toLowerCase().includes('new')&&q.toLowerCase().includes('regime')){a='Old: higher deductions + higher rates; New: lower rates with minimal deductions. Choose based on your deduction size.'}else a='Demo Mode: Ask tax questions or drop a file to summarize.'}else{try{if(window.askCA){a=await Promise.race([window.askCA(q),new Promise((_,rej)=>setTimeout(()=>rej(new Error('timeout')),18000))])}else{a='Live placeholder. Connect window.askCA(question) → Promise<string>.'}}catch(e){a='Backend error: '+e.message}}L.querySelector('.bubble').innerHTML=a;if(window.speechSynthesis && STATE.voice.enabled){try{speechSynthesis.speak(new SpeechSynthesisUtterance(a))}catch(e){}}STATE.newMsg=true;el.badge.style.display='inline-block'}
function updateBanner(){el.banner.classList.toggle('show',STATE.demoMode)}
updateBanner();
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.shiftKey&&e.key.toLowerCase()==='c'){e.preventDefault();root.classList.contains('open')?closeUI():openUI()}if((e.ctrlKey||e.metaKey)&&!e.shiftKey&&e.key.toLowerCase()==='d'){e.preventDefault();STATE.demoMode=!STATE.demoMode;localStorage.setItem('cbv29.demoMode',STATE.demoMode);updateBanner();toast(STATE.demoMode?'Demo Mode ON':'Live Mode ON',STATE.demoMode?'demo':'live')}});
el.fab.onclick=()=>openUI();el.overlay.onclick=()=>closeUI();root.querySelector('.close').onclick=()=>closeUI();el.send.onclick=()=>{ask(el.ta.value);el.ta.value=''};el.ta.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();el.send.click()}});el.file.onchange=()=>handleFiles(el.file.files);root.dataset.cbTheme=STATE.theme;el.theme.onclick=()=>{root.dataset.cbTheme=root.dataset.cbTheme==='light'?'dark':'light';localStorage.setItem('cbv29.theme',root.dataset.cbTheme)};el.demo.onchange=()=>{STATE.demoMode=el.demo.checked;localStorage.setItem('cbv29.demoMode',STATE.demoMode);updateBanner();toast(STATE.demoMode?'Demo Mode ON':'Live Mode ON',STATE.demoMode?'demo':'live')};el.voice.onchange=()=>{STATE.voice.enabled=el.voice.checked;localStorage.setItem('cbv29.voice.enabled',STATE.voice.enabled);toast(STATE.voice.enabled?'Voice Enabled':'Voice Disabled')};
window.CAChatbotV29={open:()=>openUI(true),close:()=>closeUI(),setMode:(m)=>{STATE.mode=(m==='full'?'full':'popup'); if(root.classList.contains('open')) openUI(true)},setTheme:(t)=>{root.dataset.cbTheme=t;localStorage.setItem('cbv29.theme',t)},enableDemo:(v)=>{STATE.demoMode=!!v;localStorage.setItem('cbv29.demoMode',STATE.demoMode);updateBanner()},enableVoice:(v)=>{STATE.voice.enabled=!!v;localStorage.setItem('cbv29.voice.enabled',STATE.voice.enabled)},ask:ask};
})();