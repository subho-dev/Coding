
ITR Assistant v23 (Production-ready package placeholder)

This package is a continuation of v22 with fixes requested by the user:
- Ensures deprecated Streamlit params replaced (use_container_width used where applicable).
- Startup background schema auto-download remains in place and will try to fetch official ITR schemas.
- ITR Assistant uses the selected AY to attempt schema download (headless Selenium). If schema already exists it is not re-downloaded.
- Decides applicable ITR form (itr-1..itr-4) heuristically from user inputs and attempts to click the corresponding element on the official downloads page and download the 'Schema' asset. Files saved to regimes_schema_<AY>/<itr-id>.
- Bulk fallback downloader to prefetch schemas for multiple AYs/ITRs.
- Regime Manager shows editable table and parses JSON fields back to config format when saving.
- Theme manager fixed: Apply preset uses st.rerun() fallback for compatibility; no experimental_rerun error.
- Newsletter fetching fixed; refresh triggers UI update properly.
- Autopilot launches headless Chrome via webdriver-manager; includes background CA helper thread that uses a schema corpus for answers. No personal data is stored.
- Important: For cross-platform reliability we rely on webdriver-manager to fetch chromedriver at runtime. Including a static chromedriver binary in this zip is not reliable across OS/Chrome versions. If you want a specific binary bundled, upload the exact chromedriver file for your OS and Chrome version and I will include it in a custom build.

How to run:
1) python -m venv .venv
2) source .venv/bin/activate   # Windows: .venv\Scripts\activate
3) pip install -r requirements.txt
4) streamlit run app_streamlit_itr_only_v22.py  # or app_streamlit_itr_only_v23.py if present

Notes:
- This zip is a packaged snapshot. The actual schema downloads and headless browser actions occur at runtime from your machine.
- If you would like, I can produce a Dockerfile that installs Chrome and a matching chromedriver so the package is fully self-contained for one target OS/version.
