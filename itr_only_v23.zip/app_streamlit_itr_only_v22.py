
# app_streamlit_itr_only_v22.py (v22)
import os, threading, time, traceback, yaml, glob, sys
import streamlit as st
st.set_page_config(page_title="ITR Assistant v22", layout="wide")
LOG="itr_v22_log.txt"
def log(msg):
    try:
        with open(LOG,"a",encoding="utf-8") as f: f.write(f"{time.time()} - {msg}\n")
    except: pass

# Try import existing modules from package if present
try:
    from fetcher import fetch_from_sources
    from schema_downloader import bulk_fallback_all_years, download_schema_for_ay
    from autopilot import CAHelper, launch_headless_chrome
except Exception as e:
    log(f"imports: {e}")

# Auto-download schemas at startup in background if missing
def ensure_schemas(years=None, itr_ids=None):
    years = years or ["2025-26","2024-25","2023-24"]
    itr_ids = itr_ids or ("itr-1","itr-2","itr-3","itr-4")
    root = "."
    missing = []
    for y in years:
        for itr in itr_ids:
            folder = os.path.join(root, f"regimes_schema_{y}", itr)
            exists = any(os.path.exists(os.path.join(folder,f)) for f in (os.listdir(folder) if os.path.exists(folder) else []))
            if not exists:
                missing.append((y, itr))
    if not missing:
        log("No missing schemas found at startup.")
        return
    # run bulk fetch for missing years (using downloader)
    try:
        bulk_fallback_all_years(years, itr_ids, dest_root=root)
        log("Startup bulk fetch triggered.")
    except Exception as e:
        log(f"Startup fetch failed: {e}")

# Start background ensure on first run
if "startup_schema_thread" not in st.session_state:
    def bg_job():
        try:
            ensure_schemas()
        except Exception as e:
            log(f"bg_job error: {e}\\n{traceback.format_exc()}")
    t = threading.Thread(target=bg_job, daemon=True)
    t.start()
    st.session_state.startup_schema_thread = True

st.title("ITR Assistant v22 (Startup auto-schema & improved CA helper)")
st.write("This app will attempt to download official schemas at startup in background if they are missing. See Logs in Settings for details.")

st.button("Show Log (tail)")
if st.button("Open Settings"):
    st.experimental_set_query_params(open="settings")
